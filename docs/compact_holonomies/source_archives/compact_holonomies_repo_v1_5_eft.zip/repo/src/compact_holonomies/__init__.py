"""Compact holonomies research utilities.

The package deliberately separates exact identities, controlled effective-field-
theory (EFT) assumptions, and phenomenological hypotheses.
"""

from .effective_foam_eft import (
    EFTParameters,
    HolonomyCorrection,
    barrier_action,
    tunneling_amplitude,
    tunneling_probability,
    foam_corrected_barrier,
    phase_decoherence_factor,
    planck_suppression,
)

__all__ = [
    "EFTParameters",
    "HolonomyCorrection",
    "barrier_action",
    "tunneling_amplitude",
    "tunneling_probability",
    "foam_corrected_barrier",
    "phase_decoherence_factor",
    "planck_suppression",
]
