#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
pytest -q
python3 scripts/verify_holonomy_document.py
python3 scripts/verify_effective_foam_eft.py
