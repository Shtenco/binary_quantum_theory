"""Controlled quantum 3+1 linearized-gravity sector on a periodic lattice.

This module closes several pieces that were absent from the nonlinear research
program: a kinematic Hilbert space, explicit quantum constraints, a physical TT
subspace, a positive inner product, unitary evolution and a propagator.

The result is deliberately limited to linear perturbations around flat space.
At this order the hypersurface-deformation algebra is Abelianized.  Therefore
exact commutator closure here is not a solution of the nonlinear 3+1 Dirac
algebra with structure functions.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

import numpy as np
from scipy.linalg import expm


Array = np.ndarray


def _symmetric_basis() -> tuple[Array, ...]:
    basis: list[Array] = []
    for i in range(3):
        m = np.zeros((3, 3), dtype=float)
        m[i, i] = 1.0
        basis.append(m)
    for i, j in ((0, 1), (0, 2), (1, 2)):
        m = np.zeros((3, 3), dtype=float)
        m[i, j] = m[j, i] = 1.0 / np.sqrt(2.0)
        basis.append(m)
    return tuple(basis)


SYMMETRIC_BASIS = _symmetric_basis()


def symmetric_tensor_to_vector(tensor: Array) -> Array:
    tensor = np.asarray(tensor, dtype=float)
    if tensor.shape != (3, 3):
        raise ValueError("tensor must be 3x3")
    return np.array([np.tensordot(b, tensor, axes=2) for b in SYMMETRIC_BASIS])


def symmetric_vector_to_tensor(vector: Array) -> Array:
    vector = np.asarray(vector, dtype=float)
    if vector.shape != (6,):
        raise ValueError("vector must have six symmetric components")
    return sum(coefficient * basis for coefficient, basis in zip(vector, SYMMETRIC_BASIS))


def signed_mode(mode: int, size: int) -> int:
    if size < 3:
        raise ValueError("lattice size must be >=3")
    value = int(mode) % int(size)
    return value if value <= size // 2 else value - size


def continuum_momentum(
    mode: Iterable[int], shape: Iterable[int], spacing: float = 1.0
) -> Array:
    shape_array = np.asarray(tuple(shape), dtype=int)
    mode_array = np.asarray(tuple(mode), dtype=int)
    if shape_array.shape != (3,) or mode_array.shape != (3,):
        raise ValueError("mode and shape must contain three entries")
    if spacing <= 0 or np.any(shape_array < 3):
        raise ValueError("spacing must be positive and all sizes >=3")
    signed = np.array([signed_mode(n, size) for n, size in zip(mode_array, shape_array)])
    lengths = spacing * shape_array
    return 2.0 * np.pi * signed / lengths


def lattice_momentum(
    mode: Iterable[int], shape: Iterable[int], spacing: float = 1.0
) -> Array:
    """Symmetric finite-difference momentum 2 sin(k a/2)/a."""
    k = continuum_momentum(mode, shape, spacing)
    return 2.0 * np.sin(0.5 * spacing * k) / spacing


def lattice_dispersion(
    mode: Iterable[int], shape: Iterable[int], spacing: float = 1.0
) -> float:
    khat = lattice_momentum(mode, shape, spacing)
    return float(khat @ khat)


def transverse_projector(momentum: Array) -> Array:
    momentum = np.asarray(momentum, dtype=float)
    if momentum.shape != (3,):
        raise ValueError("momentum must have three components")
    norm2 = float(momentum @ momentum)
    if norm2 <= 1e-30:
        raise ValueError("TT projection is undefined for the zero mode")
    return np.eye(3) - np.outer(momentum, momentum) / norm2


def tt_action(tensor: Array, momentum: Array) -> Array:
    tensor = np.asarray(tensor, dtype=float)
    if tensor.shape != (3, 3):
        raise ValueError("tensor must be 3x3")
    p = transverse_projector(momentum)
    transverse = p @ tensor @ p
    return transverse - 0.5 * p * np.trace(transverse)


def tt_projector(momentum: Array) -> Array:
    columns = [symmetric_tensor_to_vector(tt_action(basis, momentum)) for basis in SYMMETRIC_BASIS]
    return np.column_stack(columns)


def tt_polarization_basis(momentum: Array, tolerance: float = 1e-10) -> Array:
    projector = tt_projector(momentum)
    values, vectors = np.linalg.eigh(0.5 * (projector + projector.T))
    selected = vectors[:, values > 1.0 - tolerance]
    if selected.shape != (6, 2):
        raise RuntimeError(f"expected two TT modes, found {selected.shape[1]}")
    return selected


def _levi_civita(a: int, b: int, c: int) -> int:
    if len({a, b, c}) < 3:
        return 0
    permutation = (a, b, c)
    inversions = sum(permutation[i] > permutation[j] for i in range(3) for j in range(i + 1, 3))
    return -1 if inversions % 2 else 1


@dataclass(frozen=True)
class LinearConstraint:
    name: str
    q_coefficients: Array
    p_coefficients: Array

    def commutator_coefficient(self, other: "LinearConstraint", hbar: float = 1.0) -> complex:
        """Coefficient c in [C1,C2]=c I for [q_A,p_B]=i hbar delta_AB."""
        if hbar <= 0:
            raise ValueError("hbar must be positive")
        symplectic = float(self.q_coefficients @ other.p_coefficients - self.p_coefficients @ other.q_coefficients)
        return 1j * hbar * symplectic


def linearized_constraints(momentum: Array) -> tuple[LinearConstraint, ...]:
    """Abelianized Gauss, spatial-diffeomorphism and Hamiltonian constraints.

    Canonical variables are a triad perturbation q_(a i) and momentum p_(a i),
    flattened into nine components.  The background identifies internal and
    spatial indices.  The Gauss constraints remove the antisymmetric sector;
    D_i and H act on the symmetric metric sector.
    """
    k = np.asarray(momentum, dtype=float)
    if k.shape != (3,) or float(k @ k) <= 1e-30:
        raise ValueError("a nonzero three-momentum is required")

    constraints: list[LinearConstraint] = []
    zero = np.zeros(9, dtype=float)

    # Linearized internal-rotation constraints: G_a = eps_(a b i) p_(b i).
    for a in range(3):
        p = np.zeros((3, 3), dtype=float)
        for b in range(3):
            for i in range(3):
                p[b, i] = _levi_civita(a, b, i)
        constraints.append(LinearConstraint(f"G{a}", zero.copy(), p.reshape(-1)))

    # Linearized momentum constraints D_i=-2 k_j p_(ij), using the symmetric part.
    for i in range(3):
        p = np.zeros((3, 3), dtype=float)
        for j in range(3):
            p[i, j] -= k[j]
            p[j, i] -= k[j]
        constraints.append(LinearConstraint(f"D{i}", zero.copy(), p.reshape(-1)))

    # Scalar constraint H=(k_i k_j-k^2 delta_ij) q_(ij).
    q = np.outer(k, k) - float(k @ k) * np.eye(3)
    constraints.append(LinearConstraint("H", q.reshape(-1), zero.copy()))
    return tuple(constraints)


def quantum_constraint_algebra_certificate(momentum: Array, hbar: float = 1.0) -> dict[str, Any]:
    constraints = linearized_constraints(momentum)
    matrix = np.zeros((len(constraints), len(constraints)), dtype=complex)
    for i, left in enumerate(constraints):
        for j, right in enumerate(constraints):
            matrix[i, j] = left.commutator_coefficient(right, hbar)
    return {
        "constraint_names": [constraint.name for constraint in constraints],
        "max_absolute_commutator_coefficient": float(np.max(np.abs(matrix))),
        "commutator_matrix_real": matrix.real.tolist(),
        "commutator_matrix_imag": matrix.imag.tolist(),
        "algebra": "exact Abelianized linearized 3+1 constraint algebra",
        "pass": bool(np.max(np.abs(matrix)) < 1e-13),
        "scope": "linear perturbations around a flat background; not the nonlinear Dirac algebra",
    }


def annihilation_operator(cutoff: int) -> Array:
    if cutoff < 2:
        raise ValueError("cutoff must be >=2")
    operator = np.zeros((cutoff, cutoff), dtype=complex)
    for n in range(1, cutoff):
        operator[n - 1, n] = np.sqrt(n)
    return operator


@dataclass(frozen=True)
class PhysicalFockSector:
    cutoff: int
    omega: float
    hbar: float
    hamiltonian: Array
    annihilation_plus: Array
    annihilation_cross: Array


def physical_fock_sector(cutoff: int, omega: float, hbar: float = 1.0) -> PhysicalFockSector:
    if omega <= 0 or hbar <= 0:
        raise ValueError("omega and hbar must be positive")
    a = annihilation_operator(cutoff)
    identity = np.eye(cutoff, dtype=complex)
    a_plus = np.kron(a, identity)
    a_cross = np.kron(identity, a)
    number_plus = a_plus.conj().T @ a_plus
    number_cross = a_cross.conj().T @ a_cross
    total_identity = np.eye(cutoff**2, dtype=complex)
    hamiltonian = hbar * omega * (number_plus + number_cross + total_identity)
    return PhysicalFockSector(cutoff, float(omega), float(hbar), hamiltonian, a_plus, a_cross)


def low_occupancy_projector(cutoff: int) -> Array:
    """Project away states touching the finite-Fock truncation boundary."""
    keep = []
    for n_plus in range(cutoff):
        for n_cross in range(cutoff):
            keep.append(n_plus < cutoff - 1 and n_cross < cutoff - 1)
    return np.diag(np.asarray(keep, dtype=float))


def fock_certificate(cutoff: int = 6, omega: float = 0.7, hbar: float = 1.0, time: float = 0.41) -> dict[str, Any]:
    sector = physical_fock_sector(cutoff, omega, hbar)
    identity = np.eye(cutoff**2, dtype=complex)
    low = low_occupancy_projector(cutoff)
    commutator_plus = sector.annihilation_plus @ sector.annihilation_plus.conj().T - sector.annihilation_plus.conj().T @ sector.annihilation_plus
    commutator_cross = sector.annihilation_cross @ sector.annihilation_cross.conj().T - sector.annihilation_cross.conj().T @ sector.annihilation_cross
    low_error_plus = np.linalg.norm(low @ (commutator_plus - identity) @ low)
    low_error_cross = np.linalg.norm(low @ (commutator_cross - identity) @ low)
    unitary = expm(-1j * sector.hamiltonian * time / hbar)
    unitary_error = np.linalg.norm(unitary.conj().T @ unitary - identity)
    eigenvalues = np.linalg.eigvalsh(sector.hamiltonian)
    expected_ground = hbar * omega
    return {
        "hilbert_dimension": cutoff**2,
        "physical_polarizations": 2,
        "positive_inner_product": True,
        "ground_energy": float(eigenvalues[0]),
        "expected_ground_energy": float(expected_ground),
        "low_occupancy_ccr_error_plus": float(low_error_plus),
        "low_occupancy_ccr_error_cross": float(low_error_cross),
        "unitarity_error": float(unitary_error),
        "pass": bool(
            abs(eigenvalues[0] - expected_ground) < 1e-13
            and low_error_plus < 1e-13
            and low_error_cross < 1e-13
            and unitary_error < 1e-12
        ),
    }


def thermal_partition_function(beta_temperature: float, omega: float, hbar: float = 1.0) -> float:
    if beta_temperature <= 0 or omega <= 0 or hbar <= 0:
        raise ValueError("all parameters must be positive")
    x = np.exp(-beta_temperature * hbar * omega)
    return float(np.exp(-beta_temperature * hbar * omega) / (1.0 - x) ** 2)


def propagator_residue(momentum: Array) -> Array:
    """Residue of the physical graviton propagator at the massless pole."""
    return tt_projector(momentum)


def dispersion_convergence_certificate(
    mode: tuple[int, int, int] = (1, 2, 0),
    lattice_sizes: tuple[int, ...] = (16, 24, 32, 48, 64),
    physical_length: float = 2.0 * np.pi,
) -> dict[str, Any]:
    errors: list[float] = []
    spacings: list[float] = []
    continuum_value: float | None = None
    for size in lattice_sizes:
        spacing = physical_length / size
        k = continuum_momentum(mode, (size, size, size), spacing)
        continuum_value = float(k @ k)
        lattice_value = lattice_dispersion(mode, (size, size, size), spacing)
        errors.append(abs(lattice_value - continuum_value))
        spacings.append(spacing)
    orders = [
        np.log(errors[i - 1] / errors[i]) / np.log(spacings[i - 1] / spacings[i])
        for i in range(1, len(errors))
    ]
    return {
        "mode": list(mode),
        "lattice_sizes": list(lattice_sizes),
        "spacings": spacings,
        "absolute_errors": errors,
        "observed_orders": [float(value) for value in orders],
        "minimum_observed_order": float(min(orders)),
        "continuum_omega_squared": float(continuum_value),
        "pass": bool(min(orders) > 1.95),
    }


def anisotropy_prediction_coefficient_ratio() -> float:
    """Ratio of O(a^2 k^4) corrections: axis direction / body diagonal = 3."""
    return 3.0


def linearized_quantum_gravity_certificate() -> dict[str, Any]:
    shape = (32, 32, 32)
    spacing = 0.2
    mode = (2, 3, 1)
    momentum = lattice_momentum(mode, shape, spacing)
    projector = tt_projector(momentum)
    eigenvalues = np.linalg.eigvalsh(0.5 * (projector + projector.T))
    polarization_basis = tt_polarization_basis(momentum)
    tensors = [symmetric_vector_to_tensor(polarization_basis[:, i]) for i in range(2)]
    transversality = max(np.linalg.norm(tensor @ momentum) for tensor in tensors)
    trace_error = max(abs(np.trace(tensor)) for tensor in tensors)
    algebra = quantum_constraint_algebra_certificate(momentum)
    constraints = linearized_constraints(momentum)
    gradient_matrix = np.vstack([
        np.concatenate([constraint.q_coefficients, constraint.p_coefficients])
        for constraint in constraints
    ])
    constraint_rank = int(np.linalg.matrix_rank(gradient_matrix, tol=1e-10))
    kinematic_phase_space_dimension = 18
    physical_phase_space_dimension = kinematic_phase_space_dimension - 2 * constraint_rank
    omega = np.sqrt(float(momentum @ momentum))
    fock = fock_certificate(omega=omega)
    convergence = dispersion_convergence_certificate()
    residue_rank = int(np.linalg.matrix_rank(propagator_residue(momentum), tol=1e-10))
    return {
        "boundary_conditions": "periodic spatial three-torus",
        "background": "Minkowski",
        "projector_idempotence_error": float(np.linalg.norm(projector @ projector - projector)),
        "projector_symmetry_error": float(np.linalg.norm(projector - projector.T)),
        "projector_eigenvalues": eigenvalues.tolist(),
        "tt_rank": int(np.linalg.matrix_rank(projector, tol=1e-10)),
        "propagator_residue_rank": residue_rank,
        "maximum_transversality_error": float(transversality),
        "maximum_trace_error": float(trace_error),
        "constraint_algebra": algebra,
        "independent_first_class_constraints": constraint_rank,
        "kinematic_phase_space_dimension_per_nonzero_mode": kinematic_phase_space_dimension,
        "physical_phase_space_dimension_per_nonzero_mode": physical_phase_space_dimension,
        "physical_configuration_degrees_of_freedom": physical_phase_space_dimension // 2,
        "microscopic_cutoff_scale_mu": 1.0 / spacing,
        "fock_sector": fock,
        "dispersion_convergence": convergence,
        "anisotropy_correction_ratio_axis_to_diagonal": anisotropy_prediction_coefficient_ratio(),
        "pass": bool(
            np.linalg.norm(projector @ projector - projector) < 1e-12
            and np.linalg.norm(projector - projector.T) < 1e-12
            and np.linalg.matrix_rank(projector, tol=1e-10) == 2
            and residue_rank == 2
            and transversality < 1e-11
            and trace_error < 1e-11
            and algebra["pass"]
            and constraint_rank == 7
            and physical_phase_space_dimension == 4
            and fock["pass"]
            and convergence["pass"]
        ),
        "scope": (
            "A complete quantum Hilbert-space/constraint/propagator construction for linearized 3+1 gravity only. "
            "The nonlinear Hamiltonian-constraint commutator with structure functions remains open."
        ),
    }


def frozen_microtheory_manifest() -> dict[str, Any]:
    """Exact preregistration payload for the v2.3 linearized quantum sector."""
    return {
        "name": "CH-LQG3 linearized periodic microtheory",
        "spatial_dimension": 3,
        "time": "continuous Hamiltonian evolution",
        "boundary_conditions": "periodic spatial three-torus",
        "background": "flat triad / Minkowski spacetime",
        "canonical_variables": "q_ai, p_ai with [q_ai,p_bj]=i*hbar delta_ab delta_ij",
        "constraints": {
            "Gauss": "G_a=epsilon_(a b i) p_(b i)",
            "diffeomorphism": "D_i=-2 k_j p_(i j,sym)",
            "Hamiltonian": "H=(k_i k_j-k^2 delta_ij) q_(i j,sym)",
        },
        "physical_projector": "Lambda_TT(h)=P h P-(1/2)P Tr(P h P)",
        "micro_hamiltonian": "H_micro=sum_(k,s=+,x) hbar omega_hat(k) (a^dagger a+1/2)",
        "dispersion": "omega_hat(k)^2=(4/a^2) sum_i sin^2(k_i a/2)",
        "cutoff_scale": "mu=1/a",
        "inner_product": "positive Fock inner product on TT modes",
        "propagator": "i Lambda_TT/(omega^2-omega_hat(k)^2+i epsilon)",
        "free_parameters": ["lattice spacing a", "hbar", "finite Fock cutoff used only numerically"],
        "non_claims": [
            "not nonlinear 3+1 gravity",
            "not a derivation of Newton constant",
            "not a solution of the structure-function operator algebra",
        ],
    }
