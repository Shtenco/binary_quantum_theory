"""Off-shell nonlinear 3+1 ADM hypersurface-deformation algebra certificate.

This module numerically verifies the *classical* ADM bracket on a periodic
three-torus for smooth off-shell metric and momentum fields.  It also performs
a death test of the generalized DeWitt kinetic supermetric coefficient lambda:
the standard three-dimensional value lambda=1/2 closes, while nearby values do
not.

The calculation is a nonlinear classical target for future operator
quantization.  It is not itself a quantum commutator calculation.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np


SQRT2 = np.sqrt(2.0)


def _symmetric_basis() -> np.ndarray:
    basis = []
    for i in range(3):
        matrix = np.zeros((3, 3), dtype=float)
        matrix[i, i] = 1.0
        basis.append(matrix)
    for i, j in ((0, 1), (0, 2), (1, 2)):
        matrix = np.zeros((3, 3), dtype=float)
        matrix[i, j] = matrix[j, i] = 1.0 / SQRT2
        basis.append(matrix)
    return np.asarray(basis)


SYMMETRIC_BASIS = _symmetric_basis()


def vectors_to_tensors(values: np.ndarray) -> np.ndarray:
    return np.einsum("...a,aij->...ij", values, SYMMETRIC_BASIS)


def tensors_to_vectors(values: np.ndarray) -> np.ndarray:
    return np.einsum("...ij,aij->...a", values, SYMMETRIC_BASIS)


def spectral_derivative(values: np.ndarray, axis: int, length: float = 2.0 * np.pi) -> np.ndarray:
    count = values.shape[axis]
    wave_numbers = 2.0 * np.pi * np.fft.fftfreq(count, d=length / count)
    shape = [1] * values.ndim
    shape[axis] = count
    derivative = np.fft.ifft(
        1j * wave_numbers.reshape(shape) * np.fft.fft(values, axis=axis),
        axis=axis,
    )
    if np.isrealobj(values):
        return derivative.real
    return derivative


def spatial_geometry(metric_vectors: np.ndarray) -> tuple[np.ndarray, ...]:
    metric = vectors_to_tensors(metric_vectors)
    inverse = np.linalg.inv(metric)
    determinant = np.linalg.det(metric)
    if np.any(determinant <= 0):
        raise ValueError("metric must be positive definite")
    sqrt_metric = np.sqrt(determinant)
    derivatives = np.asarray([spectral_derivative(metric, axis) for axis in range(3)])

    gamma = np.zeros(metric.shape[:-2] + (3, 3, 3), dtype=metric.dtype)
    for upper in range(3):
        for left in range(3):
            for right in range(3):
                value = 0.0
                for contracted in range(3):
                    value = value + inverse[..., upper, contracted] * (
                        derivatives[left, ..., contracted, right]
                        + derivatives[right, ..., contracted, left]
                        - derivatives[contracted, ..., left, right]
                    )
                gamma[..., upper, left, right] = 0.5 * value

    gamma_derivatives = np.asarray([spectral_derivative(gamma, axis) for axis in range(3)])
    ricci = np.zeros_like(metric)
    for left in range(3):
        for right in range(3):
            value = 0.0
            for contracted in range(3):
                value = value + gamma_derivatives[contracted, ..., contracted, left, right]
                value = value - gamma_derivatives[right, ..., contracted, left, contracted]
                for second in range(3):
                    value = value + gamma[..., contracted, left, right] * gamma[..., second, contracted, second]
                    value = value - gamma[..., second, left, contracted] * gamma[..., contracted, right, second]
            ricci[..., left, right] = value
    scalar_curvature = np.einsum("...ij,...ij->...", inverse, ricci)
    return metric, inverse, sqrt_metric, gamma, scalar_curvature


def adm_hamiltonian(
    metric_vectors: np.ndarray,
    momentum_vectors: np.ndarray,
    lapse: np.ndarray,
    dewitt_lambda: float = 0.5,
    length: float = 2.0 * np.pi,
) -> float:
    grid_size = metric_vectors.shape[0]
    spacing = length / grid_size
    metric, _, sqrt_metric, _, scalar_curvature = spatial_geometry(metric_vectors)
    momentum = vectors_to_tensors(momentum_vectors)
    momentum_lower = np.einsum("...ia,...jb,...ab->...ij", metric, metric, momentum)
    momentum_squared = np.einsum("...ij,...ij->...", momentum, momentum_lower)
    momentum_trace = np.einsum("...ij,...ij->...", metric, momentum)
    density = (
        momentum_squared - dewitt_lambda * momentum_trace**2
    ) / sqrt_metric - sqrt_metric * scalar_curvature
    return float(spacing**3 * np.sum(lapse * density))


def analytic_momentum_gradient(
    metric_vectors: np.ndarray,
    momentum_vectors: np.ndarray,
    lapse: np.ndarray,
    dewitt_lambda: float = 0.5,
    length: float = 2.0 * np.pi,
) -> np.ndarray:
    grid_size = metric_vectors.shape[0]
    spacing = length / grid_size
    metric, _, sqrt_metric, _, _ = spatial_geometry(metric_vectors)
    momentum = vectors_to_tensors(momentum_vectors)
    momentum_lower = np.einsum("...ia,...jb,...ab->...ij", metric, metric, momentum)
    momentum_trace = np.einsum("...ij,...ij->...", metric, momentum)
    tensor_gradient = (
        2.0
        * spacing**3
        * lapse[..., None, None]
        / sqrt_metric[..., None, None]
        * (momentum_lower - dewitt_lambda * momentum_trace[..., None, None] * metric)
    )
    return tensors_to_vectors(tensor_gradient)


def finite_difference_metric_gradient(
    metric_vectors: np.ndarray,
    momentum_vectors: np.ndarray,
    lapse: np.ndarray,
    dewitt_lambda: float = 0.5,
    length: float = 2.0 * np.pi,
    step: float = 1e-5,
) -> np.ndarray:
    if step <= 0:
        raise ValueError("step must be positive")
    gradient = np.empty_like(metric_vectors)
    plus = metric_vectors.copy().reshape(-1)
    minus = metric_vectors.copy().reshape(-1)
    output = gradient.reshape(-1)
    for index in range(plus.size):
        plus[index] += step
        minus[index] -= step
        output[index] = (
            adm_hamiltonian(plus.reshape(metric_vectors.shape), momentum_vectors, lapse, dewitt_lambda, length)
            - adm_hamiltonian(minus.reshape(metric_vectors.shape), momentum_vectors, lapse, dewitt_lambda, length)
        ) / (2.0 * step)
        plus[index] -= step
        minus[index] += step
    return gradient


def adm_diffeomorphism(
    metric_vectors: np.ndarray,
    momentum_vectors: np.ndarray,
    shift: np.ndarray,
    length: float = 2.0 * np.pi,
) -> float:
    grid_size = metric_vectors.shape[0]
    spacing = length / grid_size
    metric, _, _, gamma, _ = spatial_geometry(metric_vectors)
    momentum = vectors_to_tensors(momentum_vectors)
    divergence = np.zeros(metric_vectors.shape[:-1] + (3,), dtype=float)
    for upper in range(3):
        value = 0.0
        for derivative_index in range(3):
            value = value + spectral_derivative(momentum[..., derivative_index, upper], derivative_index)
            for contracted in range(3):
                value = value + gamma[..., upper, derivative_index, contracted] * momentum[..., derivative_index, contracted]
        divergence[..., upper] = value
    covariant_density = -2.0 * np.einsum("...ik,...k->...i", metric, divergence)
    return float(spacing**3 * np.sum(shift * covariant_density))


def _smooth_scalar(grid_size: int, rng: np.random.Generator, amplitude: float) -> np.ndarray:
    coordinates = np.arange(grid_size) * 2.0 * np.pi / grid_size
    x, y, z = np.meshgrid(coordinates, coordinates, coordinates, indexing="ij")
    value = np.zeros((grid_size, grid_size, grid_size), dtype=float)
    for coordinate in (x, y, z):
        value += rng.normal() * np.sin(coordinate) + rng.normal() * np.cos(coordinate)
    return amplitude * value / 3.0


def smooth_off_shell_configuration(grid_size: int = 4, seed: int = 2) -> tuple[np.ndarray, ...]:
    if grid_size < 3:
        raise ValueError("grid_size must be >=3")
    rng = np.random.default_rng(seed)
    metric = np.zeros((grid_size, grid_size, grid_size, 6), dtype=float)
    metric[..., :3] = 1.0
    for component in range(6):
        metric[..., component] += _smooth_scalar(grid_size, rng, 0.025)
    momentum = np.zeros_like(metric)
    for component in range(6):
        momentum[..., component] = _smooth_scalar(grid_size, rng, 0.03)
    lapse_1 = 1.0 + _smooth_scalar(grid_size, rng, 0.1)
    lapse_2 = 0.7 + _smooth_scalar(grid_size, rng, 0.1)
    return metric, momentum, lapse_1, lapse_2


@dataclass(frozen=True)
class ADMHDAClosureTrial:
    grid_size: int
    seed: int
    dewitt_lambda: float
    poisson_bracket: float
    diffeomorphism_constraint: float
    absolute_residual: float
    relative_residual: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def adm_hda_closure_trial(
    grid_size: int = 4,
    seed: int = 2,
    dewitt_lambda: float = 0.5,
    length: float = 2.0 * np.pi,
    finite_difference_step: float = 1e-5,
) -> ADMHDAClosureTrial:
    metric, momentum, lapse_1, lapse_2 = smooth_off_shell_configuration(grid_size, seed)
    metric_gradient_1 = finite_difference_metric_gradient(
        metric, momentum, lapse_1, dewitt_lambda, length, finite_difference_step
    )
    metric_gradient_2 = finite_difference_metric_gradient(
        metric, momentum, lapse_2, dewitt_lambda, length, finite_difference_step
    )
    momentum_gradient_1 = analytic_momentum_gradient(metric, momentum, lapse_1, dewitt_lambda, length)
    momentum_gradient_2 = analytic_momentum_gradient(metric, momentum, lapse_2, dewitt_lambda, length)
    spacing = length / grid_size
    poisson_bracket = float(
        np.sum(metric_gradient_1 * momentum_gradient_2 - momentum_gradient_1 * metric_gradient_2)
        / spacing**3
    )

    _, inverse, _, _, _ = spatial_geometry(metric)
    lapse_1_gradient = np.stack([spectral_derivative(lapse_1, axis) for axis in range(3)], axis=-1)
    lapse_2_gradient = np.stack([spectral_derivative(lapse_2, axis) for axis in range(3)], axis=-1)
    covector = lapse_1[..., None] * lapse_2_gradient - lapse_2[..., None] * lapse_1_gradient
    shift = np.einsum("...ij,...j->...i", inverse, covector)
    expected = adm_diffeomorphism(metric, momentum, shift, length)
    absolute = abs(poisson_bracket - expected)
    relative = absolute / max(1e-30, abs(expected))
    return ADMHDAClosureTrial(
        grid_size=grid_size,
        seed=seed,
        dewitt_lambda=float(dewitt_lambda),
        poisson_bracket=poisson_bracket,
        diffeomorphism_constraint=expected,
        absolute_residual=float(absolute),
        relative_residual=float(relative),
    )


def momentum_gradient_certificate(grid_size: int = 3, seed: int = 4) -> dict[str, Any]:
    metric, momentum, lapse, _ = smooth_off_shell_configuration(grid_size, seed)
    analytic = analytic_momentum_gradient(metric, momentum, lapse)
    numerical = np.empty_like(momentum)
    step = 1e-6
    plus = momentum.copy().reshape(-1)
    minus = momentum.copy().reshape(-1)
    for index in range(plus.size):
        plus[index] += step
        minus[index] -= step
        numerical.reshape(-1)[index] = (
            adm_hamiltonian(metric, plus.reshape(momentum.shape), lapse)
            - adm_hamiltonian(metric, minus.reshape(momentum.shape), lapse)
        ) / (2.0 * step)
        plus[index] -= step
        minus[index] += step
    scale = max(1e-30, float(np.linalg.norm(numerical)))
    relative = float(np.linalg.norm(analytic - numerical) / scale)
    return {"relative_error": relative, "pass": bool(relative < 2e-8)}


def nonlinear_adm_certificate() -> dict[str, Any]:
    closure_trials = [adm_hda_closure_trial(grid_size=size, dewitt_lambda=0.5) for size in (3, 4, 5)]
    wrong_lambda_trials = [
        adm_hda_closure_trial(grid_size=3, dewitt_lambda=value) for value in (0.4, 0.6)
    ]
    gradient = momentum_gradient_certificate()
    residuals = [trial.relative_residual for trial in closure_trials]
    return {
        "standard_dewitt_lambda": 0.5,
        "closure_convergence": [trial.as_dict() for trial in closure_trials],
        "wrong_lambda_death_tests": [trial.as_dict() for trial in wrong_lambda_trials],
        "analytic_momentum_gradient": gradient,
        "best_relative_residual": float(min(residuals)),
        "worst_wrong_lambda_relative_residual": float(min(trial.relative_residual for trial in wrong_lambda_trials)),
        "pass": bool(
            residuals[-1] < 1e-4
            and residuals[-1] < residuals[-2] < residuals[-3]
            and all(trial.relative_residual > 0.5 for trial in wrong_lambda_trials)
            and gradient["pass"]
        ),
        "classification": "nonlinear off-shell classical 3+1 ADM HDA certificate",
        "scope": (
            "Classical Poisson brackets on smooth periodic fields. It fixes the nonlinear classical target "
            "but does not establish an operator representation or quantum anomaly freedom."
        ),
    }
