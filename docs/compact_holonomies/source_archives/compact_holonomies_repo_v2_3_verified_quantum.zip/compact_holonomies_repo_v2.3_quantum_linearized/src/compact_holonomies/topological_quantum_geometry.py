"""Exact 3D commuting-projector holonomy code and its gravity no-go result.

Qubits live on links of a periodic cubic lattice.  Vertex (Gauss) and plaquette
(curvature) stabilizers commute because boundary-of-boundary is zero.  The
physical ground space is nontrivial, but on T^3 it contains only three global
logical qubits and no local graviton polarizations.  This is a useful exact
quantum-geometry laboratory and an explicit warning that exact commuting
projectors alone tend to produce a topological, not GR-like, continuum phase.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

import numpy as np


def gf2_rank(matrix: np.ndarray) -> int:
    a = np.asarray(matrix, dtype=np.uint8).copy() % 2
    rows, cols = a.shape
    rank = 0
    for col in range(cols):
        pivots = np.flatnonzero(a[rank:, col])
        if pivots.size == 0:
            continue
        pivot = rank + int(pivots[0])
        if pivot != rank:
            a[[rank, pivot]] = a[[pivot, rank]]
        for row in range(rows):
            if row != rank and a[row, col]:
                a[row] ^= a[rank]
        rank += 1
        if rank == rows:
            break
    return rank


def _vertex_index(x: int, y: int, z: int, length: int) -> int:
    return (x % length) + length * ((y % length) + length * (z % length))


def _edge_index(x: int, y: int, z: int, direction: int, length: int) -> int:
    return direction + 3 * _vertex_index(x, y, z, length)


def _face_index(x: int, y: int, z: int, orientation: int, length: int) -> int:
    return orientation + 3 * _vertex_index(x, y, z, length)


def cubic_boundary_matrices(length: int) -> tuple[np.ndarray, np.ndarray]:
    """Return d1:C1->C0 and d2:C2->C1 over GF(2) on a periodic cubic complex."""
    if length < 2:
        raise ValueError("length must be >=2")
    vertices = length**3
    edges = 3 * vertices
    faces = 3 * vertices
    d1 = np.zeros((vertices, edges), dtype=np.uint8)
    d2 = np.zeros((edges, faces), dtype=np.uint8)

    unit = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    for x in range(length):
        for y in range(length):
            for z in range(length):
                coordinates = (x, y, z)
                for direction, step in enumerate(unit):
                    edge = _edge_index(x, y, z, direction, length)
                    start = _vertex_index(x, y, z, length)
                    end = _vertex_index(x + step[0], y + step[1], z + step[2], length)
                    d1[start, edge] ^= 1
                    d1[end, edge] ^= 1

                # orientations: xy, xz, yz
                for orientation, (mu, nu) in enumerate(((0, 1), (0, 2), (1, 2))):
                    face = _face_index(x, y, z, orientation, length)
                    emu = unit[mu]
                    enu = unit[nu]
                    boundary_edges = (
                        _edge_index(x, y, z, mu, length),
                        _edge_index(x + emu[0], y + emu[1], z + emu[2], nu, length),
                        _edge_index(x + enu[0], y + enu[1], z + enu[2], mu, length),
                        _edge_index(x, y, z, nu, length),
                    )
                    for edge in boundary_edges:
                        d2[edge, face] ^= 1
    return d1, d2


@dataclass(frozen=True)
class TopologicalGeometryCertificate:
    lattice_length: int
    vertices: int
    edge_qubits: int
    plaquettes: int
    gauss_rank: int
    curvature_rank: int
    logical_qubits: int
    ground_state_degeneracy: int
    boundary_of_boundary_weight: int
    local_graviton_polarizations: int
    pass_exact_code: bool
    gravity_continuum_pass: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def topological_geometry_certificate(length: int = 3) -> TopologicalGeometryCertificate:
    d1, d2 = cubic_boundary_matrices(length)
    boundary_of_boundary = (d1 @ d2) % 2
    gauss_rank = gf2_rank(d1)
    curvature_rank = gf2_rank(d2)
    edge_qubits = d1.shape[1]
    logical = edge_qubits - gauss_rank - curvature_rank
    # Three global Wilson-loop qubits on the spatial three-torus.
    degeneracy = 2**logical
    return TopologicalGeometryCertificate(
        lattice_length=length,
        vertices=length**3,
        edge_qubits=edge_qubits,
        plaquettes=d2.shape[1],
        gauss_rank=gauss_rank,
        curvature_rank=curvature_rank,
        logical_qubits=logical,
        ground_state_degeneracy=degeneracy,
        boundary_of_boundary_weight=int(np.count_nonzero(boundary_of_boundary)),
        local_graviton_polarizations=0,
        pass_exact_code=bool(
            np.count_nonzero(boundary_of_boundary) == 0
            and logical == 3
            and degeneracy == 8
        ),
        gravity_continuum_pass=False,
    )


def topological_geometry_suite(lengths: tuple[int, ...] = (2, 3, 4)) -> dict[str, Any]:
    certificates = [topological_geometry_certificate(length) for length in lengths]
    return {
        "trials": [certificate.as_dict() for certificate in certificates],
        "all_exact_codes_pass": all(certificate.pass_exact_code for certificate in certificates),
        "all_have_three_global_logical_qubits": all(certificate.logical_qubits == 3 for certificate in certificates),
        "gravity_verdict": (
            "FAIL as a GR continuum candidate: the exact commuting-projector phase has only global topological "
            "qubits and zero local tensor polarizations. Noncommuting dynamics or a critical gapless phase is required."
        ),
    }
