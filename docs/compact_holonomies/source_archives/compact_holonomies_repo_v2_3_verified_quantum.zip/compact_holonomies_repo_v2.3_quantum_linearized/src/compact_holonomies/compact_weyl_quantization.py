"""Finite compact Weyl quantization and the finite-dimensional CCR no-go.

Compact holonomy/flux variables admit an exact finite-dimensional Weyl algebra,
while an exact canonical commutator [q,p]=i hbar I cannot exist in finite
dimension because the trace of every commutator vanishes.  This module makes
that distinction explicit and machine-verifiable.
"""
from __future__ import annotations

from typing import Any

import numpy as np


def finite_weyl_pair(dimension: int) -> tuple[np.ndarray, np.ndarray, complex]:
    if dimension < 2:
        raise ValueError("dimension must be >=2")
    omega = np.exp(2j * np.pi / dimension)
    clock = np.diag(omega ** np.arange(dimension))
    shift = np.zeros((dimension, dimension), dtype=complex)
    for n in range(dimension):
        shift[(n + 1) % dimension, n] = 1.0
    return clock, shift, omega


def compact_laplacian_from_shift(shift: np.ndarray, delta: float = 1.0) -> np.ndarray:
    if delta <= 0:
        raise ValueError("delta must be positive")
    shift = np.asarray(shift, dtype=complex)
    if shift.ndim != 2 or shift.shape[0] != shift.shape[1]:
        raise ValueError("shift must be square")
    identity = np.eye(shift.shape[0], dtype=complex)
    return (2.0 * identity - shift - shift.conj().T) / delta**2


def finite_dimensional_ccr_no_go(dimension: int, hbar: float = 1.0) -> dict[str, Any]:
    if dimension < 1 or hbar <= 0:
        raise ValueError("dimension and hbar must be positive")
    # For arbitrary finite matrices Q,P, Tr([Q,P])=0 by cyclicity.
    trace_any_commutator = 0j
    target_trace = 1j * hbar * dimension
    return {
        "dimension": dimension,
        "trace_of_any_finite_commutator": [trace_any_commutator.real, trace_any_commutator.imag],
        "trace_of_i_hbar_identity": [target_trace.real, target_trace.imag],
        "trace_mismatch_magnitude": float(abs(target_trace - trace_any_commutator)),
        "exact_finite_dimensional_CCR_possible": False,
        "conclusion": (
            "An exact [Q,P]=i hbar I representation requires an infinite-dimensional Hilbert space. "
            "Finite compact models must use the exponentiated Weyl algebra instead."
        ),
    }


def compact_weyl_certificate(dimension: int = 17, delta: float = 0.4) -> dict[str, Any]:
    clock, shift, omega = finite_weyl_pair(dimension)
    identity = np.eye(dimension, dtype=complex)
    weyl_error = np.linalg.norm(clock @ shift - omega * shift @ clock)
    clock_unitarity = np.linalg.norm(clock.conj().T @ clock - identity)
    shift_unitarity = np.linalg.norm(shift.conj().T @ shift - identity)
    periodicity = max(
        np.linalg.norm(np.linalg.matrix_power(clock, dimension) - identity),
        np.linalg.norm(np.linalg.matrix_power(shift, dimension) - identity),
    )
    laplacian = compact_laplacian_from_shift(shift, delta)
    numerical = np.sort(np.linalg.eigvalsh(laplacian).real)
    modes = np.arange(dimension)
    analytic = np.sort(4.0 * np.sin(np.pi * modes / dimension) ** 2 / delta**2)
    spectral_error = np.max(np.abs(numerical - analytic))
    no_go = finite_dimensional_ccr_no_go(dimension)
    return {
        "dimension": dimension,
        "root_of_unity": [float(omega.real), float(omega.imag)],
        "weyl_relation_error": float(weyl_error),
        "clock_unitarity_error": float(clock_unitarity),
        "shift_unitarity_error": float(shift_unitarity),
        "periodicity_error": float(periodicity),
        "compact_laplacian_spectral_error": float(spectral_error),
        "finite_CCR_no_go": no_go,
        "pass": bool(
            weyl_error < 1e-12
            and clock_unitarity < 1e-12
            and shift_unitarity < 1e-12
            and periodicity < 1e-11
            and spectral_error < 1e-12
            and not no_go["exact_finite_dimensional_CCR_possible"]
        ),
    }
