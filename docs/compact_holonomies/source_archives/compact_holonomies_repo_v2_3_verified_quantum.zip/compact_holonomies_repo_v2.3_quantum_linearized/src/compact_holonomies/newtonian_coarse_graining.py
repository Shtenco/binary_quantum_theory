"""Coarse-grained Newtonian kernel from the same compact lattice Laplacian.

The calculation is parameter free after choosing lattice spacing and volume.
It demonstrates the expected Green-function crossover to 1/r and force to
1/r^2 in three spatial dimensions.  Newton's constant remains an input
normalization; this is not a derivation of G.
"""
from __future__ import annotations

from typing import Any

import numpy as np


def periodic_lattice_green_function(size: int = 96, spacing: float = 1.0) -> np.ndarray:
    if size < 16 or spacing <= 0:
        raise ValueError("size must be >=16 and spacing positive")
    wave = 2.0 * np.pi * np.fft.fftfreq(size)
    sine_squared = np.sin(0.5 * wave) ** 2
    eigenvalues = (4.0 / spacing**2) * (
        sine_squared[:, None, None]
        + sine_squared[None, :, None]
        + sine_squared[None, None, :]
    )
    inverse = np.zeros_like(eigenvalues)
    mask = eigenvalues > 1e-15
    inverse[mask] = 1.0 / eigenvalues[mask]
    return np.fft.ifftn(inverse).real


def axial_force_profile(
    size: int = 96, spacing: float = 1.0, r_min: int = 5, r_max: int = 14
) -> tuple[np.ndarray, np.ndarray]:
    if not (1 <= r_min < r_max < size // 2):
        raise ValueError("invalid radial interval")
    green = periodic_lattice_green_function(size, spacing)
    radii = np.arange(r_min, r_max + 1, dtype=int)
    force = np.array(
        [(green[r, 0, 0] - green[r + 1, 0, 0]) / spacing for r in radii],
        dtype=float,
    )
    return (radii.astype(float) + 0.5) * spacing, force


def newtonian_coarse_graining_certificate(
    size: int = 96, spacing: float = 1.0, r_min: int = 5, r_max: int = 14
) -> dict[str, Any]:
    radius, force = axial_force_profile(size, spacing, r_min, r_max)
    continuum_force = 1.0 / (4.0 * np.pi * radius**2)
    relative = (force - continuum_force) / continuum_force
    slope, intercept = np.polyfit(np.log(radius), np.log(force), 1)
    exponent = -float(slope)
    amplitude = float(np.exp(intercept))
    return {
        "lattice_size": size,
        "spacing": spacing,
        "radius_midpoints": radius.tolist(),
        "lattice_force": force.tolist(),
        "continuum_force": continuum_force.tolist(),
        "effective_power_exponent": exponent,
        "fitted_amplitude": amplitude,
        "continuum_amplitude": float(1.0 / (4.0 * np.pi)),
        "maximum_relative_error": float(np.max(np.abs(relative))),
        "mean_relative_error": float(np.mean(np.abs(relative))),
        "pass": bool(abs(exponent - 2.0) < 0.08 and np.max(np.abs(relative)) < 0.05),
        "scope": (
            "Emergence of the three-dimensional massless Green kernel from a fixed lattice Laplacian. "
            "The normalization G and nonlinear Einstein dynamics are not derived."
        ),
    }
