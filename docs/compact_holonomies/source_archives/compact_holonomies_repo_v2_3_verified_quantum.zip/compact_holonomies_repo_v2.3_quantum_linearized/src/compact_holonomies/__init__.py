"""Compact holonomies research utilities.

Exact identities, controlled EFT assumptions, anomaly-free reduced dynamics,
and prediction audits are kept separate by design.
"""

from .effective_foam_eft import (
    EFTParameters,
    HolonomyCorrection,
    barrier_action,
    tunneling_amplitude,
    tunneling_probability,
    foam_corrected_barrier,
    phase_decoherence_factor,
    planck_suppression,
)
from .anomaly_free_spherical import (
    beta,
    canonical_holonomy_chart,
    closure_convergence,
    continuum_closure_trial,
    f1,
    f2,
    signature_change_threshold,
    symbolic_certificate,
)
from .micro_spectrum import (
    analytic_eigenvalues,
    compact_laplacian,
    run_blind_spectrum_test,
    universal_series_ratio,
)

__all__ = [
    "EFTParameters",
    "HolonomyCorrection",
    "barrier_action",
    "tunneling_amplitude",
    "tunneling_probability",
    "foam_corrected_barrier",
    "phase_decoherence_factor",
    "planck_suppression",
    "f1",
    "f2",
    "beta",
    "signature_change_threshold",
    "canonical_holonomy_chart",
    "symbolic_certificate",
    "continuum_closure_trial",
    "closure_convergence",
    "compact_laplacian",
    "analytic_eigenvalues",
    "run_blind_spectrum_test",
    "universal_series_ratio",
]

from .chiral_overlap import (
    chiral_certificate,
    chiral_flux_suite,
    overlap_dirac_operator,
    overlap_index,
    uniform_u1_flux_links,
)
from .anomaly_free_matter import (
    minimal_hypercharge_solution,
    right_neutrino_family,
    symbolic_hypercharge_certificate,
)
from .renormalization_group import (
    rg_certificate,
    standard_model_one_loop_beta_coefficients,
)
from .free_overlap_4d import free_overlap_4d_certificate, free_overlap_block

__all__.extend([
    "chiral_certificate",
    "chiral_flux_suite",
    "overlap_dirac_operator",
    "overlap_index",
    "uniform_u1_flux_links",
    "minimal_hypercharge_solution",
    "right_neutrino_family",
    "symbolic_hypercharge_certificate",
    "rg_certificate",
    "standard_model_one_loop_beta_coefficients",
    "free_overlap_4d_certificate",
    "free_overlap_block",
])

from .topological_generations import generation_certificate, three_generation_suite
from .unification_stress import (
    CouplingBenchmark,
    fermion_trace_normalizations,
    minimal_unification_stress_certificate,
    spectral_coupling_certificate,
)
from .generation_selection import generation_selection_certificate
from .flavor_no_go import constant_higgs_flavor_certificate

__all__.extend([
    "generation_certificate",
    "three_generation_suite",
    "CouplingBenchmark",
    "fermion_trace_normalizations",
    "minimal_unification_stress_certificate",
    "spectral_coupling_certificate",
    "generation_selection_certificate",
    "constant_higgs_flavor_certificate",
])

from .linearized_quantum_gravity import (
    anisotropy_prediction_coefficient_ratio,
    dispersion_convergence_certificate,
    fock_certificate,
    frozen_microtheory_manifest,
    lattice_dispersion,
    lattice_momentum,
    linearized_quantum_gravity_certificate,
    propagator_residue,
    quantum_constraint_algebra_certificate,
    thermal_partition_function,
    tt_projector,
)
from .newtonian_coarse_graining import newtonian_coarse_graining_certificate
from .topological_quantum_geometry import (
    topological_geometry_certificate,
    topological_geometry_suite,
)

__all__.extend([
    "anisotropy_prediction_coefficient_ratio",
    "dispersion_convergence_certificate",
    "fock_certificate",
    "frozen_microtheory_manifest",
    "lattice_dispersion",
    "lattice_momentum",
    "linearized_quantum_gravity_certificate",
    "propagator_residue",
    "quantum_constraint_algebra_certificate",
    "thermal_partition_function",
    "tt_projector",
    "newtonian_coarse_graining_certificate",
    "topological_geometry_certificate",
    "topological_geometry_suite",
])
from .compact_weyl_quantization import (
    compact_weyl_certificate,
    finite_dimensional_ccr_no_go,
    finite_weyl_pair,
)

__all__.extend([
    "compact_weyl_certificate",
    "finite_dimensional_ccr_no_go",
    "finite_weyl_pair",
])
from .adm_nonlinear_hda import (
    adm_hda_closure_trial,
    nonlinear_adm_certificate,
)

__all__.extend([
    "adm_hda_closure_trial",
    "nonlinear_adm_certificate",
])
