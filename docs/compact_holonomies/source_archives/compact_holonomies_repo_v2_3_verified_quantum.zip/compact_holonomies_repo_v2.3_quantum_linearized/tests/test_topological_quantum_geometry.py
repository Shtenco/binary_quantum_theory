from compact_holonomies.topological_quantum_geometry import (
    cubic_boundary_matrices,
    topological_geometry_certificate,
    topological_geometry_suite,
)


def test_boundary_of_boundary_is_zero():
    d1, d2 = cubic_boundary_matrices(3)
    assert ((d1 @ d2) % 2).sum() == 0


def test_three_torus_ground_space_has_three_logical_qubits():
    certificate = topological_geometry_certificate(3)
    assert certificate.pass_exact_code
    assert certificate.logical_qubits == 3
    assert certificate.ground_state_degeneracy == 8
    assert certificate.local_graviton_polarizations == 0
    assert not certificate.gravity_continuum_pass


def test_topological_result_is_size_independent():
    suite = topological_geometry_suite((2, 3, 4))
    assert suite["all_exact_codes_pass"]
    assert suite["all_have_three_global_logical_qubits"]
