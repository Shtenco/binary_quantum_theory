from compact_holonomies.newtonian_coarse_graining import newtonian_coarse_graining_certificate


def test_three_dimensional_lattice_green_function_recovers_inverse_square_force():
    certificate = newtonian_coarse_graining_certificate(size=64, r_min=5, r_max=10)
    assert certificate["pass"]
    assert abs(certificate["effective_power_exponent"] - 2.0) < 0.08
    assert certificate["maximum_relative_error"] < 0.05
