import hashlib
import json
from pathlib import Path

from compact_holonomies.linearized_quantum_gravity import frozen_microtheory_manifest


def test_frozen_quantum_microtheory_manifest_matches_executable_definition():
    root = Path(__file__).resolve().parents[1]
    manifest = root / "preregistration" / "QUANTUM_LINEARIZED_MICROTHEORY_v2.3.json"
    expected = json.dumps(frozen_microtheory_manifest(), indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    assert manifest.read_text(encoding="utf-8") == expected
    digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
    registered = (root / "preregistration" / "QUANTUM_LINEARIZED_MICROTHEORY_v2.3.sha256").read_text().split()[0]
    assert digest == registered
