import numpy as np

from compact_holonomies.linearized_quantum_gravity import (
    anisotropy_prediction_coefficient_ratio,
    dispersion_convergence_certificate,
    fock_certificate,
    lattice_momentum,
    linearized_quantum_gravity_certificate,
    propagator_residue,
    quantum_constraint_algebra_certificate,
    thermal_partition_function,
    tt_projector,
)


def test_tt_projector_has_exactly_two_physical_modes():
    momentum = lattice_momentum((1, 2, 3), (24, 24, 24), 0.3)
    projector = tt_projector(momentum)
    assert np.linalg.norm(projector @ projector - projector) < 1e-12
    assert np.linalg.norm(projector - projector.T) < 1e-12
    assert np.linalg.matrix_rank(projector, tol=1e-10) == 2
    assert np.linalg.matrix_rank(propagator_residue(momentum), tol=1e-10) == 2


def test_linearized_quantum_constraints_commute_exactly():
    momentum = np.array([0.7, -0.2, 1.1])
    certificate = quantum_constraint_algebra_certificate(momentum)
    assert certificate["pass"]
    assert certificate["max_absolute_commutator_coefficient"] < 1e-13


def test_physical_fock_space_is_unitary_and_positive():
    certificate = fock_certificate(cutoff=5, omega=0.83, time=0.37)
    assert certificate["pass"]
    assert certificate["physical_polarizations"] == 2
    assert certificate["positive_inner_product"]


def test_lattice_graviton_dispersion_has_second_order_continuum_limit():
    certificate = dispersion_convergence_certificate()
    assert certificate["pass"]
    assert certificate["minimum_observed_order"] > 1.95
    assert anisotropy_prediction_coefficient_ratio() == 3.0


def test_partition_function_is_two_oscillator_result():
    beta, omega = 1.3, 0.7
    x = np.exp(-beta * omega)
    expected = np.exp(-beta * omega) / (1.0 - x) ** 2
    assert np.isclose(thermal_partition_function(beta, omega), expected)


def test_full_linearized_quantum_certificate():
    certificate = linearized_quantum_gravity_certificate()
    assert certificate["pass"]
    assert certificate["tt_rank"] == 2
    assert certificate["constraint_algebra"]["pass"]
