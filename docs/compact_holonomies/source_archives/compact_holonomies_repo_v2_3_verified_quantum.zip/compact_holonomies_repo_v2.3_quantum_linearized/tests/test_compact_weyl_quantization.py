from compact_holonomies.compact_weyl_quantization import (
    compact_weyl_certificate,
    finite_dimensional_ccr_no_go,
)


def test_exact_finite_weyl_algebra_and_compact_spectrum():
    certificate = compact_weyl_certificate(19, 0.37)
    assert certificate["pass"]
    assert certificate["weyl_relation_error"] < 1e-12
    assert certificate["compact_laplacian_spectral_error"] < 1e-12


def test_exact_finite_canonical_commutator_is_impossible():
    result = finite_dimensional_ccr_no_go(11, 0.8)
    assert not result["exact_finite_dimensional_CCR_possible"]
    assert result["trace_mismatch_magnitude"] == 8.8
