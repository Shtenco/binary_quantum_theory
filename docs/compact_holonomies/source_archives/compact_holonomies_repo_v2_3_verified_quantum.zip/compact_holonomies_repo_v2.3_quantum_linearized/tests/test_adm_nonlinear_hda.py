from compact_holonomies.adm_nonlinear_hda import (
    adm_hda_closure_trial,
    momentum_gradient_certificate,
)


def test_analytic_momentum_gradient_matches_finite_difference():
    certificate = momentum_gradient_certificate(grid_size=3, seed=4)
    assert certificate["pass"]
    assert certificate["relative_error"] < 2e-8


def test_nonlinear_adm_hda_closes_off_shell_for_standard_dewitt_metric():
    trial = adm_hda_closure_trial(grid_size=3, seed=2, dewitt_lambda=0.5)
    assert trial.relative_residual < 0.03


def test_wrong_dewitt_supermetric_coefficients_fail_closure():
    low = adm_hda_closure_trial(grid_size=3, seed=2, dewitt_lambda=0.4)
    high = adm_hda_closure_trial(grid_size=3, seed=2, dewitt_lambda=0.6)
    assert low.relative_residual > 0.5
    assert high.relative_residual > 0.5
