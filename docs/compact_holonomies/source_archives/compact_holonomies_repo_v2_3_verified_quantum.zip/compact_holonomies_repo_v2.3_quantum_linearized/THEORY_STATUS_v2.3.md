# Theory status v2.3

## Что доказано в коде

1. Компактные голономные тождества и контролируемый классический предел.
2. Замыкание вакуумного сферического effective HDA-сектора.
3. Нелинейное off-shell замыкание классической ADM HDA в 3+1 при
   `lambda=1/2`, с grid convergence.
4. Точная абелианизированная операторная алгебра ограничений линейной 3+1
   гравитации.
5. Две физические TT-моды, положительный Fock inner product, unitary
   Hamiltonian evolution, propagator and partition function.
6. Точная finite Weyl algebra для компактных переменных.
7. Топологический no-go для простого commuting-projector continuum.
8. Киральные overlap-секторы, anomaly constraints и ранее опубликованные
   отрицательные тесты flavor/unification.

## Что не доказано

1. Нелинейная операторная HDA полной 3+1 теории.
2. Совместное ядро нелинейных quantum constraints.
3. Regulator-independent continuum quantum measure.
4. Динамический вывод Einstein-Hilbert EFT из microscopic path integral.
5. Абсолютные `G`, `Lambda`, gauge couplings, masses, CKM/PMNS.
6. Успешное новое внешнее количественное предсказание.

## Текущая классификация

Не «завершённая квантовая гравитация», а:

> контролируемый квантовый линейный 3+1 сектор, встроенный в
> компактно-голономную исследовательскую программу, с отдельно проверенной
> нелинейной классической ADM-алгеброй.

## Следующая обязательная задача

Построить регуляризованные нелинейные операторы

\[
\hat G[\Lambda],\quad
\hat D[\vec N],\quad
\hat H[N]
\]

на одном Weyl/spin-network Hilbert space и проверить

\[
\frac{1}{i\hbar}
[\hat H[N],\hat H[M]]
=
\hat D[\widehat{g^{ij}(N\partial_jM-M\partial_jN)}]
+
\hat G[\cdots]
+
O(a^p,\hbar^2)
\]

на заранее замороженном наборе off-shell semiclassical states. Изменение
ordering или counterterms после раскрытия holdout должно запрещаться.
