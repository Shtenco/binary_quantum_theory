#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / "preregistration/FUTURE_BLIND_PREDICTIONS_v2.3.json"
manifest = {
    "version": "2.3.0",
    "frozen_predictions": [
        {
            "id": "F001",
            "prediction": "Exactly two luminal tensor modes around Minkowski in the minimal curvature-cubed completion.",
            "formula": "N_TT=2; c_gw/c=1; omega^2=k^2 at quadratic order",
            "allowed_refutation": "A robust extra tensor polarization or vacuum linear dispersion inconsistent with source effects refutes this completion.",
        },
        {
            "id": "F002",
            "prediction": "Vacuum spherical structure function beta crosses zero first at |delta K_phi|=pi/4.",
            "formula": "beta=cos(2 delta K_phi)",
            "allowed_refutation": "A derivation from the same fixed f1 showing a different beta refutes the sector implementation.",
        },
        {
            "id": "F003",
            "prediction": "The fixed compact shift spectrum has c6/c4^2=2/5.",
            "formula": "4 sin^2(q/2)=q^2-q^4/12+q^6/360+...",
            "allowed_refutation": "Independent diagonalization of the registered operator disagreeing beyond numerical tolerance refutes the implementation.",
        },
        {
            "id": "F004",
            "prediction": "For the registered uniform-flux convention, the overlap index equals minus the integer U(1) flux.",
            "formula": "index(D_ov)=Tr gamma5(1-a D_ov/(2 rho))=-Q",
            "allowed_refutation": "A nonsingular admissible challenge in the registered lattice family producing a noninteger index or index != -Q refutes the implementation.",
        },
        {
            "id": "F005",
            "prediction": "The free 4D overlap operator has only the p=0 massless Brillouin corner for 0<rho<2r.",
            "formula": "D_ov(0)=0; sigma_min[D_ov(p_corner)]=2 rho/a for every nonzero pi-corner",
            "allowed_refutation": "Any additional zero at a nonzero Brillouin corner in the stated parameter interval refutes the implementation.",
        },
        {
            "id": "F006",
            "prediction": "In the registered overlap flux family, the chiral zero-mode multiplicity equals |Q|.",
            "formula": "N_zero=|index(D_ov)|=|Q|",
            "allowed_refutation": "An admissible nonsingular Q challenge with a different zero-mode count refutes the implementation.",
        },
        {
            "id": "F007",
            "prediction": "The frozen linearized compact 3+1 microtheory has lattice dispersion omega_hat^2=(4/a^2) sum_i sin^2(k_i a/2).",
            "formula": "omega_hat^2=k^2-(a^2/12) sum_i k_i^4+O(a^4); axis/diagonal correction ratio=3",
            "allowed_refutation": "A direct Hessian diagonalization of the frozen lattice Hamiltonian giving another spectrum or correction ratio refutes the implementation.",
        },
        {
            "id": "F008",
            "prediction": "The nonlinear classical 3+1 ADM HDA selects the DeWitt kinetic coefficient lambda=1/2 in three spatial dimensions.",
            "formula": "{H[N],H[M]}=D[g^ij(N d_j M-M d_j N)] for lambda=1/2",
            "allowed_refutation": "Off-shell convergence to a different lambda with the same canonical variables and potential refutes the certificate.",
        },
        {
            "id": "F009",
            "prediction": "A strictly commuting-projector Z2 holonomy code on T^3 has eight ground states but no local graviton polarizations.",
            "formula": "k=b1(T^3)=3; dim H_ground=2^3; N_local_TT=0",
            "allowed_refutation": "A local gapless tensor mode in the registered stabilizer Hamiltonian refutes the no-go result.",
        },
    ],
    "conditional_results_not_counted_as_external_blind_predictions": [
        "Standard-Model hypercharge ratios after assuming the representation pattern and Yukawa terms",
        "one-loop beta coefficients after assuming three generations and one Higgs doublet",
        "sin^2(theta_W)=3/8 after assuming a common gauge-trace normalization",
        "Q=3 as the physical flux sector; only the implication Q=3 -> three chiral modes is verified",
        "the Newtonian 1/r^2 kernel after choosing a three-dimensional massless lattice Laplacian",
        "the linearized quantum constraint algebra; nonlinear operator closure remains open",
    ],
    "prohibited_after_freeze": [
        "changing formulas after seeing challenge or external data",
        "adding observable-specific fit coefficients",
        "counting constructed gauge couplings as predictions",
        "claiming that anomaly cancellation alone derives the gauge group or number of generations",
        "claiming that linearized quantum closure solves the nonlinear 3+1 Dirac algebra",
        "claiming that the topological commuting-projector code has a GR continuum limit",
    ],
}
serialized = json.dumps(manifest, indent=2, sort_keys=True).encode()
manifest_path.write_bytes(serialized)
digest = hashlib.sha256(serialized).hexdigest()
result = {"artifact_id": "A23", "manifest": str(manifest_path.relative_to(ROOT)), "sha256": digest}
out = ROOT / "artifacts/A23_future_preregistration/frozen_manifest_hash.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
