#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.newtonian_coarse_graining import newtonian_coarse_graining_certificate

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts" / "A35_newtonian_coarse_graining"
OUT.mkdir(parents=True, exist_ok=True)
result = newtonian_coarse_graining_certificate()
(OUT / "certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
if not result["pass"]:
    raise SystemExit(1)
