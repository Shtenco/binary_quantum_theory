#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.topological_quantum_geometry import topological_geometry_suite

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts" / "A36_topological_quantum_geometry"
OUT.mkdir(parents=True, exist_ok=True)
result = topological_geometry_suite()
(OUT / "certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
if not result["all_exact_codes_pass"]:
    raise SystemExit(1)
