#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.adm_nonlinear_hda import nonlinear_adm_certificate

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts" / "A39_nonlinear_adm_3d_hda"
OUT.mkdir(parents=True, exist_ok=True)
result = nonlinear_adm_certificate()
(OUT / "certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
if not result["pass"]:
    raise SystemExit(1)
