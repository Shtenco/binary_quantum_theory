#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from compact_holonomies.linearized_quantum_gravity import frozen_microtheory_manifest

ROOT = Path(__file__).resolve().parents[1]
manifest = ROOT / "preregistration" / "QUANTUM_LINEARIZED_MICROTHEORY_v2.3.json"
hash_file = ROOT / "preregistration" / "QUANTUM_LINEARIZED_MICROTHEORY_v2.3.sha256"
expected_payload = json.dumps(frozen_microtheory_manifest(), indent=2, sort_keys=True, ensure_ascii=False) + "\n"
actual_payload = manifest.read_text(encoding="utf-8")
if actual_payload != expected_payload:
    raise SystemExit("frozen microtheory manifest differs from executable definition")
digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
registered = hash_file.read_text(encoding="utf-8").split()[0]
if digest != registered:
    raise SystemExit("microtheory SHA256 mismatch")
result = {"pass": True, "manifest": str(manifest.relative_to(ROOT)), "sha256": digest}
out = ROOT / "artifacts" / "A38_quantum_microtheory_preregistration"
out.mkdir(parents=True, exist_ok=True)
(out / "certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
