#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.linearized_quantum_gravity import linearized_quantum_gravity_certificate

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts" / "A33_A34_quantum_linearized_3d"
OUT.mkdir(parents=True, exist_ok=True)
result = linearized_quantum_gravity_certificate()
(OUT / "certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
if not result["pass"]:
    raise SystemExit(1)
