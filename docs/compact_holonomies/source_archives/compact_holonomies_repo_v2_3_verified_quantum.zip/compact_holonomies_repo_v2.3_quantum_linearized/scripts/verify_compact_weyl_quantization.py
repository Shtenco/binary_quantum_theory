#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.compact_weyl_quantization import compact_weyl_certificate

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts" / "A37_compact_weyl_quantization"
OUT.mkdir(parents=True, exist_ok=True)
result = compact_weyl_certificate()
(OUT / "certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
if not result["pass"]:
    raise SystemExit(1)
