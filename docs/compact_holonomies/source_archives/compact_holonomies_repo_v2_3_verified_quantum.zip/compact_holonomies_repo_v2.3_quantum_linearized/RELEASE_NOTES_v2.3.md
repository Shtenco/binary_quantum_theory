# Release notes v2.3.0

## Новые проверки

- **A33:** операторная линейная 3+1 алгебра ограничений `G,D,H`.
- **A34:** TT physical Hilbert space, Fock Hamiltonian, unitary evolution,
  partition function and propagator.
- **A35:** coarse-grained `1/r²` force kernel from the compact 3D Laplacian.
- **A36:** exact 3D commuting-projector holonomy code and topological no-go.
- **A37:** finite Weyl algebra plus finite-dimensional CCR no-go theorem.
- **A38:** SHA-256 frozen executable microtheory manifest.
- **A39:** nonlinear off-shell classical 3+1 ADM HDA and DeWitt-`lambda`
  death tests.

## Основные числа

- unit tests: `55 passed`;
- TT rank: `2`;
- independent linearized first-class constraints: `7`;
- quantum commutator residual: `6.22e-15`;
- unitary-evolution residual: `3.31e-16`;
- dispersion convergence order: `1.973...1.997`;
- coarse-grained force exponent: `2.0471`;
- T3 topological ground degeneracy: `8`;
- nonlinear ADM HDA residual at `5^3`: `2.85e-6`;
- wrong-lambda residuals: `1.36`, `1.40`;
- successful continuous-constant coverage: `0/445`.

## Научная граница

v2.3 is the first version containing a genuine quantum Hilbert space and
constraint operators for a 3+1 gravitational sector.  That sector is
linearized.  The nonlinear 3+1 result remains classical.  Therefore v2.3 must
not be described as a complete quantum gravity theory.
