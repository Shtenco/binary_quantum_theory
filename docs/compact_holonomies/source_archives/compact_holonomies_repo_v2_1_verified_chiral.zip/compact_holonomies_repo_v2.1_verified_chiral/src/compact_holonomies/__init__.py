"""Compact holonomies research utilities.

Exact identities, controlled EFT assumptions, anomaly-free reduced dynamics,
and prediction audits are kept separate by design.
"""

from .effective_foam_eft import (
    EFTParameters,
    HolonomyCorrection,
    barrier_action,
    tunneling_amplitude,
    tunneling_probability,
    foam_corrected_barrier,
    phase_decoherence_factor,
    planck_suppression,
)
from .anomaly_free_spherical import (
    beta,
    canonical_holonomy_chart,
    closure_convergence,
    continuum_closure_trial,
    f1,
    f2,
    signature_change_threshold,
    symbolic_certificate,
)
from .micro_spectrum import (
    analytic_eigenvalues,
    compact_laplacian,
    run_blind_spectrum_test,
    universal_series_ratio,
)

__all__ = [
    "EFTParameters",
    "HolonomyCorrection",
    "barrier_action",
    "tunneling_amplitude",
    "tunneling_probability",
    "foam_corrected_barrier",
    "phase_decoherence_factor",
    "planck_suppression",
    "f1",
    "f2",
    "beta",
    "signature_change_threshold",
    "canonical_holonomy_chart",
    "symbolic_certificate",
    "continuum_closure_trial",
    "closure_convergence",
    "compact_laplacian",
    "analytic_eigenvalues",
    "run_blind_spectrum_test",
    "universal_series_ratio",
]

from .chiral_overlap import (
    chiral_certificate,
    chiral_flux_suite,
    overlap_dirac_operator,
    overlap_index,
    uniform_u1_flux_links,
)
from .anomaly_free_matter import (
    minimal_hypercharge_solution,
    right_neutrino_family,
    symbolic_hypercharge_certificate,
)
from .renormalization_group import (
    rg_certificate,
    standard_model_one_loop_beta_coefficients,
)
from .free_overlap_4d import free_overlap_4d_certificate, free_overlap_block

__all__.extend([
    "chiral_certificate",
    "chiral_flux_suite",
    "overlap_dirac_operator",
    "overlap_index",
    "uniform_u1_flux_links",
    "minimal_hypercharge_solution",
    "right_neutrino_family",
    "symbolic_hypercharge_certificate",
    "rg_certificate",
    "standard_model_one_loop_beta_coefficients",
    "free_overlap_4d_certificate",
    "free_overlap_block",
])
