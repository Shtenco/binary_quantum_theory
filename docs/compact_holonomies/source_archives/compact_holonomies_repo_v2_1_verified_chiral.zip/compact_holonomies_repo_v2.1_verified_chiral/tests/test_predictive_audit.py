import json
import subprocess
import sys
from pathlib import Path


def test_predictive_audit_separates_structural_predictions_from_445_constants():
    root = Path(__file__).resolve().parents[1]
    subprocess.run([sys.executable, "scripts/audit_predictive_power.py"], cwd=root, check=True,
                   stdout=subprocess.PIPE, text=True)
    data = json.loads((root / "artifacts/A17_predictive_power_audit/predictive_power_audit.json").read_text())
    assert data["catalog_claim_tested"] == 445
    assert data["n_registered_structural_predictions"] >= 5
    assert data["n_registered_physical_constant_predictions"] == 0
    assert data["physical_constant_coverage_fraction"] == 0.0
    assert data["status"] == "STRUCTURAL_PREDICTIONS_ONLY"
    assert data["target_leakage_symbols_found"] == []
