from compact_holonomies.prediction_registry import constants_coverage_report, registry


def test_registry_has_structural_predictions_but_no_fake_445_constant_claim():
    items = registry()
    report = constants_coverage_report(445)
    assert len(items) >= 5
    assert report["independent_modern_physics_constants_predicted"] == 0
    assert report["coverage_fraction"] == 0.0
