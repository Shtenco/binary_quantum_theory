"""
A15: Rigorous (not naive) count of TT polarizations for linearized vacuum
gravity, via explicit rank computation -- NOT the guessed arithmetic of A14.
Roadmap item 5, baseline half.

SCOPE, STATED UP FRONT: this computes the standard, well-established result
for UNDEFORMED linearized GR (Lorenz/harmonic gauge counting). It does NOT
extend this to the sine/holonomy-deformed lattice theory of A1-A14 -- that
connection is NOT attempted here and remains open (see honest_scope_note at
the end). This script's only job is to replace "naive counting" with an
actual, checkable linear-algebra computation for the reference (undeformed)
theory, which the compact-holonomies-deformed theory would need to reduce to
in the delta->0 limit for internal consistency.

Method (standard, textbook -- MTW ch.35, Wald ch.4.4):
  - Symmetric polarization tensor eps_{mu nu}, 10 independent real components,
    Minkowski signature (-,+,+,+).
  - Null wavevector k^mu = (w,0,0,w) (wave moving in z), w != 0 symbolic.
  - Lorenz/harmonic gauge condition: k^mu (eps_{mu nu} - (1/2) eta_{mu nu} eps) = 0
    for each nu -- 4 linear conditions on the 10 components. RANK computed
    explicitly, not assumed to be 4.
  - Residual gauge freedom: eps_{mu nu} -> eps_{mu nu} - (k_mu xi_nu + k_nu xi_mu)
    for xi^mu satisfying k^mu k_mu = 0 (automatically compatible with Lorenz
    gauge since k is null) -- a 4-parameter family (xi_0..xi_3). Embed as a
    10x4 matrix, RANK computed explicitly (this is the "gauge orbit" inside
    the constraint surface).
  - Physical dof = dim(constraint surface) - dim(gauge orbit), both from
    explicit sympy rank computations, not textbook assertion.
"""
import sympy as sp
import json

w = sp.symbols('w', real=True, nonzero=True)
eta = sp.diag(-1, 1, 1, 1)  # mostly-plus signature
k = sp.Matrix([w, 0, 0, w])  # null: k.eta.k = -w^2+w^2 = 0

# 10 independent components of symmetric eps_{mu nu}, mu,nu=0..3
names = []
idx_pairs = [(i, j) for i in range(4) for j in range(i, 4)]
syms = sp.symbols(' '.join(f'e{i}{j}' for i, j in idx_pairs))
eps = sp.zeros(4, 4)
for (i, j), s in zip(idx_pairs, syms):
    eps[i, j] = s
    eps[j, i] = s

# trace eps = eta^{mu nu} eps_{mu nu}
trace_eps = sum(eta[i, i] * eps[i, i] for i in range(4))

# k_nu = eta_{nu mu} k^mu
k_lower = eta * k

# Lorenz condition_nu = k^mu eps_{mu nu} - (1/2) k_nu * trace_eps , for nu=0..3
# k^mu eps_{mu nu} = sum_mu k[mu] * eps[mu,nu]  (k^mu already has upper index; eps has lower indices,
# contraction k^mu eps_{mu nu} needs eta to raise one eps index properly -- but since we contract
# k^mu (upper) directly with eps_{mu nu} (lower-lower) via k^mu eps_{mu nu} = (eta^{mu a}k_a) eps_{mu nu}
# it's cleaner to just contract k (already given as k^mu components, i.e. contravariant) against the
# first lower index of eps using the standard k^mu eps_{mu nu} = sum_mu k[mu]*eps[mu,nu]
# (this is valid: contracting an upper index vector component-wise against a lower tensor index)
lorenz_eqs = []
for nu in range(4):
    term = sum(k[mu] * eps[mu, nu] for mu in range(4)) - sp.Rational(1, 2) * k_lower[nu] * trace_eps
    lorenz_eqs.append(sp.expand(term))

# Build the 4x10 constraint matrix (coefficients of each eps symbol in each Lorenz eq)
constraint_matrix = sp.zeros(4, len(syms))
for row, eq in enumerate(lorenz_eqs):
    poly = sp.Poly(eq, *syms)
    for col, s in enumerate(syms):
        constraint_matrix[row, col] = poly.coeff_monomial(s)

constraint_rank = constraint_matrix.rank()

# Residual gauge: eps_{mu nu} -> eps_{mu nu} - (k_mu xi_nu + k_nu xi_mu), xi^0..xi^3 free (4 params)
xi = sp.symbols('xi0 xi1 xi2 xi3')
xi_vec = sp.Matrix(xi)
xi_lower = eta * xi_vec
gauge_shift = sp.zeros(4, 4)
for i in range(4):
    for j in range(4):
        gauge_shift[i, j] = k_lower[i] * xi_lower[j] / xi_lower[j].subs(xi_lower[j], 1) if False else 0
# build gauge_shift properly: k_mu xi_nu + k_nu xi_mu  (both lower-index, using k_lower and xi as given upper then lower)
gauge_shift = sp.zeros(4, 4)
for i in range(4):
    for j in range(4):
        gauge_shift[i, j] = k_lower[i]*xi_vec[j] + k_lower[j]*xi_vec[i]

# extract the 10 independent components of gauge_shift as linear functions of xi0..xi3 -> 10x4 matrix
gauge_matrix = sp.zeros(len(syms), 4)
for row, (i, j) in enumerate(idx_pairs):
    expr = sp.expand(gauge_shift[i, j])
    poly = sp.Poly(expr, *xi)
    for col, x in enumerate(xi):
        gauge_matrix[row, col] = poly.coeff_monomial(x)

gauge_rank = gauge_matrix.rank()

# Verify: does every gauge_matrix column actually lie in the null space of constraint_matrix
# (i.e. is gauge transformation automatically Lorenz-gauge-preserving, as claimed)?
check = sp.simplify(constraint_matrix * gauge_matrix)
gauge_preserves_lorenz = (check == sp.zeros(4, 4))

physical_dof = 10 - constraint_rank - gauge_rank

result = {
    "artifact_id": "A15",
    "roadmap_item": 5,
    "scope": "BASELINE undeformed linearized GR only -- see honest_scope_note",
    "setup": {
        "raw_components_of_symmetric_eps": 10,
        "null_wavevector": "k^mu = (w,0,0,w), verified null: k.eta.k = 0",
    },
    "constraint_rank_(Lorenz_gauge, 4 candidate conditions)": constraint_rank,
    "gauge_orbit_rank_(4 candidate residual-gauge directions)": gauge_rank,
    "gauge_transformations_automatically_preserve_Lorenz_condition": gauge_preserves_lorenz,
    "physical_dof_computed": physical_dof,
    "expected_from_textbook": 2,
    "match": physical_dof == 2,
    "honest_scope_note": (
        "This confirms, via explicit rank computation rather than assumed "
        "counting, that undeformed linearized vacuum GR has exactly 2 "
        "physical TT polarizations. It does NOT show this survives the "
        "sine/holonomy deformation (f1=sin^2 etc.) used throughout A1-A14, "
        "and does NOT connect to the discrete lattice models of A6-A14 at "
        "all -- that would require building an actual transverse sector on "
        "the lattice (A14 flagged this as unresolved) and re-running an "
        "analogous rank computation on the DEFORMED discrete constraints. "
        "That work is not done here and is left explicitly open, not "
        "asserted or assumed to go through."
    ),
}
print(json.dumps(result, indent=2))
with open("/home/claude/work/repo/artifacts/A15_tt_polarization_count/tt_count_results.json", "w") as f:
    json.dump(result, f, indent=2)
