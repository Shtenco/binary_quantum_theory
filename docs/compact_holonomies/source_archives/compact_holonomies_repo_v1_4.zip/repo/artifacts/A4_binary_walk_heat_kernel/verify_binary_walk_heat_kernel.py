#!/usr/bin/env python3
"""
A4 -- Бинарное блуждание -> тепловое ядро
=============================================
Реконструкция независимого артефакта (оригинальный файл автора
binary_walk_heat_kernel_derivation/verify_binary_walk_heat_kernel.py,
SHA-256 3eabb445..., в переданных мне материалах отсутствовал -- есть
только его название и заявленные результаты: "порядок сходимости ≈2.0035;
порядок синусоидальной ошибки ≈3.9999").

Скрипт измеряет ДВА независимых порядка сходимости заново, своими числами:

  (I)  |cos(m*eps)^N - exp(-m^2*t)|  ~  C1 * eps^p1,   ожидание p1 ~ 2
       (дискретное биномиальное блуждание -> тепловое ядро)

  (II) sum_f |sin(X_f) - X_f| * A_f  ~  C2 * a^p2,     ожидание p2 ~ 4
       (суммарная ошибка синус-действия относительно Редже, X_f=O(a^2)
        типичная голономия грани, A_f=O(a^2) площадь, N_faces=O(a^-4))

N.B.: при оценке (I) N=round(2t/eps^2) округляется до целого -- если
сравнивать cos(m*eps)^N с exp(-m^2*t) для НОМИНАЛЬНОГО t, ошибка округления
N маскирует истинный порядок O(eps^2). Правильная методика (и то, что здесь
сделано) -- сравнивать с exp(-m^2*t_eff), где t_eff=N*eps^2/2 -- РЕАЛЬНО
достигнутое значение при целом N.
"""
import json
import numpy as np

report = {"artifact_id": "A4", "checks": [], "raw_data": {}}


def add_check(name, passed, detail):
    report["checks"].append({"name": name, "pass": bool(passed), "detail": detail})
    print(f"[{'PASS' if passed else 'FAIL'}] {name}\n       {detail}")


# --- (I) сходимость биномиального блуждания к тепловому ядру ---
def heat_kernel_convergence_order(m=1.7, t=0.35,
                                   eps_list=(0.2, 0.1, 0.05, 0.025, 0.0125, 0.00625, 0.003125)):
    errs, epss, t_effs = [], [], []
    for eps in eps_list:
        N = int(round(2 * t / eps**2))
        t_eff = N * eps**2 / 2
        approx = np.cos(m * eps) ** N
        exact = np.exp(-m**2 * t_eff)
        errs.append(abs(approx - exact))
        epss.append(eps)
        t_effs.append(t_eff)
    p, _ = np.polyfit(np.log(epss), np.log(errs), 1)
    return float(p), list(zip(epss, errs, t_effs))

order1, data1 = heat_kernel_convergence_order()
report["raw_data"]["heat_kernel_convergence"] = [
    {"eps": e, "error": err, "t_eff": t_eff} for e, err, t_eff in data1
]
for eps, err, t_eff in data1:
    print(f"       eps={eps:<10} t_eff={t_eff:.6f}  error={err:.4e}")
add_check(
    "Порядок сходимости cos(m*eps)^N -> exp(-m^2*t) ~ O(eps^2)",
    1.85 <= order1 <= 2.15,
    f"измеренный порядок p1 = {order1:.4f} (7 точек eps=0.2..0.003125, регрессия log-log)",
)


# --- (II) порядок O(a^4) для суммарной ошибки синус-действия ---
def action_error_order(a_list=(0.4, 0.2, 0.1, 0.05, 0.025), n_trials=60, seed=20260714):
    rng = np.random.default_rng(seed)
    orders = []
    for _ in range(n_trials):
        errs, avals = [], []
        for a in a_list:
            n_faces = int(round(a ** -4))
            n_faces = min(n_faces, 2_000_000)  # практический потолок памяти
            X_f = rng.normal(0, 1, n_faces) * a**2
            A_f = a**2
            action_err = np.sum(np.abs(np.sin(X_f) - X_f)) * A_f
            errs.append(action_err)
            avals.append(a)
        p, _ = np.polyfit(np.log(avals), np.log(errs), 1)
        orders.append(p)
    return float(np.mean(orders)), float(np.std(orders)), orders

order2_mean, order2_std, all_orders = action_error_order()
report["raw_data"]["action_error_order"] = {
    "mean": order2_mean, "std": order2_std, "n_trials": len(all_orders)
}
add_check(
    "Порядок суммарной ошибки синус-действия vs Regge ~ O(a^4)",
    3.6 <= order2_mean <= 4.4,
    f"измеренный порядок p2 = {order2_mean:.3f} +/- {order2_std:.3f} по {len(all_orders)} независимым реализациям",
)

report["measured_order_binary_walk"] = order1
report["measured_order_sine_action_error"] = order2_mean
report["document_claimed_values"] = {
    "binary_walk_order": 2.0035,
    "sine_action_error_order": 3.9999,
    "note": "Эти числа взяты из основного документа (Приложение А, A4) и НЕ "
            "были использованы для настройки данного скрипта -- сравниваются "
            "постфактум ниже.",
}
add_check(
    "Измеренный порядок (I) согласуется с заявленным в документе (≈2.0035)",
    abs(order1 - 2.0035) < 0.2,
    f"|{order1:.4f} - 2.0035| = {abs(order1-2.0035):.4f}",
)
add_check(
    "Измеренный порядок (II) согласуется с заявленным в документе (≈3.9999)",
    abs(order2_mean - 3.9999) < 0.5,
    f"|{order2_mean:.4f} - 3.9999| = {abs(order2_mean-3.9999):.4f}",
)

n_pass = sum(c["pass"] for c in report["checks"])
report["summary"] = f"{n_pass}/{len(report['checks'])} checks passed"

with open("derivation_results.json", "w", encoding="utf-8") as fh:
    json.dump(report, fh, ensure_ascii=False, indent=2)

print(f"\n{report['summary']}")
