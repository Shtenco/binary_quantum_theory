#!/usr/bin/env python3
"""
A3 -- Неединственность ультрафиолетового ядра
================================================
Реконструкция независимого артефакта (оригинальный файл автора
test_nonlocal_kernel_underdetermination.py, SHA-256 081e5c0d..., в
переданных мне материалах отсутствовал -- есть только его название и
назначение).

Строим три разных "микроскопических" ядра W(q), все с одинаковым ведущим
инфракрасным (q->0) пределом W(q) ~ q^2, но с разным поведением уже на
следующем (q^4) порядке и качественно разным поведением в УФ (q -> pi,
граница зоны Бриллюэна):

  W_A(q) = q^2                        -- континуальный (эталонный) предел
  W_B(q) = 4*sin^2(q/2)                -- стандартная решёточная дисперсия
  W_C(q) = q^2 / (1 + q^2/8)           -- Паде-регуляризованное ядро

Символьно (sympy) проверяем: ведущий член ряда Тейлора W_B и W_C при q->0
совпадает с q^2 (общий ИК-предел), коэффициент при q^4 уже различается
между ядрами (неединственность начинается на подведущем порядке), а при
q->pi значения W_i(pi) существенно различаются -- то есть общий
низкоэнергетический (ИК) предел не фиксирует единственное микроскопическое
(УФ) продолжение.
"""
import json
import numpy as np
import sympy as sp

q = sp.symbols('q', real=True)

kernels = {
    "W_A_continuum": q**2,
    "W_B_lattice_nn": 4 * sp.sin(q / 2) ** 2,
    "W_C_pade_regularized": q**2 / (1 + q**2 / 8),
}

report = {"artifact_id": "A3", "checks": [], "ir_series": {}, "uv_values": {}}


def add_check(name, passed, detail):
    report["checks"].append({"name": name, "pass": bool(passed), "detail": detail})
    print(f"[{'PASS' if passed else 'FAIL'}] {name}\n       {detail}")


# --- ИК-предел: разложение в ряд Тейлора вокруг q=0 до O(q^6) ---
series = {}
for name, expr in kernels.items():
    ser = sp.series(expr, q, 0, 6).removeO()
    series[name] = sp.expand(ser)
    report["ir_series"][name] = str(series[name])

ref = series["W_A_continuum"]
ir_matches = {}
uv_freedom = {}
for name, ser in series.items():
    if name == "W_A_continuum":
        continue
    diff_poly = sp.expand(ser - ref)
    poly = sp.Poly(diff_poly, q)
    # "общий ИК-предел" = совпадение ВЕДУЩЕГО (q^2) коэффициента при q->0
    leading_coeffs_diff = [poly.coeff_monomial(q**k) for k in range(0, 3)]  # 1, q, q^2
    ir_matches[name] = all(c == 0 for c in leading_coeffs_diff)
    # неединственность начинается уже на следующем (q^4) порядке
    q4_coeff = poly.coeff_monomial(q**4)
    uv_freedom[name] = (q4_coeff != 0)

for name in ir_matches:
    add_check(
        f"Общий ИК-предел (ведущий член q^2 при q->0) у {name}",
        ir_matches[name],
        f"ряд: {series[name]}  (совпадает с q^2 до и включая порядок q^1; коэффициент q^2 идентичен)",
    )
for name in uv_freedom:
    add_check(
        f"Неединственность уже на подведущем (q^4) порядке у {name} -- УФ-свобода при общем ИК",
        uv_freedom[name],
        f"коэффициент при q^4 отличен от эталонного (0 у W_A): {series[name]}",
    )

# --- УФ-поведение: значения при q=pi (граница зоны Бриллюэна) ---
uv_vals = {name: float(expr.subs(q, sp.pi)) for name, expr in kernels.items()}
report["uv_values"] = uv_vals
uv_spread = max(uv_vals.values()) - min(uv_vals.values())
add_check(
    "УФ-значения W(pi) существенно различаются между ядрами с общим ИК-пределом",
    uv_spread > 1.0,
    f"W(pi) = {uv_vals}; разброс = {uv_spread:.4f}",
)

# --- количественная проверка на сетке q in [0, pi] ---
qs = np.linspace(1e-3, np.pi, 500)
funcs = {name: sp.lambdify(q, expr, 'numpy') for name, expr in kernels.items()}
vals = {name: f(qs) for name, f in funcs.items()}
max_uv_diff = float(np.max(np.abs(vals["W_B_lattice_nn"] - vals["W_A_continuum"])))
add_check(
    "На всей зоне [0,pi] ядра заметно расходятся (не тождественны глобально)",
    max_uv_diff > 0.5,
    f"max|W_B - W_A| на сетке из 500 точек = {max_uv_diff:.4f}",
)

n_pass = sum(c["pass"] for c in report["checks"])
report["summary"] = f"{n_pass}/{len(report['checks'])} checks passed"
report["conclusion"] = (
    "Несколько микроскопических ядер W(q) дают один и тот же ИК-предел "
    "(общий continuum limit q^2), но качественно разное УФ-поведение. "
    "Значит continuum/ИК-предел сам по себе не определяет единственный "
    "микроскопический гамильтониан -- нужен независимый критерий отбора "
    "(класс универсальности), как и утверждается в основном документе."
)

with open("nonlocal_kernel_underdetermination.json", "w", encoding="utf-8") as fh:
    json.dump(report, fh, ensure_ascii=False, indent=2)

print(f"\n{report['summary']}")
print(report["conclusion"])
