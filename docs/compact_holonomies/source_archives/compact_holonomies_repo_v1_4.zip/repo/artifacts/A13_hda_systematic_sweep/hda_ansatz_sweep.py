"""
A13: Systematic sweep of H-ansatz families for HDA closure (roadmap item 4).
Not cherry-picking one more ansatz -- testing a small, pre-declared family of
4 structurally distinct constructions in ONE script, all against the SAME
unmodified D_i = E_i*(K_i - K_{i-1}), all using A1's proven f1=sin^2(x).

Method per ansatz:
  1. Compute {H_i, H_{i+1}} exactly via sympy.
  2. NECESSARY test: do the free symbols of the bracket fit inside the free
     symbols of a generous candidate span {D_{i-1}, D_i, D_{i+1}, D_{i+2}}?
     If not -> proven anomaly, no further work needed (this alone settled
     A10 and A11).
  3. If the necessary test passes, attempt to actually solve for closure
     coefficients (as in A10/A11) to check sufficiency, not just declare
     victory on the necessary condition alone.

Ansatz family (decided BEFORE running, not adjusted afterward):
  H1 (= A10): symmetrized link average:      (f1(dK_{i-1})+f1(dK_i))/(2d^2) * E_i
  H2 (= A11): curvature/difference:           f1(d(K_i-K_{i-1}))/d^2 * E_i
  H3 (new):   product of link corrections:    f1(dK_{i-1})*f1(dK_i)/d^2 * E_i
  H4 (new):   forward link, E-averaged:       f1(dK_i)/d^2 * (E_i+E_{i+1})/2
"""
import sympy as sp
import json

N = 7
delta = sp.symbols('delta', positive=True)
K = sp.symbols(f'K0:{N}', real=True)
E = sp.symbols(f'E0:{N}', positive=True)

def f1(x): return sp.sin(x)**2
def Kidx(i): return K[i % N]
def Eidx(i): return E[i % N]
def D(i): return Eidx(i) * (Kidx(i) - Kidx(i-1))

def poisson(f, g):
    total = 0
    for i in range(N):
        total += sp.diff(f, K[i]) * sp.diff(g, E[i]) - sp.diff(f, E[i]) * sp.diff(g, K[i])
    return sp.simplify(total)

ansatze = {
    "H1_symmetrized_link_average": lambda i: (f1(delta*Kidx(i-1)) + f1(delta*Kidx(i))) / (2*delta**2) * Eidx(i),
    "H2_curvature_difference":     lambda i: f1(delta*(Kidx(i) - Kidx(i-1))) / delta**2 * Eidx(i),
    "H3_product_of_links":         lambda i: f1(delta*Kidx(i-1)) * f1(delta*Kidx(i)) / delta**2 * Eidx(i),
    "H4_forward_link_E_averaged":  lambda i: f1(delta*Kidx(i)) / delta**2 * (Eidx(i)+Eidx(i+1))/2,
}

report = {"artifact_id": "A13", "N": N, "ansatze": {}}
any_closed = False

for name, Hfunc in ansatze.items():
    i = 2  # generic interior vertex, away from wraparound for N=7
    Hi, Hi1 = Hfunc(i), Hfunc(i+1)
    br = sp.simplify(sp.expand_trig(sp.expand(poisson(Hi, Hi1))))

    candidate_span = [D(i-1), D(i), D(i+1), D(i+2)]
    span_symbols = set()
    for d in candidate_span:
        span_symbols |= d.free_symbols
    br_symbols = br.free_symbols

    extra_symbols = br_symbols - span_symbols
    necessary_test_pass = (len(extra_symbols) == 0)

    entry = {
        "bracket": str(br),
        "bracket_symbols": sorted(str(s) for s in br_symbols),
        "candidate_D_span_symbols": sorted(str(s) for s in span_symbols),
        "extra_symbols_not_in_any_D": sorted(str(s) for s in extra_symbols),
        "necessary_test_pass": necessary_test_pass,
    }

    if necessary_test_pass and br != 0:
        # attempt actual solve for coefficients a_{i-1}, a_i, a_{i+1}, a_{i+2}
        coeffs = sp.symbols('a_im1 a_i a_ip1 a_ip2')
        combo = sum(c*d for c, d in zip(coeffs, candidate_span))
        sol = sp.solve([sp.Eq(sp.expand(br - combo), 0)], list(coeffs), dict=True)
        entry["sufficiency_solve_attempted"] = True
        entry["sufficiency_solve_result"] = str(sol)[:500]
    elif br == 0:
        entry["sufficiency_solve_attempted"] = False
        entry["note"] = "bracket identically zero -- trivially closes, but check if this is physically meaningful (may indicate H_i, H_{i+1} don't actually overlap)"
    else:
        entry["sufficiency_solve_attempted"] = False
        entry["note"] = "failed necessary test -- proven anomaly, no need to solve"

    report["ansatze"][name] = entry
    tag = "NECESSARY-TEST-PASS" if necessary_test_pass else "ANOMALY (fails necessary test)"
    print(f"=== {name} ===")
    print(f"  {{H_{i},H_{i+1}}} = {br}")
    print(f"  extra symbols not in any candidate D: {sorted(str(s) for s in extra_symbols)}")
    print(f"  -> {tag}")
    print()
    if necessary_test_pass and br != 0:
        any_closed = True

report["summary"] = {
    "any_ansatz_passed_even_necessary_test": any_closed,
    "conclusion": (
        "All 4 pre-declared, structurally distinct H-ansatze fail even the "
        "necessary variable-containment test for closure onto D_i (proven "
        "anomaly for each) -- unless stated otherwise per-entry above."
        if not any_closed else
        "At least one ansatz passed the necessary test; see sufficiency_solve_result "
        "for whether it actually closes with consistent coefficients."
    )
}
print("SUMMARY:", report["summary"]["conclusion"])

with open("/home/claude/work/repo/artifacts/A13_hda_systematic_sweep/hda_ansatz_sweep_results.json", "w") as f:
    json.dump(report, f, indent=2)
