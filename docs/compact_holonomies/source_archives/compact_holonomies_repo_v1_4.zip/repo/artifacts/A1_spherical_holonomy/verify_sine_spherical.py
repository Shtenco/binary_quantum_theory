#!/usr/bin/env python3
"""
A1 -- Сферическая голономная проверка
======================================
Реконструкция независимого артефакта. ВАЖНО: исходный файл автора
(verify_sine_spherical.py, SHA-256 d7c60d19...) в переданных мне материалах
отсутствовал -- есть только его название и заявленное назначение в
Приложении А документа. Этот скрипт написан заново и проверяет ровно то,
что перечислено как назначение артефакта:

  1. точное тождество sin(i*theta) = i*sinh(theta);
  2. малокривизный предел sin(delta*K)/delta -> K;
  3. редуцированное сферическое closure-соотношение f2 = (1/2) f1',  beta = f2';
  4. смена знака beta = cos(2*delta*K), beta = -1 при delta*K = pi/2.

Для пункта 3 в документе дана только структура рекурсии (f2=(1/2)f1',
beta=f2'), а не сами f1,f2 в явном виде. Минимальное самосогласованное
решение, совместимое одновременно с этой рекурсией И с независимо данным
в документе beta=cos(2*delta*K) (пункт 4), таково:

    f1(x) = sin^2(x),   f2(x) = sin(x)cos(x) = (1/2)sin(2x),   beta(x) = cos(2x)

Действительно: f1'(x) = 2 sin(x)cos(x) = sin(2x) = 2*f2(x)  =>  f2=(1/2)f1'.
f2'(x) = cos(2x) = beta(x). Ниже это проверяется символьно (sympy, точно)
и численно вслепую на 20000 случайных точек (конечные разности).

Результат сохраняется в sine_spherical_verification.json.
"""
import json
import hashlib
import numpy as np
import sympy as sp

rng = np.random.default_rng(20260714)
report = {"artifact_id": "A1", "checks": []}


def add_check(name, passed, detail):
    report["checks"].append({"name": name, "pass": bool(passed), "detail": detail})
    print(f"[{'PASS' if passed else 'FAIL'}] {name}\n       {detail}")


# 1. sin(i*theta) = i*sinh(theta) -- точное тождество
theta = np.linspace(-6, 6, 50000)
lhs = np.sin(1j * theta)
rhs = 1j * np.sinh(theta)
err = float(np.max(np.abs(lhs - rhs)))
add_check("sin(i*theta) = i*sinh(theta)", err < 1e-9, f"max|LHS-RHS| по 50000 точкам = {err:.3e}")

# 2. малокривизный предел sin(delta*K)/delta -> K
K = np.diag([0.7, -2.3, 1.05, 4.4])
deltas = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6]
diffs = [float(np.linalg.norm(np.sin(d * K) / d - K)) for d in deltas]
monotone = all(diffs[i] > diffs[i + 1] for i in range(len(diffs) - 1))
add_check(
    "sin(delta*K)/delta -> K при delta -> 0",
    monotone and diffs[-1] < 1e-9,
    f"delta=1e-1..1e-6 -> ошибки = {['%.3e' % x for x in diffs]}",
)

# 3. Символьная проверка closure-соотношения f2=(1/2)f1', beta=f2'
x = sp.symbols('x', real=True)
f1 = sp.sin(x) ** 2
f2_expected = sp.sin(x) * sp.cos(x)
beta_expected = sp.cos(2 * x)

f2_from_f1 = sp.simplify(sp.Rational(1, 2) * sp.diff(f1, x))
beta_from_f2 = sp.simplify(sp.diff(f2_expected, x))

closure_ok = sp.simplify(f2_from_f1 - f2_expected) == 0
beta_ok = sp.simplify(beta_from_f2 - beta_expected) == 0
add_check(
    "Символьно: f2 = (1/2) f1'  для  f1=sin^2(x), f2=sin(x)cos(x)",
    closure_ok,
    f"(1/2) d/dx[sin^2 x] = {f2_from_f1}  ==  sin(x)cos(x): разность = {sp.simplify(f2_from_f1 - f2_expected)}",
)
add_check(
    "Символьно: beta = f2'  для  beta=cos(2x)",
    beta_ok,
    f"d/dx[sin(x)cos(x)] = {beta_from_f2}  ==  cos(2x): разность = {sp.simplify(beta_from_f2 - beta_expected)}",
)

# 3b. Слепая численная проверка на 20000 случайных точек (конечные разности,
#     скрипт не использует символьный результат выше -- независимая ветка)
N_BLIND = 20000
xs = rng.uniform(-3.0, 3.0, N_BLIND)
h = 1e-6
f1_num = lambda t: np.sin(t) ** 2
f2_num = lambda t: np.sin(t) * np.cos(t)

f1_prime_fd = (f1_num(xs + h) - f1_num(xs - h)) / (2 * h)
f2_pred = 0.5 * f1_prime_fd
f2_true = f2_num(xs)
max_rel_err_f2 = float(np.max(np.abs(f2_pred - f2_true)))

f2_prime_fd = (f2_num(xs + h) - f2_num(xs - h)) / (2 * h)
beta_true = np.cos(2 * xs)
max_rel_err_beta = float(np.max(np.abs(f2_prime_fd - beta_true)))

add_check(
    f"Слепая проверка f2=(1/2)f1' на {N_BLIND} случайных точках (конечные разности)",
    max_rel_err_f2 < 1e-5,
    f"max|f2_predicted - f2_true| = {max_rel_err_f2:.3e}",
)
add_check(
    f"Слепая проверка beta=f2' на {N_BLIND} случайных точках (конечные разности)",
    max_rel_err_beta < 1e-5,
    f"max|beta_predicted - beta_true| = {max_rel_err_beta:.3e}",
)

# 4. Смена знака: beta(delta*K=pi/2) = -1
dK = np.pi / 2
beta_at_pi2 = float(np.cos(2 * dK))
add_check(
    "beta = cos(2*delta*K) = -1 при delta*K = pi/2",
    abs(beta_at_pi2 - (-1.0)) < 1e-12,
    f"cos(pi) = {beta_at_pi2:.12f}",
)

n_pass = sum(c["pass"] for c in report["checks"])
n_total = len(report["checks"])
report["summary"] = f"{n_pass}/{n_total} checks passed"
report["note"] = (
    "Скрипт написан заново автором проверки (не оригинальный файл документа); "
    "f1, f2 выбраны как минимальное решение, совместимое с обеими данными в "
    "документе формулами (f2=(1/2)f1', beta=f2') и (beta=cos(2*delta*K))."
)

with open("sine_spherical_verification.json", "w", encoding="utf-8") as fh:
    json.dump(report, fh, ensure_ascii=False, indent=2)

print(f"\n{report['summary']}")
