"""
A11: Second, independently-motivated attempt at HDA closure (roadmap item 4).
NOT a retuning of A10 to force a match -- a genuinely different ansatz,
motivated by standard lattice gauge theory practice: deform the GAUGE-INVARIANT
curvature (difference of neighboring link holonomies), not the raw link
variables separately. This is arguably the more standard choice (field
strength = curl of connection), independent of what would make D and H
"match" -- decided BEFORE computing the bracket, not after.

H_i = f1( delta*(K_i - K_{i-1}) ) / delta^2 * E_i     [curvature-based]
      (vs A10's H_i = (f1(delta*K_{i-1}) + f1(delta*K_i))/(2 delta^2) * E_i)

D_i = E_i * (K_i - K_{i-1})    [unchanged from A10 -- standard discrete
                                 momentum constraint, not retuned]

Same f1 = sin^2(x) from A1. Test: does {H_i, H_{i+1}} close onto D_i, D_{i+1}
now? Reported honestly either way.
"""
import sympy as sp
import json

N = 6
delta = sp.symbols('delta', positive=True)
K = sp.symbols(f'K0:{N}', real=True)
E = sp.symbols(f'E0:{N}', positive=True)

def f1(x): return sp.sin(x)**2

def Kidx(i): return K[i % N]
def Eidx(i): return E[i % N]

def H(i):
    return f1(delta*(Kidx(i) - Kidx(i-1))) / delta**2 * Eidx(i)

def D(i):
    return Eidx(i) * (Kidx(i) - Kidx(i-1))

def poisson(f, g):
    total = 0
    for i in range(N):
        total += sp.diff(f, K[i]) * sp.diff(g, E[i]) - sp.diff(f, E[i]) * sp.diff(g, K[i])
    return sp.simplify(total)

results = []
for i in [1, 2]:
    Hi, Hi1 = H(i), H(i+1)
    br = poisson(Hi, Hi1)
    br = sp.simplify(sp.expand_trig(sp.expand(br)))
    Di, Di1 = sp.expand(D(i)), sp.expand(D(i+1))

    dep_check = {
        "br_has_E_i": bool(br.has(Eidx(i))),
        "br_has_E_i+1": bool(br.has(Eidx(i+1))),
        "br_has_K_i-1": bool(br.has(Kidx(i-1))),
        "br_has_K_i+2": bool(br.has(Kidx(i+2))),
        "Di_vars": sorted({str(s) for s in Di.free_symbols}),
        "Di1_vars": sorted({str(s) for s in Di1.free_symbols}),
        "br_vars": sorted({str(s) for s in br.free_symbols}),
    }

    row = {"pair": f"H_{i},H_{i+1}", "bracket": str(br), "D_i": str(Di), "D_i+1": str(Di1),
           "variable_dependency_check": dep_check}
    results.append(row)
    print(f"--- {{H_{i}, H_{i+1}}} ---")
    print("bracket:", br)
    print("vars in bracket:", dep_check["br_vars"])
    print("vars in D_i:", dep_check["Di_vars"], " vars in D_{i+1}:", dep_check["Di1_vars"])
    print()

with open("/home/claude/work/repo/artifacts/A11_hda_second_attempt/hda_curvature_ansatz_results.json", "w") as f:
    json.dump({"artifact_id": "A11", "N": N, "results": results}, f, indent=2)
