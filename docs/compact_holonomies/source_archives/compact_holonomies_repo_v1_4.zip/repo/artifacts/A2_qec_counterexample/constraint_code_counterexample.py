#!/usr/bin/env python3
"""
A2 -- Контрпример к выводу динамики из QEC (exact toric-code toy)
====================================================================
Реконструкция независимого артефакта (оригинальный файл автора
constraint_code_counterexample.py, SHA-256 24d661e5..., в переданных мне
материалах отсутствовал -- есть только его название и назначение).

Идея контрпримера: строим ТОЧНЫЙ (не приближённый) toric code на решётке
L x L с периодическими граничными условиями -- стандартный пример локального
кода квантовой коррекции ошибок (Kitaev 1997/2003). Стабилизаторы (звёзды и
плакетки) заданы бинарной симплектической (GF(2)) матрицей, что позволяет
точно вычислить:

  - независимость стабилизаторов (ранг над GF(2));
  - размерность кодового пространства k (логические кубиты);
  - расстояние кода d (минимальный вес логического оператора).

Ключевой пункт: этот код полностью статичен -- локальность и коррекция
ошибок в нём заданы БЕЗ какой-либо динамики (гамильтониана эволюции,
дисперсионного соотношения, гравитона, HDA-алгебры ограничений). Значит
сам факт "локальный код с хорошим QEC" не фиксирует ни geometry, ни
Einstein dynamics, ни spin-2 моду -- для этого нужны дополнительные
структуры, которых в toric code нет по построению.
"""
import json
import numpy as np


def toric_code_binary_symplectic(L):
    """
    Строит toric code на LxL решётке с периодическими граничными условиями.
    Кубиты живут на рёбрах: 2*L*L кубитов (горизонтальные + вертикальные).
    Возвращает бинарные X- и Z-стабилизаторные матрицы (звёзды и плакетки).
    """
    n_qubits = 2 * L * L

    def edge_h(row, col):
        # горизонтальное ребро в узле (row, col)
        return (row % L) * L + (col % L)

    def edge_v(row, col):
        return L * L + (row % L) * L + (col % L)

    # X-стабилизаторы (звёзды): произведение X по 4 рёбрам, инцидентным узлу
    X_stab = np.zeros((L * L, n_qubits), dtype=np.uint8)
    for r in range(L):
        for c in range(L):
            v = r * L + c
            for e in (edge_h(r, c), edge_h(r, c - 1), edge_v(r, c), edge_v(r - 1, c)):
                X_stab[v, e] ^= 1

    # Z-стабилизаторы (плакетки): произведение Z по 4 рёбрам границы плакетки
    Z_stab = np.zeros((L * L, n_qubits), dtype=np.uint8)
    for r in range(L):
        for c in range(L):
            p = r * L + c
            for e in (edge_h(r, c), edge_h(r + 1, c), edge_v(r, c), edge_v(r, c + 1)):
                Z_stab[p, e] ^= 1

    return X_stab, Z_stab, n_qubits


def gf2_rank(mat):
    """Ранг бинарной матрицы над GF(2) методом Гаусса."""
    M = mat.copy().astype(np.uint8) % 2
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = None
        for r in range(rank, rows):
            if M[r, col]:
                pivot = r
                break
        if pivot is None:
            continue
        M[[rank, pivot]] = M[[pivot, rank]]
        for r in range(rows):
            if r != rank and M[r, col]:
                M[r] ^= M[rank]
        rank += 1
        if rank == rows:
            break
    return rank


def minimal_logical_weight(L, X_stab, Z_stab, n_qubits, trials=4000, rng=None):
    """
    Оценка расстояния кода снизу: логический X-оператор -- незамкнутая
    (некontрактируемая) петля по вертикальным рёбрам, обёрнутая вокруг тора.
    Минимальный вес такой петли по построению равен L (нетривиальный
    гомологический класс на торе). Проверяем это прямым построением и
    случайным поиском более коротких эквивалентных представителей внутри
    класса (умножение на стабилизаторы) -- ни один не должен быть короче.
    """
    if rng is None:
        rng = np.random.default_rng(0)

    def edge_v(row, col):
        return L * L + (row % L) * L + (col % L)

    # логический оператор: столбец вертикальных рёбер, замыкающийся вокруг тора
    logical = np.zeros(n_qubits, dtype=np.uint8)
    for r in range(L):
        logical[edge_v(r, 0)] = 1
    base_weight = int(logical.sum())

    all_stabs = X_stab  # логический Z-тип коммутирует с X-стабилизаторами по построению теста
    min_weight_found = base_weight
    for _ in range(trials):
        mask = rng.integers(0, 2, size=all_stabs.shape[0], dtype=np.uint8)
        combo = (mask[:, None] * all_stabs).sum(axis=0) % 2
        candidate = (logical ^ combo)
        w = int(candidate.sum())
        if w < min_weight_found:
            min_weight_found = w
    return base_weight, min_weight_found


def run(L=4, seed=20260714):
    rng = np.random.default_rng(seed)
    X_stab, Z_stab, n = toric_code_binary_symplectic(L)

    rank_X = gf2_rank(X_stab)
    rank_Z = gf2_rank(Z_stab)
    # известное тождество для toric code на торе: ранг(X)=ранг(Z)=L*L-1
    n_stars = X_stab.shape[0]
    n_plaquettes = Z_stab.shape[0]

    n_independent = rank_X + rank_Z
    k_logical = n - n_independent  # логическая размерность (число логических кубитов)

    base_w, min_w = minimal_logical_weight(L, X_stab, Z_stab, n, trials=4000, rng=rng)

    # синдром для одиночной X-ошибки на случайном ребре: должен быть нетривиален
    err_qubit = int(rng.integers(0, n))
    error = np.zeros(n, dtype=np.uint8)
    error[err_qubit] = 1
    syndrome = (Z_stab @ error) % 2
    syndrome_nontrivial = bool(syndrome.any())

    report = {
        "artifact_id": "A2",
        "model": f"toric code, L={L}x{L}, periodic boundary conditions",
        "n_qubits": n,
        "n_star_stabilizers": n_stars,
        "n_plaquette_stabilizers": n_plaquettes,
        "rank_X_stabilizers": rank_X,
        "rank_Z_stabilizers": rank_Z,
        "expected_rank_each": L * L - 1,
        "n_logical_qubits_k": int(k_logical),
        "expected_k_on_torus": 2,
        "code_distance_lower_bound": min(base_w, min_w),
        "expected_distance": L,
        "single_qubit_error_gives_nontrivial_syndrome": syndrome_nontrivial,
        "checks": [],
    }

    def add_check(name, passed, detail):
        report["checks"].append({"name": name, "pass": bool(passed), "detail": detail})
        print(f"[{'PASS' if passed else 'FAIL'}] {name}\n       {detail}")

    add_check(
        "Ранг X- и Z-стабилизаторов = L^2-1 каждый (известный факт для тора)",
        rank_X == L * L - 1 and rank_Z == L * L - 1,
        f"rank_X={rank_X}, rank_Z={rank_Z}, ожидание={L*L-1}",
    )
    add_check(
        "Число логических кубитов k=2 (топологическое вырождение на торе)",
        k_logical == 2,
        f"k = n - rank_X - rank_Z = {n} - {rank_X} - {rank_Z} = {k_logical}",
    )
    add_check(
        f"Расстояние кода d=L={L} (минимальный вес нестягиваемой петли)",
        min(base_w, min_w) == L,
        f"базовый представитель вес={base_w}, минимум после {4000} случайных стабилизаторных сдвигов={min_w}",
    )
    add_check(
        "Одиночная ошибка даёт нетривиальный синдром (код обнаруживает ошибки)",
        syndrome_nontrivial,
        f"синдром для ошибки на кубите {err_qubit}: вес синдрома = {int(syndrome.sum())}",
    )
    add_check(
        "Контрпример: код полностью статичен -- ни гамильтониана эволюции, ни "
        "дисперсионного соотношения, ни HDA-алгебры ограничений в построении нет",
        True,
        "По построению: X_stab/Z_stab -- статические бинарные матрицы; "
        "локальность+QEC не требуют и не порождают динамику => "
        "QEC+локальность недостаточны для вывода Einstein dynamics.",
    )

    n_pass = sum(c["pass"] for c in report["checks"])
    report["summary"] = f"{n_pass}/{len(report['checks'])} checks passed"
    return report


if __name__ == "__main__":
    rep = run(L=4)
    with open("constraint_code_results.json", "w", encoding="utf-8") as fh:
        json.dump(rep, fh, ensure_ascii=False, indent=2)
    print(f"\n{rep['summary']}")
