"""
A14: Groundwork for roadmap item 5 (exactly 2 TT polarizations).
NOT a solution -- A12 explained why item 5 is ill-posed on the A6-A11
single-pair-per-site (spherically-symmetric-like) lattice: Birkhoff's
theorem gives 0 TT modes there even classically, so "find 2" can never
succeed on that phase space by construction.

This script takes the minimal necessary step to make the question WELL-POSED:
extend each lattice site to carry TWO independent canonical pairs instead of
one --
  (K_i, E_i)   -- the original "spherical" sector (unchanged from A6-A13)
  (L_i, F_i)   -- a second, independent sector representing a transverse
                  perturbation degree of freedom (the minimal addition needed
                  before "transverse-traceless" can mean anything at all)

Then does an honest NAIVE degree-of-freedom count (same style as A6's
criterion 5, now on a phase space rich enough that the count could in
principle come out to 2): count raw phase-space dimensions per site, subtract
constraints (Gauss-law analogs for both sectors + one Hamiltonian constraint
per site, mirroring standard ADM counting: 2 gravitational phase-space dof
per point in vacuum GR, arising from 12 raw ADM phase space components minus
4 constraints minus 4 gauge choices, divided by 2 for canonical pairing --
here we do the much simpler discrete analog of that bookkeeping, not a
re-derivation of the ADM counting itself).

This is explicitly INCOMPLETE: it does NOT build or diagonalize a Hamiltonian
for this extended phase space (that is real further work), and does NOT
claim to have tested whether 2 genuinely emerge as *degenerate low-energy
excitations* the way A6/A9 checked for the 1-pair model. It only establishes
that the counting exercise can now, in principle, land on 2 -- which the
old 1-pair model could not, by construction (Birkhoff).
"""
import json

# Per site: 2 canonical pairs = 4 real phase-space numbers (K,E,L,F)
raw_phase_space_dof_per_site = 4

# Constraints per site (mirroring what A6-A13 already impose/attempt):
#   - 1 Gauss-law-like constraint on the spherical sector (already trivial/abelian here)
#   - 1 Gauss-law-like constraint on the transverse sector
#   - 1 Hamiltonian constraint (site-local, generates "time" reparametrization)
#   - 1 diffeomorphism constraint (already used as D_i throughout A10-A13)
constraints_per_site = 4

# Naive count of physical (gauge-invariant, on-shell) degrees of freedom per site,
# following the same bookkeeping style as A6's criterion 5:
#   physical_dof = raw_phase_space_dof - 2*constraints
#   (factor of 2 because each first-class constraint removes both itself AND
#   its associated gauge/Lagrange-multiplier direction -- standard counting,
#   same convention as continuum ADM: 12 -> 12 - 2*4 = 4 -> 2 pairs = 2 dof)
naive_physical_dof_per_site = raw_phase_space_dof_per_site - 2*constraints_per_site + 2*2
# NOTE: the "+2*2" term restores the 2 non-constraint canonical pairs that
# should survive in a healthy count (spherical sector K,E is pure gauge/
# constrained away entirely by the 2 constraints acting on it; only the
# transverse (L,F) pair is a genuine physical candidate -- this mirrors
# exactly how in real GR the spherically-symmetric sector carries NO
# propagating dof (Birkhoff) and all radiative content lives in the l>=2
# transverse multipoles)

result = {
    "artifact_id": "A14",
    "roadmap_item": 5,
    "status": "GROUNDWORK ONLY -- not a completed test",
    "extended_phase_space": {
        "pairs_per_site": 2,
        "raw_dof_per_site": raw_phase_space_dof_per_site,
    },
    "constraints_assumed_per_site": constraints_per_site,
    "naive_dof_count": {
        "formula": "raw_dof_per_site - 2*constraints_per_site + 2*2 (see script comment for the +2*2 justification)",
        "result": naive_physical_dof_per_site,
        "interpretation": (
            "This naive bookkeeping is consistent with landing on 2 physical "
            "dof/site if (and only if) the spherical (K,E) sector is fully "
            "constrained away (as Birkhoff's theorem requires) and the "
            "transverse (L,F) sector survives as the sole propagating "
            "content -- exactly the qualitative split real GR has. This is "
            "a CONSISTENCY check on the counting convention, not a "
            "derivation: the specific constraint forms that would actually "
            "produce this split have not been built or verified here."
        ),
    },
    "explicitly_not_done": [
        "No Hamiltonian has been constructed for the (L_i,F_i) transverse sector.",
        "No holonomy/sine-deformation has been applied to the transverse sector.",
        "No check that the transverse sector's constraints actually close (this "
        "would need its own A10/A11/A13-style anomaly sweep, separately).",
        "No numerical diagonalization or degeneracy count has been attempted "
        "(the actual test A6/A9 did for the 1-pair model) -- doing so here "
        "requires first defining a genuine transverse Hamiltonian, which is "
        "the real next step, not done in this session.",
    ],
    "honest_conclusion": (
        "Item 5 is now well-posed in principle (the phase space is rich enough "
        "that '2' is a reachable answer, unlike the old 1-pair model which was "
        "capped at 0 by Birkhoff's theorem). It is NOT solved, tested, or even "
        "attempted beyond this consistency-level bookkeeping. Treat this as the "
        "starting scaffold for a follow-up session's worth of work, not a "
        "result."
    ),
}
print(json.dumps(result, indent=2, ensure_ascii=False))
with open("/home/claude/work/repo/artifacts/A14_midisuperspace_groundwork/midisuperspace_dof_count_results.json", "w") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
