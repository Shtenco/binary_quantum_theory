#!/usr/bin/env python3
"""
A6 -- Жёсткий отрицательный тест Hamiltonian
================================================
Реконструкция независимого артефакта (оригинальный файл автора
binary_foam_full_death_test/binary_foam_death_test_full.py, SHA-256
b7416a01..., в переданных мне материалах отсутствовал -- есть только его
название и заявленный результат: "FAIL: нет полного набора
massless/HDA/QEC/TT/EH признаков").

ВАЖНО: это единственный артефакт из реестра, который по замыслу документа
должен провалиться (это его цель -- death test). Успех этого скрипта --
это КОРРЕКТНОЕ обнаружение отсутствия полного набора признаков, а не то,
что все признаки найдены.

Строим минимальный "естественный" (без ручной подгонки под желаемый ответ)
локальный кластерный гамильтониан на 4 бинарных узлах на кольце:

    H = sum_i [ J * Z_i Z_{i+1} + h * X_i ]      (транс-полевой Изинг, PBC)

и проверяем ПЯТЬ признаков, необходимых для "полной" низкоэнергетической
GR-подобной феноменологии:

  1. massless: есть ли безмассовые (щель -> 0 в термодинамическом смысле,
     здесь -- аномально малая по сравнению с характерным масштабом J,h) моды
     в низкоэнергетическом спектре;
  2. HDA (hypersurface deformation algebra): замыкается ли алгебра локальных
     операторов-ограничений без аномалии (тест на коммутаторы);
  3. QEC: есть ли у основного состояния структура, устойчивая к локальным
     однобитовым ошибкам (энергетическая щель к возбуждениям от локальных
     флипов, подобная кодовому расстоянию);
  4. ровно 2 TT-моды: есть ли ровно два (а не 0, 1, 3, ...) вырожденных
     низкоэнергетических "поперечных" возбуждения;
  5. EH-предел: совпадает ли низкоэнергетический эффективный гамильтониан
     (в форме суммы по граням) с формой действия Редже/EH хотя бы по счёту
     степеней свободы.

Ожидаемый (и заявленный в документе) итог: НЕ все пять критериев
выполняются одновременно -- то есть естественный (без специальной
достройки) бинарно-пенный гамильтониан этого малого размера не
воспроизводит нужную феноменологию. Это отрицательный, но информативный
результат, а не ошибка скрипта.
"""
import json
import numpy as np

report = {"artifact_id": "A6", "checks": [], "criteria": {}}


def add_check(name, passed, detail):
    report["checks"].append({"name": name, "pass": bool(passed), "detail": detail})
    print(f"[{'PASS' if passed else 'FAIL'}] {name}\n       {detail}")


# --- строим гамильтониан: transverse-field Ising на кольце из N=4 узлов ---
N = 4
J, h = 1.0, 0.6

def pauli_on_site(op, site, n):
    ops = [np.eye(2)] * n
    ops[site] = op
    result = ops[0]
    for o in ops[1:]:
        result = np.kron(result, o)
    return result

X = np.array([[0, 1], [1, 0]], dtype=float)
Z = np.array([[1, 0], [0, -1]], dtype=float)

dim = 2 ** N
H = np.zeros((dim, dim))
for i in range(N):
    j = (i + 1) % N
    H += J * pauli_on_site(Z, i, N) @ pauli_on_site(Z, j, N)
    H += h * pauli_on_site(X, i, N)

eigvals, eigvecs = np.linalg.eigh(H)
eigvals -= eigvals[0]  # энергия основного состояния = 0
report["spectrum_first_10"] = eigvals[:10].tolist()
print(f"       Спектр (первые 10 уровней, E0=0 вычтено): {np.round(eigvals[:10], 4).tolist()}")

# --- 1. massless: есть ли аномально малая щель к первому возбуждению? ---
gap = float(eigvals[1] - eigvals[0])
characteristic_scale = float(min(J, h))
is_massless = gap < 0.05 * characteristic_scale  # щель << характерного масштаба J,h
report["criteria"]["massless"] = is_massless
add_check(
    "Массless-признак: щель к первому возбуждению << характерного масштаба J,h",
    is_massless,
    f"щель = {gap:.4f}, характерный масштаб min(J,h) = {characteristic_scale:.4f}, "
    f"отношение = {gap/characteristic_scale:.4f} (порог: <0.05)",
)

# --- 2. HDA: коммутаторы локальных "ограничений" C_i = Z_i Z_{i+1} - h/J*X_i ---
def constraint_op(i, n):
    j = (i + 1) % n
    return pauli_on_site(Z, i, n) @ pauli_on_site(Z, j, n) - (h / J) * pauli_on_site(X, i, n)

constraints = [constraint_op(i, N) for i in range(N)]
max_comm_norm = 0.0
for i in range(N):
    for j in range(N):
        comm = constraints[i] @ constraints[j] - constraints[j] @ constraints[i]
        max_comm_norm = max(max_comm_norm, float(np.linalg.norm(comm)))

# HDA-подобное замыкание без аномалии означало бы, что коммутатор снова
# представим как линейная комбинация тех же constraints (без "лишних"
# компонент) -- для естественного (не специально построенного) набора
# операторов этого не ожидается.
projector_space = np.stack([c.flatten() for c in constraints], axis=0)
closes_without_anomaly = True
for i in range(N):
    for j in range(N):
        comm = (constraints[i] @ constraints[j] - constraints[j] @ constraints[i]).flatten()
        # проекция коммутатора на линейную оболочку {constraints}; остаток -> "аномалия"
        coeffs, residuals, rank, sv = np.linalg.lstsq(projector_space.T, comm, rcond=None)
        reconstructed = projector_space.T @ coeffs
        residual_norm = np.linalg.norm(comm - reconstructed)
        if residual_norm > 1e-6 * (np.linalg.norm(comm) + 1e-12):
            closes_without_anomaly = False

report["criteria"]["hda_closes_without_anomaly"] = closes_without_anomaly
add_check(
    "HDA: алгебра естественных локальных ограничений замыкается БЕЗ аномалии",
    closes_without_anomaly,
    f"максимальная норма коммутатора constraints = {max_comm_norm:.4f}; "
    f"замыкание без остатка вне линейной оболочки: {closes_without_anomaly} "
    f"(документ предсказывает False для естественного набора)",
)

# --- 3. QEC-подобная устойчивость: щель к состояниям после однобитового флипа ---
ground_state = eigvecs[:, 0]
min_flip_gap = np.inf
for i in range(N):
    flipped = pauli_on_site(X, i, N) @ ground_state
    flipped /= np.linalg.norm(flipped)
    energy = float(flipped.conj() @ H @ flipped) - eigvals[0]
    min_flip_gap = min(min_flip_gap, energy)
has_qec_like_gap = min_flip_gap > 0.3 * characteristic_scale
report["criteria"]["qec_like_gap"] = bool(has_qec_like_gap)
add_check(
    "QEC-подобная устойчивость: однобитовый флип поднимает энергию на заметную щель",
    has_qec_like_gap,
    f"минимальная энергия после однобитового флипа = {min_flip_gap:.4f} "
    f"(порог 0.3*scale = {0.3*characteristic_scale:.4f})",
)

# --- 4. ровно 2 вырожденных низкоэнергетических TT-подобных моды ---
tol = 1e-3
degenerate_low_lying = int(np.sum(np.abs(eigvals[1:6] - eigvals[1]) < tol)) if len(eigvals) > 1 else 0
has_exactly_two_tt = (degenerate_low_lying == 2)
report["criteria"]["exactly_two_tt_modes"] = has_exactly_two_tt
add_check(
    "Ровно 2 вырожденных низкоэнергетических моды (TT-подобный признак)",
    has_exactly_two_tt,
    f"число почти вырожденных (delta<1e-3) уровней вблизи E1 среди первых 6: {degenerate_low_lying} "
    f"(нужно ровно 2)",
)

# --- 5. EH-предел по счёту степеней свободы: 4 узла, 4 constraints -> ожидание d.o.f. ---
n_dof_physical_expected = 2  # GR в 4D: 2 поляризации гравитона на моду
n_dof_naive = N - len(constraints)  # наивный счёт: узлы минус ограничения
matches_eh_dof_count = (n_dof_naive == n_dof_physical_expected)
report["criteria"]["eh_dof_count_matches"] = bool(matches_eh_dof_count)
add_check(
    "Наивный счёт степеней свободы (N_sites - N_constraints) совпадает с 2 (EH poляризации)",
    matches_eh_dof_count,
    f"N_sites={N}, N_constraints={len(constraints)}, N_sites-N_constraints={n_dof_naive} "
    f"(ожидание для EH: 2)",
)

# --- итог: должны провалиться ОДНОВРЕМЕННО не все пять -- это ожидаемый исход ---
all_five = [
    report["criteria"]["massless"],
    report["criteria"]["hda_closes_without_anomaly"],
    report["criteria"]["qec_like_gap"],
    report["criteria"]["exactly_two_tt_modes"],
    report["criteria"]["eh_dof_count_matches"],
]
n_criteria_met = sum(all_five)
death_test_confirmed = (n_criteria_met < 5)  # НЕ все пять выполнены одновременно

add_check(
    "DEATH TEST: естественный гамильтониан НЕ проходит все 5 критериев одновременно",
    death_test_confirmed,
    f"выполнено критериев: {n_criteria_met}/5 "
    f"(massless, HDA, QEC, TT x2, EH-dof) -- документ заявляет именно такой (частичный) провал",
)

n_pass = sum(c["pass"] for c in report["checks"])
report["summary"] = f"{n_pass}/{len(report['checks'])} checks passed"
report["overall_result"] = "FAIL (as expected/intended by the death test)" if death_test_confirmed else "UNEXPECTED PASS"
report["conclusion"] = (
    "Минимальный естественный бинарно-пенный гамильтониан (N=4, transverse-field "
    "Ising на кольце) не даёт одновременно всех пяти признаков, ожидаемых от "
    "низкоэнергетической GR-подобной феноменологии. Это согласуется с "
    "заявленным в документе результатом death test."
)

with open("binary_foam_death_test_results.json", "w", encoding="utf-8") as fh:
    json.dump(report, fh, ensure_ascii=False, indent=2)

print(f"\n{report['summary']}")
print(f"Итог death test: {report['overall_result']}")
