"""
A10: Constraint-algebra (HDA) closure test with holonomy corrections,
built on top of A1's own result. Roadmap item 4.

IMPORTANT SCOPE STATEMENT (read before the numbers):
This is NOT a reconstruction of the full spherically-symmetric ADM
Hamiltonian constraint from Bojowald/Brahma/Reyes (refs [6],[7] in the
main README) -- reproducing their exact regularization from memory would
risk silently introducing sign/convention errors and presenting them as
verified physics, which is precisely the kind of overclaiming this whole
repository is trying to avoid. Instead this builds the SIMPLEST
self-contained lattice toy that (a) uses the *exact* correction functions
f1(x)=sin^2(x), f2(x)=sin(x)cos(x), beta(x)=cos(2x) that A1 already proved
satisfy the closure recursion f2=(1/2)f1', beta=f2', and (b) has genuine
non-trivial coupling between neighboring constraints (via link/vertex
lattice-gauge-theory structure), so that the Poisson-bracket algebra is
not trivially zero by construction (as it would be for the disjoint-support
toy Hamiltonians used in A6/A9).

Phase space: ring of N vertices and N links (link i connects vertex i to
vertex i+1). Canonical pairs: {K_i, E_i} = 1 (link-holonomy-angle K_i
conjugate to the flux E_i "owned" by its left vertex i); all other
brackets zero. This is a simplified proxy for lattice gauge/LQG canonical
structure, not a literal derivation from the full theory.

Vertex "Hamiltonian-density" constraint (holonomy corrected, using A1's f1,
symmetrized over the two links touching vertex i):
    H_i = ( f1(delta*K_{i-1}) + f1(delta*K_i) ) / (2*delta^2) * E_i

Vertex "diffeomorphism-density" constraint (discretized momentum ~ E*K'):
    D_i = E_i * (K_i - K_{i-1})

Question: does {H_i, H_{i+1}} reduce to a clean multiple of D_i and/or
D_{i+1} (closure, with the multiplier playing the role of the classical
structure function / effective inverse metric q^xx), or does it contain
a residual term outside that span (anomaly)? And does whatever multiplier
appears reproduce A1's beta=cos(2*delta*K) sign-change behaviour?
"""
import sympy as sp
import json

N = 6
delta = sp.symbols('delta', positive=True)
K = sp.symbols(f'K0:{N}', real=True)
E = sp.symbols(f'E0:{N}', positive=True)

def f1(x): return sp.sin(x)**2
def f2(x): return sp.sin(x)*sp.cos(x)
def beta(x): return sp.cos(2*x)

def Kidx(i): return K[i % N]
def Eidx(i): return E[i % N]

def H(i):
    return (f1(delta*Kidx(i-1)) + f1(delta*Kidx(i))) / (2*delta**2) * Eidx(i)

def D(i):
    return Eidx(i) * (Kidx(i) - Kidx(i-1))

def poisson(f, g):
    """{f,g} = sum_i (df/dK_i dg/dE_i - df/dE_i dg/dK_i)"""
    total = 0
    for i in range(N):
        total += sp.diff(f, K[i]) * sp.diff(g, E[i]) - sp.diff(f, E[i]) * sp.diff(g, K[i])
    return sp.simplify(total)

results = []

# test {H_i, H_{i+1}} for a couple of vertex pairs (ring, so i=1,2 is generic/away from wraparound)
for i in [1, 2]:
    Hi, Hi1 = H(i), H(i+1)
    br = poisson(Hi, Hi1)
    br = sp.simplify(sp.expand_trig(sp.expand(br)))

    Di, Di1 = sp.expand(D(i)), sp.expand(D(i+1))

    # try to solve br = a*Di + b*Di1 for constants/functions a,b of K_i only (ansatz)
    a, b = sp.symbols('a b')
    # collect what's left after subtracting a*Di + b*Di1, then try solving
    # by matching the ratio symbolically using specific numeric substitution points
    residual_expr = sp.simplify(br - a*Di - b*Di1)

    # substitute several random rational numeric points for all K,E except keep delta symbolic,
    # then solve linear system for a,b at each point; check if a,b consistent (same fn of K_i) or not
    import random
    random.seed(7)
    subs_list = []
    for _ in range(4):
        subs = {Kidx(j): sp.Rational(random.randint(-9,9), random.randint(2,6)) for j in range(N)}
        subs.update({Eidx(j): sp.Rational(random.randint(1,9), random.randint(1,4)) for j in range(N)})
        subs_list.append(subs)

    ab_solutions = []
    for subs in subs_list:
        eq = sp.Eq(residual_expr.subs(subs), 0)
        # residual_expr is linear in a,b (since br,Di,Di1 don't involve a,b)
        sol = sp.solve([residual_expr.subs(subs)], [a, b], dict=True)
        ab_solutions.append(str(sol))

    # brute force: does br lie EXACTLY (symbolically, all K,E, only delta free) in span{Di,Di1}
    # by solving for a,b as functions of delta*K_i, delta*K_{i-1}, delta*K_{i+1} using linear algebra
    # over a monomial basis after expand_trig
    exact_sol = sp.solve([sp.Eq(sp.expand(br - a*Di - b*Di1), 0)], [a, b], dict=True)

    row = {
        "pair": f"H_{i}, H_{i+1}",
        "bracket_simplified": str(br),
        "D_i": str(Di), "D_i+1": str(Di1),
        "numeric_ab_solutions_at_4_random_points": ab_solutions,
        "exact_symbolic_solve_result": str(exact_sol),
    }
    results.append(row)
    print(f"--- {{H_{i}, H_{i+1}}} ---")
    print("bracket:", br)
    print("exact symbolic solve for a,b (const w.r.t. K,E):", exact_sol)
    print()

with open("/home/claude/work/repo/artifacts/A10_hda_anomaly_test/hda_closure_results.json", "w") as f:
    json.dump({"artifact_id": "A10", "N": N, "results": results}, f, indent=2)
