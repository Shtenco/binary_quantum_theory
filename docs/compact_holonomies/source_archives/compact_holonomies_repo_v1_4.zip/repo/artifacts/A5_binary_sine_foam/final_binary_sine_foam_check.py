#!/usr/bin/env python3
"""
A5 -- Бинарная синус-пена: базовые проверки
===============================================
Реконструкция независимого артефакта (оригинальный файл автора
final_binary_sine_foam/final_binary_sine_foam_check.py, SHA-256
e2a2c889..., в переданных мне материалах отсутствовал -- есть только его
название и назначение: "однобитовый no-go, составная кривизна,
малокривизный предел").

Три проверки:

  1. Однобитовый no-go: если K -- инволюция (K^2=I, напр. одна пара
     собственных значений +-1, как у бита/кубита), то [sin(delta*K)/delta]^2
     = (sin^2(delta)/delta^2) * I -- то есть оператор ПРОПОРЦИОНАЛЕН
     единичному, кривизна НЕ зависит от состояния. Одного бита недостаточно
     для state-dependent кривизны (см. Приложение Б документа).

  2. Составная кривизна: беря ДВА бита (K = K1 (x) I + I (x) K2, тензорное
     произведение двух инволюций) кривизна уже становится зависящей от
     состояния (собственные значения sin(delta*K)/delta различаются между
     секторами), то есть один бит -- предельный случай, двух уже достаточно
     для нетривиальной composite curvature.

  3. Малокривизный предел: sin(delta*K)/delta -> K при delta -> 0,
     проверено отдельно для обоих случаев (1 бит и 2 бита).
"""
import json
import numpy as np

report = {"artifact_id": "A5", "checks": []}


def add_check(name, passed, detail):
    report["checks"].append({"name": name, "pass": bool(passed), "detail": detail})
    print(f"[{'PASS' if passed else 'FAIL'}] {name}\n       {detail}")


# --- 1. Однобитовый no-go ---
sigma_z = np.array([[1, 0], [0, -1]], dtype=float)  # K^2 = I по построению
assert np.allclose(sigma_z @ sigma_z, np.eye(2))

deltas = [0.3, 0.7, 1.1, 1.9, 2.5]
max_dev = 0.0
for delta in deltas:
    w, V = np.linalg.eigh(sigma_z)
    op = V @ np.diag(np.sin(delta * w) / delta) @ V.conj().T
    op_sq = op @ op
    predicted = (np.sin(delta) ** 2 / delta ** 2) * np.eye(2)
    dev = np.linalg.norm(op_sq - predicted)
    max_dev = max(max_dev, dev)

add_check(
    "Однобитовый no-go: [sin(delta*K)/delta]^2 = (sin^2(delta)/delta^2)*I  при K^2=I",
    max_dev < 1e-10,
    f"максимальное отклонение по delta in {deltas}: {max_dev:.2e} -- "
    f"оператор пропорционален I, кривизна не зависит от состояния",
)

# --- 2. Составная кривизна: 2 бита, K = K1 (x) I + I (x) K2 ---
K1 = np.array([[1, 0], [0, -1]], dtype=float)
K2 = np.array([[1, 0], [0, -1]], dtype=float)
I2 = np.eye(2)
K_composite = np.kron(K1, I2) + np.kron(I2, K2)  # собственные значения: -2,0,0,2

delta = 0.9
w, V = np.linalg.eigh(K_composite)
op_composite = V @ np.diag(np.sin(delta * w) / delta) @ V.conj().T

# если бы кривизна была "state-independent" (как в однобитовом случае),
# оператор был бы кратен единичному. Проверяем, что это НЕ так:
is_multiple_of_identity = np.allclose(
    op_composite, op_composite[0, 0] * np.eye(4), atol=1e-8
)
eigenvalues_distinct = len(set(np.round(w, 6))) > 1

add_check(
    "Составная кривизна: два бита дают state-dependent sin(delta*K)/delta (не кратно I)",
    (not is_multiple_of_identity) and eigenvalues_distinct,
    f"собственные значения K_composite = {sorted(w.tolist())}, "
    f"sin(delta*K)/delta кратен единичной матрице: {is_multiple_of_identity} (ожидание: False)",
)

# --- 3. Малокривизный предел для обоих случаев ---
def small_curvature_limit_error(K, deltas):
    errs = []
    for d in deltas:
        w, V = np.linalg.eigh(K)
        op = V @ np.diag(np.sin(d * w) / d) @ V.conj().T
        errs.append(np.linalg.norm(op - K))
    return errs

small_deltas = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5]
errs_1bit = small_curvature_limit_error(sigma_z, small_deltas)
errs_2bit = small_curvature_limit_error(K_composite, small_deltas)

mono_1bit = all(errs_1bit[i] > errs_1bit[i + 1] for i in range(len(errs_1bit) - 1))
mono_2bit = all(errs_2bit[i] > errs_2bit[i + 1] for i in range(len(errs_2bit) - 1))

add_check(
    "Малокривизный предел sin(delta*K)/delta -> K (1 бит)",
    mono_1bit and errs_1bit[-1] < 1e-9,
    f"ошибки при delta=1e-1..1e-5: {['%.2e' % e for e in errs_1bit]}",
)
add_check(
    "Малокривизный предел sin(delta*K)/delta -> K (2 бита, составной оператор)",
    mono_2bit and errs_2bit[-1] < 1e-9,
    f"ошибки при delta=1e-1..1e-5: {['%.2e' % e for e in errs_2bit]}",
)

n_pass = sum(c["pass"] for c in report["checks"])
report["summary"] = f"{n_pass}/{len(report['checks'])} checks passed"
report["conclusion"] = (
    "Один инволютивный генератор (K^2=I) даёт кривизну, пропорциональную "
    "единичному оператору -- state-independent, недостаточно для "
    "физической (state-dependent) кривизны. Уже двух генераторов достаточно, "
    "чтобы получить нетривиальную (composite) state-dependent структуру. "
    "Малокривизный предел sin(delta*K)/delta->K выполняется в обоих случаях."
)

with open("final_binary_sine_foam_results.json", "w", encoding="utf-8") as fh:
    json.dump(report, fh, ensure_ascii=False, indent=2)

print(f"\n{report['summary']}")
