#!/usr/bin/env python3
"""
Независимая проверка всех проверяемых расчётов из документа
"Компактные голономии как микроскопика геометрии" v1.0 (Е. Коштенко, 14.07.2026)

Каждый тест пересчитывает утверждение документа с нуля (своими средствами),
а не сверяет цифры, приведённые в самом документе. PASS/FAIL печатается явно.

Зависимости: numpy, scipy
"""

import numpy as np
from scipy.linalg import expm
from scipy import integrate, stats

np.random.seed(42)
PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
results = []

def check(name, condition, detail=""):
    tag = PASS if condition else FAIL
    print(f"[{tag}] {name}")
    if detail:
        print(f"       {detail}")
    results.append((name, bool(condition)))


print("=" * 78)
print("1.1  cos(m*eps)^N -> exp(-m^2 t)  при N*eps^2/2 = t,  N -> inf")
print("=" * 78)

def heat_kernel_error_order():
    m = 1.7
    t = 0.35
    errs, epss = [], []
    for eps in [0.2, 0.1, 0.05, 0.025, 0.0125, 0.00625]:
        N = int(round(2 * t / eps**2))
        t_eff = N * eps**2 / 2          # реально достигнутое N*eps^2/2 (N целое!)
        approx = np.cos(m * eps) ** N
        exact = np.exp(-m**2 * t_eff)   # сравниваем на ТОМ ЖЕ t_eff, иначе округление
        errs.append(abs(approx - exact))  # N->int маскирует чистую eps^2-асимптотику
        epss.append(eps)
    # порядок сходимости: err ~ C * eps^p  =>  p = наклон log(err) vs log(eps)
    logs_e = np.log(epss)
    logs_err = np.log(errs)
    p, intercept = np.polyfit(logs_e, logs_err, 1)
    return p, list(zip(epss, errs))

order, pairs = heat_kernel_error_order()
for eps, err in pairs:
    print(f"       eps={eps:<9} |cos(m*eps)^N - exp(-m^2 t)| = {err:.3e}")
check("Порядок сходимости к тепловому ядру ~ O(eps^2)",
      1.9 <= order <= 2.1,
      f"измеренный порядок p = {order:.4f} (документ заявляет ≈2.0035)")


print()
print("=" * 78)
print("1.4  (U - U^dagger)/(2i*delta) = sin(delta*K)/delta   [точное тождество]")
print("=" * 78)

def holonomy_sine_identity(dim=6, trials=200):
    max_err = 0.0
    for _ in range(trials):
        A = np.random.randn(dim, dim) + 1j * np.random.randn(dim, dim)
        K = (A + A.conj().T) / 2  # самосопряжённый генератор
        delta = np.random.uniform(0.01, 2.0)
        U = expm(1j * delta * K)
        lhs = (U - U.conj().T) / (2j * delta)
        # sin(delta*K)/delta через спектральное разложение
        w, V = np.linalg.eigh(K)
        rhs = V @ np.diag(np.sin(delta * w) / delta) @ V.conj().T
        err = np.linalg.norm(lhs - rhs)
        max_err = max(max_err, err)
    return max_err

err = holonomy_sine_identity()
check("Точное операторное тождество (U-U†)/(2iδ)=sin(δK)/δ",
      err < 1e-10,
      f"максимальное отклонение по 200 случайным самосопряж. K, dim=6: {err:.2e}")


print()
print("=" * 78)
print("1.4  ||sin(X) - X|| <= ||X||^3 / 6   [оценка остатка]")
print("=" * 78)

def sine_remainder_bound(dim=6, trials=500):
    violations = 0
    ratios = []
    for _ in range(trials):
        A = np.random.randn(dim, dim) + 1j * np.random.randn(dim, dim)
        X = (A + A.conj().T) / 2
        scale = np.random.uniform(0.01, 3.0)
        X = X / np.linalg.norm(X, 2) * scale
        w, V = np.linalg.eigh(X)
        sinX = V @ np.diag(np.sin(w)) @ V.conj().T
        lhs = np.linalg.norm(sinX - X, 2)
        rhs = np.linalg.norm(X, 2) ** 3 / 6
        ratios.append(lhs / rhs if rhs > 0 else 0)
        if lhs > rhs + 1e-12:
            violations += 1
    return violations, max(ratios)

violations, max_ratio = sine_remainder_bound()
check("Оценка ||sinX - X|| <= ||X||^3/6 не нарушается",
      violations == 0,
      f"нарушений: {violations}/500, max(||sinX-X||/(||X||^3/6)) = {max_ratio:.4f} (<=1 ожидается)")


print()
print("=" * 78)
print("1.4  S_sin - S_Regge = O_P(a^4)  для типичной голономии X_f = O_P(a^2)")
print("=" * 78)

def action_error_order(trials=40):
    orders = []
    for _ in range(trials):
        errs, avals = [], []
        for a in [0.4, 0.2, 0.1, 0.05]:      # a=0.025 -> a^-4=2.56e6 граней, слишком
            n_faces = int(round(a ** -4))     # дорого; обрезка cap'ом искажала порядок
            X_f = np.random.normal(0, 1, n_faces) * a**2   # типичный масштаб O(a^2)
            A_f = a**2                                      # площадь грани ~ a^2
            action_err = np.sum(np.abs(np.sin(X_f) - X_f)) * A_f
            errs.append(action_err)
            avals.append(a)
        p, _ = np.polyfit(np.log(avals), np.log(errs), 1)
        orders.append(p)
    return np.mean(orders), np.std(orders)

mean_p, std_p = action_error_order()
check("Суммарная ошибка действия масштабируется как O(a^4)",
      3.5 <= mean_p <= 4.5,
      f"измеренный порядок p = {mean_p:.3f} +/- {std_p:.3f} по 40 реализациям (документ: O_P(a^4))")


print()
print("=" * 78)
print("1.3  Union bound: P(exists f: |X_f|>=pi/2) <= C*a^-4*exp[-pi^2/(16*c*a^4)]")
print("=" * 78)

def union_bound_check():
    """
    Конвенция сходимости из §1.1: множитель на моде m равен exp(-m^2 t),
    что соответствует фурье-образу гауссианы N(0, sigma^2) с sigma^2 = 2t
    (так как E[e^{imX}] = exp(-m^2 sigma^2/2)). Документ полагает t_a ~ c*a^4,
    значит эффективная дисперсия грани sigma^2 = 2*c*a^4, а НЕ c*a^4 напрямую.
    Проверяем, что при этой (неявной, но необходимой) конвенции формула
    из документа действительно является union-bound overестимейтом.
    """
    c = 1.3
    ok_all = True
    rows = []
    for a in [0.5, 0.3, 0.2, 0.1]:
        sigma2 = 2 * c * a**4          # <-- ключевая, неявная в документе подстановка
        n_faces = a ** -4
        # точная гауссова хвостовая вероятность одной грани
        p_single = 2 * (1 - stats.norm.cdf(np.pi / 2, scale=np.sqrt(sigma2)))
        union_exact = min(1.0, n_faces * p_single)
        # формула документа (с C=1 для сравнения порядка убывания)
        doc_bound = n_faces * np.exp(-np.pi**2 / (16 * c * a**4))
        rows.append((a, union_exact, doc_bound))
        # документ должен быть валидной (не обязательно самой туго натянутой) верхней оценкой
        # по порядку убывания экспоненты -- сравниваем показатели экспонент
        exact_exponent = -np.pi**2 / (2 * sigma2)   # = -pi^2/(4*c*a^4)
        doc_exponent = -np.pi**2 / (16 * c * a**4)
        if doc_exponent < exact_exponent - 1e-9:
            # оценка документа убывает БЫСТРЕЕ точного хвоста -> не валидная верхняя оценка
            ok_all = False
    for a, ue, db in rows:
        print(f"       a={a:<5}  точный union tail ~ {ue:.3e}   формула документа (C=1) ~ {db:.3e}")
    return ok_all

ok = union_bound_check()
check("Формула union bound корректна ПРИ явной подстановке sigma^2=2*t_a=2*c*a^4",
      ok,
      "Без этой подстановки (если по невнимательности взять sigma^2=t_a=c*a^4 "
      "'напрямую' из §1.2) показатель экспоненты в §1.3 получился бы pi^2/(8*c*a^4), "
      "а не pi^2/(16*c*a^4) -- см. предыдущий обзор.")


print()
print("=" * 78)
print("2.1  sin(i*theta) = i*sinh(theta);  малокривизный предел sin(dK)/d -> K")
print("=" * 78)

theta = np.linspace(-4, 4, 2000)
err1 = np.max(np.abs(np.sin(1j * theta) - 1j * np.sinh(theta)))
check("sin(i*theta) = i*sinh(theta)", err1 < 1e-12, f"max|LHS-RHS| = {err1:.2e}")

K = np.diag([0.3, -1.1, 2.4])
deltas = [1e-1, 1e-2, 1e-3, 1e-4, 1e-6]
diffs = [np.linalg.norm(np.sin(d * K) / d - K) for d in deltas]
monotone = all(diffs[i] > diffs[i+1] for i in range(len(diffs)-1))
check("sin(delta*K)/delta -> K при delta -> 0 (монотонное убывание ошибки)",
      monotone and diffs[-1] < 1e-8,
      f"delta=1e-1..1e-6: ошибки = {['%.2e' % x for x in diffs]}")


print()
print("=" * 78)
print("2.1  Смена знака: beta = cos(2*delta*K), beta = -1 при delta*K = pi/2")
print("=" * 78)

dK = np.pi / 2
beta = np.cos(2 * dK)
check("cos(2*delta*K) = -1 при delta*K = pi/2", abs(beta - (-1)) < 1e-12,
      f"cos(pi) = {beta:.10f}")


print()
print("=" * 78)
print("4.  Bekenstein bound (E=M, R=2GM) алгебраически = S_BH = A/(4G)")
print("=" * 78)

import sympy as sp
G, M = sp.symbols('G M', positive=True)
S_bekenstein = 2 * sp.pi * M * (2 * G * M)          # 2*pi*E*R
A = 4 * sp.pi * (2 * G * M) ** 2                     # площадь горизонта
S_BH = A / (4 * G)
diff = sp.simplify(S_bekenstein - S_BH)
check("2*pi*E*R (E=M,R=2GM)  ==  A/(4G)  символьно", diff == 0,
      f"S_Bekenstein = {sp.simplify(S_bekenstein)},  S_BH = {sp.simplify(S_BH)},  разность = {diff}")


print()
print("=" * 78)
print("4.  Schwarzschild: собственное время свободного падения из бесконечности")
print("    от горизонта (r=2M) до r=0  =  4M/3   (G=c=1)")
print("=" * 78)

def schwarzschild_proper_time(Mval=1.0):
    # dr/dtau = -sqrt(2M/r)  =>  dtau = -sqrt(r/2M) dr, интегрируем r: 2M -> 0
    integrand = lambda r: np.sqrt(r / (2 * Mval))
    val, err = integrate.quad(integrand, 0, 2 * Mval)
    return val

tau_num = schwarzschild_proper_time(1.0)
tau_exact = 4.0 / 3.0
check("Численное интегрирование dtau/dr дает 4M/3 (M=1)",
      abs(tau_num - tau_exact) < 1e-9,
      f"численно: {tau_num:.10f},  4/3 = {tau_exact:.10f}")


print()
print("=" * 78)
print("ИТОГ")
print("=" * 78)
n_pass = sum(1 for _, ok in results if ok)
n_total = len(results)
for name, ok in results:
    print(f"  [{PASS if ok else FAIL}] {name}")
print(f"\n{n_pass}/{n_total} проверок пройдено.")
if n_pass < n_total:
    print("ВНИМАНИЕ: есть непройденные проверки, см. выше.")
