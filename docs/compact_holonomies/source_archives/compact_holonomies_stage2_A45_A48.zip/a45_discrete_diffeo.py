"""A45 — discrete spatial diffeomorphisms on the SU(2) cycle (stage-1 model).

Translation Tr: edge e -> e+1 (cyclic relabeling of tensor factors).
Claims (frozen in TZ): [Tr,M]=[Tr,W]=[Tr,H]=0 exactly; Tr acts as identity
on H_phys; dim H_diff = dim H_phys.
"""
import sys, json
import numpy as np
sys.path.insert(0, '/home/claude/qg')
from a43_a44_constrained_graph import build_cycle, physical_projector

def translation_operator(d, E):
    """Unitary permutation of tensor factors: index (i_0,...,i_{E-1}) ->
    (i_{E-1}, i_0, ..., i_{E-2})  (shift edges by +1)."""
    dimF = d ** E
    perm = np.empty(dimF, dtype=np.int64)
    for n in range(dimF):
        # decode base-d digits, most significant = edge 0
        digits = []
        x = n
        for _ in range(E):
            digits.append(x % d)
            x //= d
        digits = digits[::-1]           # edge 0 ... edge E-1
        new = [digits[-1]] + digits[:-1]  # edge e content moves to e+1
        val = 0
        for dig in new:
            val = val * d + dig
        perm[n] = val
    Tr = np.zeros((dimF, dimF))
    Tr[perm, np.arange(dimF)] = 1.0
    return Tr

def run(two_jmax=1, E=3, g2=1.0, lam=0.7):
    C = build_cycle(two_jmax, E)
    d, dimF = C['d'], C['dimF']
    Tr = translation_operator(d, E)
    out = {'two_jmax': two_jmax, 'E': E, 'dim_kin': dimF}
    out['unitary'] = float(np.linalg.norm(Tr @ Tr.T - np.eye(dimF)))
    out['order_E'] = float(np.linalg.norm(np.linalg.matrix_power(Tr, E) - np.eye(dimF)))
    Wh = (C['W'] + C['W'].conj().T) / 2
    H = g2 * C['Cas'] - lam * Wh
    out['[Tr,M]'] = float(np.linalg.norm(Tr @ C['M'] - C['M'] @ Tr))
    out['[Tr,W]'] = float(np.linalg.norm(Tr @ C['W'] - C['W'] @ Tr))
    out['[Tr,H]'] = float(np.linalg.norm(Tr @ H - H @ Tr))
    P, null = physical_projector(C['M'])
    out['dim_phys'] = null.shape[1]
    # Tr restricted to H_phys must be the identity (class functions of the loop)
    Tr_red = null.conj().T @ Tr @ null
    out['Tr_on_Hphys_vs_identity'] = float(np.linalg.norm(Tr_red - np.eye(null.shape[1])))
    # diff-invariant physical subspace
    wT, VT = np.linalg.eig(Tr_red)
    out['dim_diff_inv_phys'] = int(np.sum(np.abs(wT - 1) < 1e-9))
    return out

if __name__ == '__main__':
    R = {}
    for (tj, E) in [(1, 3), (1, 4), (2, 2)]:
        r = run(tj, E)
        R[f'jmax={tj/2}_E={E}'] = r
        print(f'-- jmax={tj/2}, E={E} (dim {r["dim_kin"]})')
        for k, v in r.items():
            print(f'   {k} = {v}')
    json.dump(R, open('/home/claude/qg2/A45_results.json', 'w'), indent=1)
