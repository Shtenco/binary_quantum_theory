"""A46 — quantum homogeneous-sector gravity from the program's sine operator.
A47 — exact operator bound on the density.
A48 — hashed held-out death test.

Frozen microtheory (TZ_STAGE2, sha256 5deb8eeb...):
  volume lattice v in {..., -6, -2, 2, 6, ...} (step 4, v=0 excluded)
  T psi(v)  = 2 v^2 psi(v) - |v||v+4| psi(v+4) - |v||v-4| psi(v-4)
  Theta     = (3 pi G / 4) T,   G = 1  (declared input)
  symbol    : Theta_cl = 3 pi G v^2 sin^2(2b)   ->  p_phi^2
  classical : b -> 0 gives p_phi^2 = 12 pi G v^2 b^2  (flat FRW, massless clock)
  observables: V(phi) = <|v|>,  rho(phi) = <p_phi^2> / (2 <|v|>^2)
Preregistered: P1 min V > 0;  P2 rho_max <= rho_c = 3 pi G / 2, and -> rho_c
for semiclassical packets; P3 symmetric bounce.
"""
import numpy as np, json, hashlib
from scipy.linalg import eigh_tridiagonal

G = 1.0
RHO_C = 3 * np.pi * G / 2

def build_theta(nside):
    """Positive-sector half-line grid v = 2, 6, 10, ...  (ERRATUM_STAGE2)."""
    v = (4 * np.arange(nside) + 2).astype(float)
    diag = 2 * v ** 2
    off = -v[:-1] * v[1:]
    pref = 3 * np.pi * G / 4
    return v, pref * diag, pref * off

def evolve_packet(nside, p0, sig_rel, phis):
    """Coherent semiclassical packet: Gaussian in v centred on the classical
    trajectory at large volume, decomposed onto the Theta eigenbasis and
    evolved with positive frequency e^{i omega phi}."""
    v, diag, off = build_theta(nside)
    w, Vec = eigh_tridiagonal(diag, off)
    om = np.sqrt(np.clip(w, 0, None))
    # coherent complex packet on the classical trajectory at v* = 3 v_b
    v_b = p0 / np.sqrt(2 * RHO_C)
    v_star = 3.0 * v_b
    s = min(p0 / (np.sqrt(3 * np.pi * G) * v_star), 1.0)
    theta = 2 * np.arcsin(s)
    dv_opt = np.sqrt(v_star / np.tan(theta / 2))
    dv = max(dv_opt, v_star * sig_rel / np.sqrt(2.0))
    n_idx = np.arange(len(v))
    psi0 = np.exp(-(v - v_star) ** 2 / (4 * dv ** 2)) * np.exp(-1j * theta * n_idx)
    psi0 /= np.linalg.norm(psi0)
    c = Vec.T @ psi0
    # locate the bounce of the coherent packet
    absv0 = np.abs(v)
    phb_grid = np.linspace(-0.8, 0.8, 161)
    Vb = []
    for ph in phb_grid:
        pr = np.abs(Vec @ (c * np.exp(1j * om * ph))) ** 2
        Vb.append(pr @ absv0)
    phi_b = float(phb_grid[int(np.argmin(Vb))])
    # exactly phi-symmetric bounce-centred state: real projection at the bounce
    d = c * np.exp(1j * om * phi_b)
    alpha = 0.5 * np.angle(np.sum(d ** 2))
    c = np.real(d * np.exp(-1j * alpha))
    c /= np.linalg.norm(c)
    p2 = float(np.sum(np.abs(c) ** 2 * om ** 2))
    p1 = float(np.sum(np.abs(c) ** 2 * om))
    sig_meas = np.sqrt(max(p2 - p1 ** 2, 0.0)) / p1
    absv = np.abs(v)
    Vt, boundary = [], []
    for phi in phis:
        psi = Vec @ (c * np.exp(1j * om * phi))
        prob = np.abs(psi) ** 2
        Vt.append(float(prob @ absv))
        boundary.append(float(prob[:5].sum() + prob[-5:].sum()))
    Vt = np.array(Vt)
    rho = p2 / (2 * Vt ** 2)
    # operator-ordered density rho_op = (1/2) M_{1/v} Theta M_{1/v}: its
    # expectation obeys the exact operator bound of A47 at every phi
    d2 = diag / v ** 2
    o2 = off / (v[:-1] * v[1:])
    rho_op = []
    for phi in phis:
        psi = Vec @ (c * np.exp(1j * om * phi))
        val = np.real(np.conj(psi) @ (d2 * psi)
                      + np.conj(psi[:-1]) @ (o2 * psi[1:])
                      + np.conj(psi[1:]) @ (o2 * psi[:-1]))
        rho_op.append(0.5 * val)
    return dict(v=v, Vt=Vt, rho=rho, rho_op=np.array(rho_op), p2=p2,
                sig_rel_measured=float(sig_meas),
                max_boundary_prob=float(max(boundary)))

def a46(nside=1600, p0=300.0, sig_rel=0.03, nphi=121, phimax=0.45):
    phis = np.linspace(-phimax, phimax, nphi)
    r = evolve_packet(nside, p0, sig_rel, phis)
    Vt, rho = r['Vt'], r['rho']
    ib = int(np.argmin(Vt))
    # P3 symmetry around the bounce point: compare mirrored windows
    half = min(ib, len(phis) - 1 - ib)
    seg_l = Vt[ib - half: ib][::-1]
    seg_r = Vt[ib + 1: ib + 1 + half]
    asym = float(np.max(np.abs(seg_l - seg_r)) / Vt.max()) if half > 3 else float('nan')
    out = dict(nside=nside, p0=p0, sig_rel_target=sig_rel,
               sig_rel_measured=r['sig_rel_measured'],
               boundary_leak=r['max_boundary_prob'],
               bounce_phi=float(phis[ib]),
               P1_minV=float(Vt.min()),
               P2_rho_max=float(rho.max()),
               P2_rho_c=RHO_C,
               P2_ratio=float(rho.max() / RHO_C),
               P2_bound_respected=bool(rho.max() <= RHO_C * (1 + 1e-6)),
               P2_rho_op_max=float(r['rho_op'].max()),
               P2_op_ratio=float(r['rho_op'].max() / RHO_C),
               P2_op_bound_respected=bool(r['rho_op'].max() <= RHO_C * (1 + 1e-12)),
               P3_asymmetry=asym)
    out['P1_pass'] = out['P1_minV'] > 0
    strict = out['sig_rel_measured'] <= 0.05
    out['P2_strict_clause_applicable'] = bool(strict)
    out['P2_pass'] = out['P2_bound_respected'] and \
        ((out['P2_ratio'] >= 0.9) if strict else True)
    out['P3_pass'] = asym < 1e-3
    return out

def a47(nsides=(200, 400, 800, 1600, 3200)):
    """Operator bound: K = M_{1/|v|} Theta M_{1/|v|};  ||K|| <= 3 pi G,
    convergence from below."""
    norms = []
    for ns in nsides:
        v, diag, off = build_theta(ns)
        d2 = diag / v ** 2
        o2 = off / (np.abs(v[:-1]) * np.abs(v[1:]))
        w = eigh_tridiagonal(d2, o2, select='i',
                             select_range=(ns - 1, ns - 1))[0]
        norms.append(float(w[0]))
    bound = 3 * np.pi * G
    viol = max(n - bound for n in norms)
    gaps = [bound - n for n in norms]
    rate = float(np.polyfit(np.log(nsides), np.log(gaps), 1)[0])
    return dict(nsides=list(nsides), norms=norms, bound=bound,
                max_violation=float(viol), gaps=gaps,
                convergence_rate_exponent=rate,
                pass_no_violation=bool(viol <= 1e-10),
                pass_converges=bool(all(gaps[i] > gaps[i+1] for i in range(len(gaps)-1))))

def a48():
    manifest = ('compact-holonomies A48 v1: held-out bounce test; '
                'p0 = 200 + (H mod 801); sig_rel = 0.02 + (H // 1000 mod 31)/1000; '
                'predictions P1-P3 of TZ_STAGE2 sha256=5deb8eeb2618d15cf7958d51d4'
                '75cceb1b7d8d8e988b0d17a94cf0b32525bfa0')
    h = hashlib.sha256(manifest.encode()).hexdigest()
    H = int(h, 16)
    p0 = 200 + (H % 801)
    sig_rel = 0.02 + ((H // 1000) % 31) / 1000.0
    res = a46(nside=2400, p0=float(p0), sig_rel=sig_rel)
    frozen_pass = res['P1_pass'] and res['P2_pass'] and res['P3_pass']
    res.update(manifest_sha256=h, held_out_p0=p0, held_out_sig_rel=sig_rel,
               verdict_frozen_P1P2P3='PASS' if frozen_pass else 'MODEL FAIL',
               operator_bound_verdict='PASS' if res['P2_op_bound_respected'] else 'FAIL')
    return res

if __name__ == '__main__':
    out = {}
    print('== A46: bounce, calibration packet ==')
    out['A46'] = a46()
    for k, v in out['A46'].items():
        print(f'   {k} = {v}')
    print('== A46b: semiclassicality scan (rho_max -> rho_c) ==')
    scan = []
    for p0 in (100.0, 200.0, 400.0, 800.0):
        r = a46(nside=2400, p0=p0, sig_rel=0.03, phimax=0.3)
        scan.append(dict(p0=p0, ratio=r['P2_ratio'], minV=r['P1_minV'],
                         leak=r['boundary_leak']))
        print(f"   p0={p0:6.0f}  rho_max/rho_c={r['P2_ratio']:.6f}  minV={r['P1_minV']:.2f}  leak={r['boundary_leak']:.1e}")
    out['A46b_scan'] = scan
    dev = [1 - s['ratio'] for s in scan]
    p_fit = float(np.polyfit(np.log([s['p0'] for s in scan]), np.log(dev), 1)[0])
    out['A46b_deviation_exponent_in_p0'] = p_fit
    print('   deviation 1 - rho_max/rho_c ~ p0^', p_fit)
    print('== A47: operator bound ==')
    out['A47'] = a47()
    for k, v in out['A47'].items():
        print(f'   {k} = {v}')
    print('== A48: hashed held-out death test ==')
    out['A48'] = a48()
    for k, v in out['A48'].items():
        print(f'   {k} = {v}')
    json.dump(out, open('/home/claude/qg2/A46_A48_results.json', 'w'), indent=1)
