# Compact Holonomies 2.2.0

- Added `A28`: exact `N_chiral=|Q|` zero-mode counting; `Q=+/-3` gives three
  same-chirality overlap modes across six unselected lattice trials.
- Added `A29`: exact representation-trace relation
  `g3^2=g2^2=(5/3)gY^2` and `sin^2(theta_W)=3/8` under explicit assumptions.
- Added `A30`: held-out gauge-coupling death test.  Minimal exact one-loop SM
  unification predicts `alpha_s(MZ)=0.0710658`, versus the frozen PDG-2024
  benchmark `0.1180+/-0.0009`; the minimal model is rejected.
- Added `A31`: no-go proof that current anomaly/parity/asymptotic-freedom
  constraints allow `N_g=1,...,5` and do not select three generations.
- Added `A32`: constant-profile flavor no-go; three topological modes remain
  exactly degenerate without additional derived symmetry breaking.
- Prediction registry expanded from 9 to 14 entries and now records one failed
  continuous physical prediction rather than claiming only successes.
- Test suite expanded from 32 to 39 tests.
- Successful continuous-constant coverage remains `0/445`.
