# Compact Holonomies v2.4 — constrained multi-vertex quantum graph

## New verified chain

```text
finite compact Weyl kinematics
  -> positive relational quantum dynamics
  -> multi-edge tensor-product Hilbert space
  -> exact local Gauss transformations
  -> joint physical projector
  -> positive master constraint
  -> gauge-invariant Hamiltonian preserving physical states
  -> exact physical-rank invariance under cycle subdivision
```

## A37

For a `Z_3` cycle with four edges, `dim(H_kin)=81` and
`dim(H_phys)=3`.  The local constraints, Wilson loop and projector agree to
machine precision.

## A38

The master-constraint kernel equals the physical projector image.  The
Hamiltonian commutes with both to about `10^-14`–`10^-15`, and evolved physical
states leak outside the constraint surface by only `2.59e-15`.

## A39

For three, four and five edge subdivisions of the same cycle, the reduced
physical dimension remains `3`.  This is a controlled topological refinement
result.

## Honest status

This is now more than a one-operator toy: it is an explicit local constrained
quantum graph with physical states and preserving dynamics.  It is still not
quantum gravity because:

- the gauge group is finite Abelian `Z_N`, not gravitational `SU(2)`;
- there are no area/volume operators tied to 3D geometry;
- there is no diffeomorphism constraint;
- the Hamiltonian is a gauge Hamiltonian, not a quantization of the Einstein
  Hamiltonian constraint;
- no quantum hypersurface-deformation algebra is obtained;
- no 3+1 semiclassical Einstein limit or physical prediction is derived.

## Registry status

- Registered results: **21**.
- Tests: **52** expected in this release.
- Continuous physical predictions tested: **1**.
- Continuous physical predictions passed: **0**.
- Successful coverage: **0/445**.

The next target is A40–A44: non-Abelian spin-network kinematics, geometric
operators, local intertwiner projection, a candidate master constraint, and a
held-out semiclassical/refinement death test.
