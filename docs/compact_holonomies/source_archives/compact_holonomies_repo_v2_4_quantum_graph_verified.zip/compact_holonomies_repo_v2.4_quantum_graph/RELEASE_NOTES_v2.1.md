# Compact Holonomies 2.1.0 — chiral matter extension

- Added a 2D compact U(1) overlap-fermion test bed with exact GW chirality and
  integer topological index (`A24`).
- Added a symbolic derivation of one-generation hypercharge ratios from
  Yukawa invariance and anomaly cancellation, with the right-neutrino
  underdetermination exposed explicitly (`A25`).
- Added exact one-loop Standard-Model gauge beta coefficients from the assumed
  representation content (`A26`).
- Added a free four-dimensional overlap operator certificate showing one
  physical massless corner, 15 gapped doublers and second-order continuum
  convergence (`A27`).
- Expanded pytest from 20 to 32 tests and the prediction registry from 5 to 9
  structural predictions.
- Continuous CODATA/PDG parameter coverage remains 0/445.
