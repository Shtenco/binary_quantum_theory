# Compact Holonomies 2.0.0 — verified research release

## What this release establishes

- The compact identity `(U-U†)/(2 i δ)=sin(δK)/δ` and its classical limit.
- A closed off-shell hypersurface-deformation bracket in the **vacuum,
  spherically symmetric continuum sector** for
  `f1=sin²(δK)/δ²`, `f2=sin(2δK)/(2δ)`, `β=cos(2δK)`.
- An explicit, but not uniquely derived, diffeomorphism-invariant low-energy
  completion whose curvature corrections start at cubic order. Its linearized
  Minkowski spectrum has two TT tensor modes and `c_GW=c`.
- A fixed compact ring micro-operator with an analytic spectrum, evaluated in
  32 reproducible SHA-256-generated holdout challenges.
- Algebraically correct compact Wilson-link realizations of
  `U(1) × SU(2) × SU(3)`.
- A frozen preregistration manifest for future external predictions.

## Numerical verification

- `pytest`: 20 passed.
- Original document checks: 10/10 passed.
- EFT/WKB checks: 7/7 passed.
- A18 maximum relative closure residual at `N=32`: `3.333077360369811e-14`.
- A20 challenge suite: 32/32 wins against both continuum and quartic baselines;
  maximum normalized RMSE `3.159618556756622e-16`.
- Wheel installation/import verified in a separate virtual environment after
  installing declared dependencies.

## Corrected legacy interpretation

The former A9 interpretation confused the exponentially closing finite-volume
ordered-state doublet splitting with the bulk excitation gap. The corrected
N=14 values are:

- doublet splitting `E1-E0 = 1.9967089761863122e-4`;
- bulk gap `E2-E0 = 1.7439564461617039`;
- long-range staggered plateau `≈0.8942255873`.

This toy is ordered and non-critical; it does not provide a GR-like continuum
phase.

## What is not established

- No full 3+1 anomaly-free constraint algebra.
- No unique derivation of the 4D low-energy completion from the micro-operator.
- No unique derivation of the Standard Model gauge group, chiral matter,
  anomaly cancellation, Higgs/Yukawa sectors, or renormalization-group flow.
- No derivation of particle masses, gauge couplings, CKM/PMNS parameters,
  cosmological constant, or a catalogue of 445 physical constants.

The honest numerical coverage of independent modern-physics constants remains
`0/445`. The release has verified structural and mathematical predictive power,
not yet empirical predictive power for the Standard Model parameter set.
