# Compact Holonomies v2.1 — verified chiral extension

## Verified chain

```text
compact holonomies
  -> closed vacuum spherical HDA (A18, restricted sector)
  -> explicit covariant low-energy completion (A19, not unique)
  -> fixed compact micro-spectrum with blind challenges (A20)
  -> compact gauge representations (A22, constructed)
  -> exact overlap chirality and topological index (A24/A27)
  -> conditional anomaly-free hypercharge ratios (A25)
  -> conditional one-loop gauge beta coefficients (A26)
```

## New results

- **A24:** 20/20 finite-lattice U(1) flux/index trials pass. Maximum
  Ginsparg-Wilson residual: `3.595858311645704e-14`; maximum index-theorem
  error: `7.105427357601002e-15`.
- **A25:** without a right-handed neutrino, anomaly cancellation plus the
  assumed representations and Yukawa interactions fixes Standard-Model
  hypercharge ratios up to normalization. With `nu_R`, a B-L mixing freedom
  remains.
- **A26:** exact one-loop coefficients `(41/10,-19/6,-7)` follow from three
  assumed generations and one Higgs doublet.
- **A27:** the free 4D overlap operator has one massless corner and 15 gapped
  doublers, exact GW residual `1.11e-16`, and `O(p^2)` continuum convergence.

## Not proved

- full interacting 3+1 anomaly-free gravity;
- unique emergence of the gauge group and representation pattern;
- interacting chiral gauge locality/nonperturbative construction in 4D;
- why there are three generations;
- Higgs potential, Yukawa matrices, flavor mixing or neutrino sector;
- absolute gauge couplings, particle masses or cosmological parameters;
- any catalogue of 445 measured constants.

## Constants coverage

The continuous measured-parameter coverage remains **0/445**. The release adds
structural discrete predictions (charges, index, doubler count, beta slopes),
not a derivation of measured masses and coupling values.
