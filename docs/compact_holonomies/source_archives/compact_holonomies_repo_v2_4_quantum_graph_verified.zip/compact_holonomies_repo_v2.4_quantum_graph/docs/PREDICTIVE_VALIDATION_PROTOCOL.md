# Predictive validation protocol (A17)

## What counts as a prediction
A result counts only if all of the following are fixed before opening the test value:

1. observable name and units;
2. exact equation and code commit;
3. all free parameters and their provenance;
4. training set and hidden test set;
5. uncertainty distribution;
6. scoring rule and rejection threshold;
7. multiple-testing correction.

Algebraic identities, reconstruction of input parameters, dimensional conversions,
fits to the same quantity, and post-hoc formula searches do not count.

## Required benchmark

- Freeze a machine-readable catalog from CODATA and PDG.
- Remove exact SI-defining quantities and derived duplicates from the independent target set.
- Group correlated quantities and retain covariance information.
- Use chronological holdout where possible: fit only to an older release, predict later measurements.
- Keep at least 20% of eligible observables hidden from all formula and model selection.
- Compare against constant, dimensional-analysis, nearest-neighbour, and randomized-symbolic baselines.
- Report log predictive density, standardized residuals, calibration coverage, and false discovery rate.

## Current result
Version 1.6 has no microscopic-to-observable map. Coverage is 0/445, so no claim of
physical predictive power is made. A future model must populate a preregistered
prediction manifest before hidden values are revealed.
