# Roadmap к честному blind test по физическим константам

## Gate 1 — unique microtheory

Должны быть зафиксированы Hilbert space, Hamiltonian/constraints, measure,
boundary conditions и все dimensionless inputs.

## Gate 2 — Standard Model sector

Нужно вывести, а не вставить:

- `SU(3)xSU(2)xU(1)`;
- chiral representations и anomaly cancellation;
- Higgs representation;
- число поколений.

## Gate 3 — normalization and RG

Из микротеории должны следовать bare kinetic coefficients, beta functions и
matching scale. Только тогда появляются вычислимые `g1,g2,g3`.

## Gate 4 — hierarchy and flavor

Нужен единый operator/mechanism для Higgs scale, Yukawa spectrum, CKM и PMNS.
Формула на каждую частицу отдельно запрещена.

## Gate 5 — data protocol

1. Сформировать независимый список observables с covariance matrix.
2. Удалить exact SI definitions и algebraically dependent conversions.
3. Разделить historical calibration и sealed holdout.
4. Заморозить git commit и SHA-256 prediction manifest.
5. Открыть holdout один раз.
6. Оценить z-scores, calibration, likelihood и multiple-testing correction.

До прохождения Gates 1–4 тест 445 чисел не является тестом теории.
