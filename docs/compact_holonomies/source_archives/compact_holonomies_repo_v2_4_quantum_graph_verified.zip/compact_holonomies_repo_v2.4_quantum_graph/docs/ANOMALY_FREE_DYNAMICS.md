# A18 — anomaly-free spherical dynamics

A10, A11 и A13 тестировали четыре простых **lattice**-анзаца и правильно нашли
аномалии. A18 не «подправляет коэффициенты» этих анзацев. Он возвращается к
continuum vacuum spherical constraint system и использует согласованные
функции

\[
2f_2=f_1',\qquad \beta=f_2'.
\]

Для sine-компактификации это даёт

\[
f_1=\sin^2(\delta K)/\delta^2,
\quad f_2=\sin(2\delta K)/(2\delta),
\quad \beta=\cos(2\delta K).
\]

`verify_anomaly_free_spherical.py` выполняет два независимых теста:

1. точный SymPy certificate функциональных тождеств и локальной канонической
   карты `Kbar=sin(delta K)/delta`, `Ebar=E/cos(delta K)`;
2. off-shell Poisson bracket на случайных гладких полях с complex-step
   functional derivatives и Fourier pseudospectral spatial derivatives.

Численный тест не использует уравнения движения и поэтому является off-shell.
Он не доказывает замыкание полной 3+1 операторной алгебры.
