# Предсказательная сила v2.0

## Что считается предсказанием

Формула должна быть заморожена до раскрытия target data, не иметь
observable-specific fit coefficients и сравниваться с baseline.

## Доказано

- A20: точный спектр фиксированного compact shift operator на 32 hashed holdout
  challenge;
- параметр-независимое отношение `c6/c4^2=2/5`;
- A18: форма structure function `beta=cos(2 delta K_phi)`;
- A19: для явно выбранного curvature-cubed completion — 2 TT modes и luminal
  linear propagation.

## Не доказано

- связь eigenvalues A20 с particle masses;
- значения gauge couplings;
- fermion masses и mixing angles;
- cosmological constant;
- 445 CODATA/PDG quantities.

`audit_predictive_power.py` автоматически сканирует source tree на типичные
символы target leakage и разделяет structural predictions от physical-constant
predictions.
