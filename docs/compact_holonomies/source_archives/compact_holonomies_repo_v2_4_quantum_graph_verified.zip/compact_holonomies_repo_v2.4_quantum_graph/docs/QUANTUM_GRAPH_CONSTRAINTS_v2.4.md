# Compact Holonomies v2.4 — local constraints on a multi-vertex quantum graph

## A37 — local Gauss constraints and the physical projector

The new model replaces the single compact degree of freedom by an oriented
cycle graph with `E` edges and one finite `Z_N` Hilbert space per edge,

\[
\mathcal H_{\rm kin}=(\mathbb C^N)^{\otimes E}.
\]

At vertex `v`, the local gauge transformation acts on the outgoing and incoming
edges as

\[
G_v=X_v X_{v-1}^\dagger.
\]

The joint physical projector is

\[
P_{\rm phys}=\prod_v\frac1N\sum_{r=0}^{N-1}G_v^r.
\]

For the registered `N=3`, `E=4` challenge:

```text
kinematical dimension             = 81
physical dimension                = 3
projector idempotence error       = 9.73e-16
maximum G_v P_phys-P_phys error   = 0
maximum [G_v,W] error             = 4.16e-15
```

The physical dimension equals `N`, as expected for one independent loop
holonomy after local gauge reduction.

## A38 — positive master constraint and preserving dynamics

The positive master constraint is

\[
M=\sum_v(2I-G_v-G_v^\dagger),
\]

and its kernel coincides with the image of `P_phys`.  The registered
Kogut–Susskind-type Hamiltonian contains electric shift terms and a magnetic
Wilson-loop term.  It obeys

\[
[H,M]=0,\qquad [H,P_{\rm phys}]=0.
\]

Measured residuals:

```text
kernel dimension                  = 3
master-projector residual         = 0
||[H,M]||                         = 2.84e-14
||[H,P_phys]||                    = 2.58e-15
maximum physical leakage          = 2.59e-15
maximum norm error                = 5.55e-16
```

Thus local constrained states exist and are preserved by unitary evolution.

## A39 — exact subdivision/refinement check

The same one-cycle topology was represented with `E=3,4,5` edges.  The full
kinematical dimension grows as `3^E`, but the gauge-reduced physical dimension
remains exactly

```text
3, 3, 3.
```

This is a genuine graph-refinement invariant of the constrained kinematics. It
is not yet a continuum limit of gravitational dynamics.

## Scope

This extension establishes the architecture of a local constrained quantum
graph:

- tensor-product kinematical Hilbert space;
- local constraints at multiple vertices;
- an exact physical projector;
- a positive master constraint;
- gauge-invariant unitary dynamics;
- a topology-preserving refinement check.

It remains a finite Abelian `Z_N` gauge graph.  The next nontrivial step is to
replace it by non-Abelian `SU(2)` representation data, add geometric area and
volume operators, then construct a regulated Hamiltonian/master constraint
whose semiclassical limit can be compared with Einstein dynamics.
