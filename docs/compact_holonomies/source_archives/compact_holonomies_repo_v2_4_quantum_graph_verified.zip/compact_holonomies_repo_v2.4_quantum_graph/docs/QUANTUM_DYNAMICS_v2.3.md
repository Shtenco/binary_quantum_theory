# Compact Holonomies v2.3 — explicit quantum kinematics and relational dynamics

## Why this extension was necessary

Up to v2.2, the strongest gravitational result was an effective classical
Poisson-algebra closure in a restricted spherical vacuum sector.  The project
still lacked an explicit Hilbert space, exact quantum operators, physical
states and unitary evolution.  A33–A35 add those objects in the smallest
controlled compact laboratory where every statement can be checked exactly.

This is a real upgrade from classical effective dynamics to quantum dynamics,
but it is **not** yet a quantization of four-dimensional general relativity.

## A33 — exact finite holonomy–flux kinematics

On the finite Hilbert space

\[
\mathcal H_N = \mathbb C^N
\]

we define a clock operator and a cyclic shift,

\[
U|n\rangle=\omega^n|n\rangle,\qquad
V|n\rangle=|n+1\;\mathrm{mod}\;N\rangle,
\qquad \omega=e^{2\pi i/N}.
\]

They obey the exact Weyl relation

\[
UV=\omega VU.
\]

For the registered `N=31` challenge, the numerical residual is

```text
||UV-omega VU||_F = 8.42e-16.
```

The implementation deliberately does **not** claim an exact finite canonical
commutator.  For any finite matrices,

\[
\mathrm{Tr}[A,B]=0,
\]

whereas \(\mathrm{Tr}(iI)=iN\).  The measured trace obstruction is exactly
`31.0` for `N=31`.  Thus the exact quantum kinematics is exponentiated
holonomy–flux kinematics, not a misleading truncated approximation to
`[q,p]=iI`.

## A34 — a solved quantum constraint in relational time

The compact positive operator is

\[
\Theta_a=\frac{2I-V-V^\dagger}{a^2}+m^2 I.
\]

Its spectrum is

\[
\lambda_k=m^2+\frac{4}{a^2}\sin^2\left(\frac{\pi k}{N}\right).
\]

The toy quantum constraint is

\[
\partial_\phi^2\Psi+\Theta_a\Psi=0.
\]

On the positive-frequency branch,

\[
i\partial_\phi\Psi=\sqrt{\Theta_a}\,\Psi,
\qquad
\Psi(\phi)=e^{-i\sqrt{\Theta_a}\phi}\Psi(0).
\]

For the frozen challenge `N=31`, `a=0.2`, `m=0.35`:

```text
minimum eigenvalue of Theta       = 0.1225000000000024
exact-spectrum maximum error      = 1.51e-13
sqrt(Theta)^2 factorization error = 3.75e-12
maximum unitarity error           = 5.44e-14
maximum state norm error          = 5.33e-15
constraint residual               = 3.75e-12
```

Therefore this finite model has:

- an explicit Hilbert space and inner product;
- self-adjoint quantum operators;
- a nonempty family of physical positive-frequency states;
- exactly unitary relational evolution;
- a solved second-order quantum constraint.

The missing step is to replace this one-degree-of-freedom operator by a
regulated set of local gravitational Gauss, diffeomorphism and Hamiltonian
operators in 3+1 dimensions and prove their anomaly-free joint action.

## A35 — controlled continuum spectral limit

At fixed circumference `L=2*pi`, the low-mode eigenvalue converges to

\[
\lambda_{\rm cont}=\left(\frac{2\pi k}{L}\right)^2
\]

with

\[
\frac{|\lambda_a-\lambda_{\rm cont}|}{\lambda_{\rm cont}}
=
\frac{\lambda_{\rm cont}}{12}a^2+O(a^4).
\]

Across the unselected resolutions

```text
N = 32, 48, 64, 96, 128, 192
```

the fitted order is

```text
p = 1.9974248813
```

and the measured leading ratio is `0.3332857`, versus the exact prediction
`1/3`.  This controls the continuum limit of one spectral operator; it does
not establish the interacting 3+1 continuum limit.

## A36 — why the present topology does not select three families

For uniform quantized U(1) flux on compact area `A`, the positive Maxwell
action is

\[
S_Q=\frac{2\pi^2Q^2}{g^2A}.
\]

It has the unique minimum

\[
Q=0
\]

and

\[
S_3/S_1=9.
\]

Thus the minimal dynamics used by the current topological toy sector actively
prefers no chiral families rather than three.  Selecting `|Q|=3` requires a new
derived mechanism—such as a nontrivial effective potential, boundary/topology
condition, coupled sector or index constraint—and that mechanism must be fixed
before looking at the desired answer.

## Exact status after v2.3

The project now contains a genuine finite quantum theory, but only as a
laboratory for one compact degree of freedom.  It still lacks:

1. a 3+1 graph/cell-complex Hilbert space with local geometric labels;
2. regulated operators \(\hat G,\hat D,\hat H\) on that space;
3. a proof of quantum constraint closure or a controlled master constraint;
4. semiclassical states reproducing the Einstein equations;
5. a nonperturbative continuum/refinement limit;
6. a new measured observable successfully predicted out of sample.

The next technically meaningful target is therefore **A37: a multi-vertex
holonomy–flux Hilbert space with a local Gauss projector and a nontrivial
Hamiltonian/master-constraint operator**, followed by an anomaly and
refinement stress test.
