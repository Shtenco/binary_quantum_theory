# Chiral matter extension — v2.1

## A24: exact lattice chirality and topology

A periodic two-dimensional U(1) link field with integer flux `Q` is used as a
finite controlled test bed. The Neuberger overlap operator is

\[
D_{\rm ov}=\frac{\rho}{a}\left(1+\gamma_5\,\operatorname{sign}H_W\right),
\qquad H_W=\gamma_5\left(D_W-\frac{\rho}{a}\right).
\]

It obeys

\[
\gamma_5D+D\gamma_5=\frac{a}{\rho}D\gamma_5D
\]

and the finite-lattice index formula

\[
\operatorname{index}D=\operatorname{Tr}\gamma_5
\left(1-\frac{aD}{2\rho}\right).
\]

For the registered link convention, `index(D)=-Q`. Twenty unselected
`(L,Q)` trials pass with maximum GW residual `3.60e-14` and maximum index error
`7.11e-15`.

This establishes exact finite-lattice chirality and topology in a 2D U(1)
test bed. It does not derive the four-dimensional Standard Model.

## A25: anomaly cancellation and hypercharge

Assume one left-handed generation with representation pattern

- `Q:(3,2)`, `u^c:(3bar,1)`, `d^c:(3bar,1)`;
- `L:(1,2)`, `e^c:(1,1)`;
- one Higgs doublet.

Yukawa invariance and the `SU(2)^2 U(1)` anomaly give all charges in terms of
`q=Y_Q` and `h=Y_H`. Without `nu^c`, the mixed gravitational anomaly is

\[
\mathcal A_{\rm grav^2U(1)}=h-3q,
\]

so `h=3q`; the cubic anomaly then vanishes identically. With `Y_H=1/2`:

\[
Y_Q=\frac16,\quad Y_{u^c}=-\frac23,\quad Y_{d^c}=\frac13,
\quad Y_L=-\frac12,\quad Y_{e^c}=1.
\]

This gives the physical charges `2/3,-1/3,0,-1`. The four weak doublets per
generation (three coloured Q doublets plus L) also avoid the global Witten
SU(2) anomaly.

With a right-handed neutrino, all local anomalies vanish for a two-parameter
family: an additional hypercharge/B-L mixing direction remains. Therefore
anomaly cancellation alone no longer fixes the ratios uniquely.

## A26: one-loop RG coefficients

From three copies of the above chiral matter content and one Higgs doublet,
with `g1=sqrt(5/3) gY`, exact group-index sums give

\[
(b_1,b_2,b_3)=\left(\frac{41}{10},-\frac{19}{6},-7\right),
\qquad
\mu\frac{dg_i}{d\mu}=\frac{b_i}{16\pi^2}g_i^3.
\]

This predicts the one-loop slopes after boundary couplings are supplied. It
does not determine their absolute values or threshold corrections.

## A27: free four-dimensional overlap fermion

For momentum `p`,

\[
D_{\rm ov}(p)=\frac{\rho}{a}\left[1+\frac{i\gamma_\mu\sin(ap_\mu)
+r\sum_\mu(1-\cos ap_\mu)-\rho}
{\sqrt{\sum_\mu\sin^2(ap_\mu)+[r\sum_\mu(1-\cos ap_\mu)-\rho]^2}}
\right].
\]

For `0<rho<2r`:

- the `p=0` corner is massless;
- all other 15 Brillouin corners have gap `2 rho/a`;
- the GW relation holds to `1.11e-16` in the numerical certificate;
- the continuum error scales as `O(p^2)`, with measured order `2.0003` or better.

This removes free lattice doublers while retaining exact lattice chirality.
An interacting four-dimensional chiral gauge theory remains a separate task.
