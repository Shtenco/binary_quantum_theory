"""
A8: Positivity of the Euclidean transfer kernel for a sine-deformed SU(2)
plaquette action. Roadmap item 2 ("локальный неабелев transfer operator
с доказанной положительностью евклидова ядра").

Background (Osterwalder-Seiler / Menotti-Onofri, standard LGT result):
For lattice gauge theory with a class-function plaquette weight f(theta)
(theta = class angle of the plaquette holonomy), the theory is reflection
positive -- and hence has a genuine positive-norm transfer operator / Hilbert
space upon Wick rotation -- IFF the Peter-Weyl (character) expansion

    f(theta) = sum_j c_j * chi_j(theta)

has c_j >= 0 for every irrep j. Ordinary Wilson/heat-kernel actions satisfy
this automatically (c_j = (2j+1) exp(-t j(j+1)) >= 0 by construction).

This script does NOT assume the sine-deformed action inherits that property.
It picks the most natural non-abelian generalization of the abelian
sin(delta*K)/delta holonomy-correction idea -- replacing the class angle
theta (the natural non-abelian analog of the abelian "curvature" delta*K)
by sin(theta)/delta inside the action -- and checks by direct numerical
integration whether the resulting weight is a positive combination of
SU(2) characters. This is a genuine, undetermined test: it could fail.

SU(2) conventions:
  - Haar measure on class angle theta in [0, pi]: dmu = (2/pi) sin^2(theta) dtheta
  - Character of spin-j irrep: chi_j(theta) = sin((2j+1) theta) / sin(theta)
  - Orthogonality: integral chi_j(theta) chi_k(theta) dmu(theta) = delta_jk
"""
from pathlib import Path
import numpy as np
import json

def chi(j, theta):
    theta = np.asarray(theta, dtype=float)
    num = np.sin((2*j+1)*theta)
    out = np.empty_like(theta)
    small = np.abs(theta) < 1e-9
    out[~small] = num[~small] / np.sin(theta[~small])
    out[small] = 2*j+1  # limit theta->0
    return out

def haar_density(theta):
    return (2/np.pi) * np.sin(theta)**2

def sine_action_weight(theta, t, delta):
    """f(theta) = exp(-t * (sin(theta)/delta)^2), the sine-deformed
    plaquette Boltzmann weight -- natural SU(2) analog of replacing the
    abelian curvature delta*K by sin(delta*K)/delta inside the action."""
    return np.exp(-t * (np.sin(theta)/delta)**2)

# Deterministic high-order Gauss-Legendre quadrature.  This is substantially
# faster and more reproducible than adaptive quad for oscillatory high-j modes.
_GL_X, _GL_W = np.polynomial.legendre.leggauss(256)
_GL_THETA = 0.5 * np.pi * (_GL_X + 1.0)
_GL_WEIGHT = 0.5 * np.pi * _GL_W
_GL_X2, _GL_W2 = np.polynomial.legendre.leggauss(128)
_GL_THETA2 = 0.5 * np.pi * (_GL_X2 + 1.0)
_GL_WEIGHT2 = 0.5 * np.pi * _GL_W2


def peter_weyl_coeff(j, t, delta):
    values = sine_action_weight(_GL_THETA, t, delta) * chi(j, _GL_THETA) * haar_density(_GL_THETA)
    val = float(np.sum(_GL_WEIGHT * values))
    # Embedded error estimate from half-order quadrature.
    val2 = float(np.sum(_GL_WEIGHT2 * sine_action_weight(_GL_THETA2, t, delta) * chi(j, _GL_THETA2) * haar_density(_GL_THETA2)))
    return val, abs(val - val2)

js = [0, 0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 7, 10]
param_sets = [
    {"t": 1.0, "delta": 1.0},
    {"t": 1.0, "delta": 0.3},   # small-lattice-spacing-like regime
    {"t": 4.0, "delta": 1.0},   # strong coupling
    {"t": 0.2, "delta": 1.0},   # weak coupling
    {"t": 1.0, "delta": 2.5},   # delta close to/above pi-scale
]

all_results = []
overall_pass = True
for params in param_sets:
    t, delta = params["t"], params["delta"]
    row = {"t": t, "delta": delta, "coeffs": []}
    any_negative = False
    for j in js:
        val, err = peter_weyl_coeff(j, t, delta)
        neg = val < -1e-6  # tolerance above quadrature error floor
        any_negative |= neg
        row["coeffs"].append({"j": j, "c_j": float(val), "quad_err": float(err), "negative": bool(neg)})
    row["any_negative_coeff"] = bool(any_negative)
    row["verdict"] = "FAIL (not reflection positive)" if any_negative else "PASS (positive for tested j range)"
    overall_pass &= (not any_negative)
    all_results.append(row)
    tag = "FAIL" if any_negative else "PASS"
    print(f"{tag}  t={t:4.1f}  delta={delta:4.1f}   " +
          "  ".join(f"c[{c['j']}]={c['c_j']:+.4f}" for c in row["coeffs"][:6]) + " ...")

out = {
    "artifact_id": "A8",
    "claim": "Sine-deformed SU(2) plaquette weight exp(-t*(sin(theta)/delta)^2) has nonnegative Peter-Weyl coefficients for all tested j (=> reflection positive => valid Euclidean transfer operator).",
    "method": "Direct numerical integration (scipy.integrate.quad) of Peter-Weyl coefficients over SU(2) Haar measure on the class angle.",
    "param_sets": all_results,
    "overall": "PASS" if overall_pass else "FAIL",
    "interpretation": None,
}
print()
print(json.dumps(out, indent=2)[:2000])
with open(str(Path(__file__).resolve().parent / "sine_action_positivity_results.json"), "w") as f:
    json.dump(out, f, indent=2)
print()
print("OVERALL:", out["overall"])
