"""
A7: SU(2) Gauss law closure on a minimal branching (trivalent) graph.
Roadmap item 1 from README.md.

Setup: a single trivalent vertex with three incident links, each carrying
a spin-j representation of SU(2). The vertex Gauss-law generator for
axis a is J_a^vertex = sum_{links l} J_a^(l) (acting on link l's factor,
identity elsewhere in the tensor product).

Claim to test: {J_a^vertex, J_b^vertex} close the su(2) algebra exactly,
i.e. [J_a^vertex, J_b^vertex] = i * eps_{abc} * J_c^vertex, with ZERO
anomaly term, for any spin representations on the three links.

This is NOT a new physical prediction -- it is a direct-sum-of-representations
fact from finite-dimensional Lie algebra representation theory. It is the
easy, structural precondition item 1 asks for. It says nothing about
whether the *dynamics* (Hamiltonian constraint / HDA closure, roadmap item 4)
is anomaly-free -- that is the actually hard, open problem.
"""
from pathlib import Path
import numpy as np
from itertools import product

def spin_operators(j):
    """Return (Jx, Jy, Jz) for spin-j representation, dimension 2j+1."""
    dim = int(round(2 * j + 1))
    m = np.arange(j, -j - 1, -1)  # m = j, j-1, ..., -j
    Jz = np.diag(m).astype(complex)
    Jp = np.zeros((dim, dim), dtype=complex)
    for i in range(dim - 1):
        mm = m[i + 1]
        Jp[i, i + 1] = np.sqrt(j * (j + 1) - mm * (mm + 1))
    Jm = Jp.conj().T
    Jx = (Jp + Jm) / 2
    Jy = (Jp - Jm) / (2j*0 + 2j)  # placeholder, fixed below
    Jy = (Jp - Jm) / (2j and 2j)  # avoid; recompute properly
    Jy = (Jp - Jm) / complex(0, 2)
    return Jx, Jy, Jz

def embed(op, site, dims):
    """Embed operator `op` acting on `site` into full tensor product space."""
    mats = []
    for i, d in enumerate(dims):
        if i == site:
            mats.append(op)
        else:
            mats.append(np.eye(d, dtype=complex))
    full = mats[0]
    for mm in mats[1:]:
        full = np.kron(full, mm)
    return full

def test_vertex(spins, seed_tag):
    dims = [int(round(2*j+1)) for j in spins]
    Jx_list, Jy_list, Jz_list = [], [], []
    for j in spins:
        jx, jy, jz = spin_operators(j)
        Jx_list.append(jx); Jy_list.append(jy); Jz_list.append(jz)

    Jx_v = sum(embed(Jx_list[i], i, dims) for i in range(len(spins)))
    Jy_v = sum(embed(Jy_list[i], i, dims) for i in range(len(spins)))
    Jz_v = sum(embed(Jz_list[i], i, dims) for i in range(len(spins)))

    def comm(A, B):
        return A @ B - B @ A

    c1 = comm(Jx_v, Jy_v) - 1j * Jz_v
    c2 = comm(Jy_v, Jz_v) - 1j * Jx_v
    c3 = comm(Jz_v, Jx_v) - 1j * Jy_v

    max_anomaly = max(np.max(np.abs(c1)), np.max(np.abs(c2)), np.max(np.abs(c3)))
    return max_anomaly, dims

results = []
test_cases = [
    ("три спина-1/2", [0.5, 0.5, 0.5]),
    ("спины 1/2,1,1",  [0.5, 1.0, 1.0]),
    ("спины 1,1,1",    [1.0, 1.0, 1.0]),
    ("спины 1/2,1,3/2", [0.5, 1.0, 1.5]),
    ("четырёхвалентный узел, все 1/2", [0.5, 0.5, 0.5, 0.5]),
]

all_pass = True
for name, spins in test_cases:
    anomaly, dims = test_vertex(spins, name)
    passed = anomaly < 1e-10
    all_pass &= passed
    results.append({
        "case": name, "spins": spins, "dims": dims,
        "max_anomaly_norm": float(anomaly), "pass": bool(passed)
    })
    print(f"{'PASS' if passed else 'FAIL'}  {name:35s} dims={dims}  max|[Ja,Jb]-i eps Jc| = {anomaly:.3e}")

import json, hashlib
out = {
    "artifact_id": "A7",
    "claim": "SU(2) Gauss-law generators at a branching vertex close su(2) exactly (no anomaly), for arbitrary spin reps on the incident links.",
    "results": results,
    "overall": "PASS" if all_pass else "FAIL",
    "caveat": (
        "This tests kinematics only (representation-theoretic closure of the "
        "Gauss constraint algebra), which is guaranteed a priori by "
        "finite-dim Lie algebra representation theory (direct sum of reps "
        "is a rep). It does NOT test the Hamiltonian constraint / "
        "hypersurface-deformation algebra (roadmap item 4), which is the "
        "genuinely open, unsolved problem in canonical quantum gravity -- "
        "closing THAT algebra without anomaly on a physical Hilbert space "
        "is not established here or anywhere in this repository, and "
        "remains open in the wider LQG literature as well."
    )
}
print(json.dumps(out, indent=2, ensure_ascii=False))
with open(str(Path(__file__).resolve().parent / "su2_gauss_closure_results.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
