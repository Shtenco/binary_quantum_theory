"""
A9: Finite-size scaling of gap, correlation length, spectral dimension.
Roadmap item 3. Same model as A6 for direct comparability: transverse-field
Ising on a ring, H = sum_i [ J * Z_i Z_{i+1} + h * X_i ], J=1.0, h=0.6
(A6's exact point -- NOT the critical point h=J=1, deliberately kept
identical to A6 rather than re-tuned, so this is a genuine continuation
of that same "natural" Hamiltonian, not a cherry-picked new one).

This is exact diagonalization (ED), not the sine/holonomy dynamics itself --
this script does NOT claim the TFIM *is* the physical binary-foam
Hamiltonian; it treats it as the minimal already-adopted toy model from A6
and asks the honest follow-up question the roadmap poses: how do its low
lying properties scale with N? This is standard many-body physics, done
straightforwardly, with no claim of new physics.

Computed for N = 4, 6, 8, 10, 12, 14 (dim up to 2^14 = 16384, ED feasible):
  - gap Delta(N) = E1 - E0
  - correlation length xi(N) from exponential decay of connected
    <Z_0 Z_r> correlator in the ground state
  - spectral dimension d_s(N) estimated from short-time heat-kernel trace
    scaling Tr[exp(-tau H)] ~ tau^{-d_s/2} (return-probability method),
    at intermediate tau (not tau->0, which is cutoff by the finite lattice)
"""
from pathlib import Path
import numpy as np
import json
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh

J, h = 1.0, 0.6

def build_H(N):
    """Sparse TFIM Hamiltonian in the computational Z basis."""
    dim = 2 ** N
    rows, cols, data = [], [], []
    for state in range(dim):
        z = np.array([1.0 if ((state >> i) & 1) == 0 else -1.0 for i in range(N)])
        diagonal = J * sum(z[i] * z[(i + 1) % N] for i in range(N))
        rows.append(state); cols.append(state); data.append(diagonal)
        for i in range(N):
            flipped = state ^ (1 << i)
            rows.append(state); cols.append(flipped); data.append(h)
    return coo_matrix((data, (rows, cols)), shape=(dim, dim), dtype=float).tocsr()


def connected_corr(gs, r, N):
    dim = gs.size
    probabilities = np.abs(gs) ** 2
    states = np.arange(dim, dtype=np.uint64)
    z0 = 1.0 - 2.0 * ((states >> 0) & 1)
    zr = 1.0 - 2.0 * ((states >> (r % N)) & 1)
    zz = float(np.sum(probabilities * z0 * zr))
    zi = float(np.sum(probabilities * z0))
    zj = float(np.sum(probabilities * zr))
    return zz - zi * zj

Ns = [4, 6, 8, 10, 12, 14]
rows = []
for N in Ns:
    H = build_H(N)
    k_eigs = min(8, H.shape[0] - 2)
    eigvals, eigvecs = eigsh(H, k=k_eigs, which="SA", tol=1e-8, maxiter=3000)
    order = np.argsort(eigvals)
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]
    E0 = eigvals[0]
    doublet_splitting = eigvals[1] - E0
    bulk_gap = eigvals[2] - E0
    gap = bulk_gap
    gs = eigvecs[:, 0]

    # connected correlator vs distance (up to N//2, PBC symmetric)
    dists = list(range(1, N // 2 + 1))
    raw_corrs = [connected_corr(gs, r, N) for r in dists]
    # J>0 is antiferromagnetic in this sign convention. Remove the alternating
    # sign and inspect the long-distance plateau (ordered phase).
    corrs = [((-1) ** r) * c for r, c in zip(dists, raw_corrs)]
    corrs_arr = np.array(corrs)
    plateau = float(np.mean(corrs_arr[-min(2, len(corrs_arr)):]))
    xi = None  # a plateau means a naive exponential correlation length is invalid

    # truncated low-energy heat-kernel proxy (64 lowest eigenvalues)
    Erel = eigvals - E0
    taus = np.geomspace(0.05, 2.0, 25)
    logZ = np.array([np.log(np.sum(np.exp(-t * Erel))) for t in taus])
    logt = np.log(taus)
    # local slope d(logZ)/d(log tau) at each point -> -d_s/2
    slopes = np.gradient(logZ, logt)
    ds_est = -2 * slopes
    # take the flattest (most plateau-like) middle region as the estimate
    mid = slice(len(taus)//3, 2*len(taus)//3)
    ds_mid_mean = float(np.mean(ds_est[mid]))
    ds_mid_std = float(np.std(ds_est[mid]))

    rows.append({
        "N": N, "dim": 2**N,
        "doublet_splitting_E1_minus_E0": float(doublet_splitting),
        "bulk_gap_E2_minus_E0": float(bulk_gap),
        "gap": float(bulk_gap),
        "correlation_length_xi": None,
        "staggered_corr_values": [float(c) for c in corrs],
        "long_range_order_plateau_estimate": plateau,
        "spectral_dim_mid_window_mean": ds_mid_mean,
        "spectral_dim_mid_window_std": ds_mid_std,
    })
    print(
        f"N={N:2d} dim={2**N:5d} split={doublet_splitting:.6g} "
        f"bulk_gap={bulk_gap:.5f} plateau={plateau:.4f} "
        f"d_s,trunc={ds_mid_mean:.3f}+-{ds_mid_std:.3f}"
    )

# simple power-law / exponential fits of gap(N) and xi(N) trend
Ns_arr = np.array(Ns, dtype=float)
gaps_arr = np.array([r["gap"] for r in rows])
# fit log(gap) vs N (exponential closing/opening) and vs log N (power law)
logg = np.log(gaps_arr)
slope_exp, _ = np.linalg.lstsq(np.vstack([Ns_arr, np.ones_like(Ns_arr)]).T, logg, rcond=None)[0], None
slope_exp = np.linalg.lstsq(np.vstack([Ns_arr, np.ones_like(Ns_arr)]).T, logg, rcond=None)[0][0]
slope_pow = np.linalg.lstsq(np.vstack([np.log(Ns_arr), np.ones_like(Ns_arr)]).T, logg, rcond=None)[0][0]

xis = [r["correlation_length_xi"] for r in rows if r["correlation_length_xi"] is not None]

summary = {
    "artifact_id": "A9",
    "model": "antiferromagnetic TFIM ring, J=+1.0, h=0.6",
    "N_values": Ns,
    "rows": rows,
    "corrected_interpretation": {
        "doublet_splitting": (
            "E1-E0 closes rapidly with N because the finite ring forms a nearly "
            "degenerate symmetry-related ordered-state doublet. It is not the bulk mass gap."
        ),
        "bulk_gap": (
            "E2-E0 is the appropriate first bulk-excitation proxy and remains finite "
            "over the tested sizes, as expected away from the critical point."
        ),
        "correlations": (
            "The staggered connected correlator approaches a non-zero plateau, showing "
            "long-range antiferromagnetic order. Fitting the raw correlator to a single "
            "exponential and reporting a huge xi was physically invalid, so xi is now omitted."
        ),
        "spectral_dimension": (
            "The heat-trace value uses only the eight lowest eigenvalues and is retained "
            "as a truncated exploratory proxy, not a continuum spectral dimension."
        ),
    },
    "honest_conclusion": (
        "This toy is in an ordered, non-critical phase: it has a closing finite-volume "
        "doublet splitting, a finite bulk excitation gap, and long-range staggered order. "
        "It therefore does not supply the desired GR-like critical continuum phase."
    ),
}

print()
print(json.dumps(summary, indent=2)[:1500])
with open(str(Path(__file__).resolve().parent / "finite_size_scaling_results.json"), "w") as f:
    json.dump(summary, f, indent=2)
