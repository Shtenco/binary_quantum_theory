import numpy as np
import pytest

from compact_holonomies.chiral_overlap import (
    chiral_certificate,
    chiral_flux_suite,
    geometric_topological_charge,
    plaquette_phases,
    uniform_u1_flux_links,
)


def test_uniform_flux_geometry():
    links = uniform_u1_flux_links(6, 2)
    phases = plaquette_phases(links)
    assert np.std(phases) < 1e-12
    assert abs(geometric_topological_charge(links) - 2.0) < 1e-12


def test_overlap_index_and_ginsparg_wilson():
    certificate = chiral_certificate(6, 1)
    assert certificate.passed
    assert certificate.overlap_index == pytest.approx(-1.0, abs=1e-10)
    assert certificate.ginsparg_wilson_error < 1e-11


def test_unselected_chiral_flux_suite():
    suite = chiral_flux_suite(lattice_sizes=(4, 5, 6), charges=(-2, -1, 0, 1, 2))
    assert suite["pass"]
    assert suite["trial_count"] == 15
    assert suite["max_index_theorem_error"] < 1e-10

