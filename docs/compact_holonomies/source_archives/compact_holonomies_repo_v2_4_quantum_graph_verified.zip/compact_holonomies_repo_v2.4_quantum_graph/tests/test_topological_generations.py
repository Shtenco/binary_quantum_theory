import pytest

from compact_holonomies.topological_generations import (
    generation_certificate,
    three_generation_suite,
)


def test_q3_gives_three_negative_chiral_modes():
    cert = generation_certificate(6, 3)
    assert cert.passed
    assert cert.zero_mode_count == 3
    assert cert.negative_chirality_modes == 3
    assert cert.positive_chirality_modes == 0
    assert cert.overlap_index == pytest.approx(-3.0, abs=1e-10)


def test_flux_orientation_reverses_chirality():
    cert = generation_certificate(6, -3)
    assert cert.passed
    assert cert.positive_chirality_modes == 3
    assert cert.negative_chirality_modes == 0


def test_three_generation_suite():
    suite = three_generation_suite((5, 6, 7))
    assert suite["pass"]
    assert suite["trial_count"] == 6
    assert suite["minimum_nonzero_singular_value"] > 1e-6
