import math
import numpy as np
import pytest

from compact_holonomies.effective_foam_eft import (
    EFTParameters,
    HolonomyCorrection,
    barrier_action,
    tunneling_amplitude,
    tunneling_probability,
    foam_corrected_barrier,
    phase_decoherence_factor,
    planck_suppression,
)


def test_eft_validation():
    EFTParameters().validate()
    with pytest.raises(ValueError):
        EFTParameters(z_phi=0).validate()


def test_holonomy_identity_limit_and_bound():
    h = HolonomyCorrection(delta=0.03)
    for k in np.linspace(-3, 3, 31):
        err = abs(h.apply(k) - k)
        assert err <= h.remainder_bound(k) + 1e-14
    assert abs(h.apply(1e-8) - 1e-8) < 1e-20


def test_phase_does_not_change_single_path_probability():
    action, hbar = 3.0, 0.7
    p0 = abs(tunneling_amplitude(action, hbar, 0.0)) ** 2
    for phase in np.linspace(-50, 50, 101):
        assert math.isclose(abs(tunneling_amplitude(action, hbar, phase)) ** 2, p0,
                            rel_tol=1e-13, abs_tol=1e-15)
    assert math.isclose(p0, tunneling_probability(action, hbar), rel_tol=1e-13)


def test_rectangular_barrier_matches_closed_form():
    mass, gap, width = 2.5, 4.0, 1.7
    potential = lambda x: gap
    numeric = barrier_action(potential, energy=0.0, mass=mass, x_left=0.0, x_right=width)
    exact = width * math.sqrt(2.0 * mass * gap)
    assert math.isclose(numeric, exact, rel_tol=1e-12)


def test_foam_correction_vanishes_with_suppression():
    v0 = lambda x: 10.0 + x*x
    phi = lambda x: math.sin(x)
    veff = foam_corrected_barrier(v0, phi, coupling=1e9, suppression=0.0)
    for x in np.linspace(-1, 1, 11):
        assert veff(x) == v0(x)


def test_planck_suppression_is_tiny_at_nuclear_scale():
    ratio2 = planck_suppression(1e-15, 1.616255e-35, power=2)
    assert 1e-41 < ratio2 < 1e-39


def test_random_phase_decoheres_not_enhances():
    assert phase_decoherence_factor(0.0) == 1.0
    assert 0.0 < phase_decoherence_factor(5.0) < 1.0
