import numpy as np

from compact_holonomies.quantum_graph_constraints import (
    cycle_refinement_certificate,
    graph_gauss_certificate,
    master_constraint_certificate,
    physical_gauss_projector,
    quantum_graph_suite,
)


def test_local_gauss_projector_has_expected_cycle_rank():
    cert = graph_gauss_certificate(3, 4)
    assert cert.passed
    assert cert.hilbert_dimension == 81
    assert cert.physical_dimension == 3


def test_joint_projector_is_exactly_idempotent():
    projector = physical_gauss_projector(3, 4)
    assert np.linalg.norm(projector @ projector - projector) < 1e-10
    assert np.linalg.norm(projector - projector.conj().T) < 1e-11


def test_master_constraint_and_hamiltonian_preserve_physical_states():
    cert = master_constraint_certificate(3, 4)
    assert cert.passed
    assert cert.master_kernel_dimension == 3
    assert cert.maximum_physical_leakage < 1e-10


def test_cycle_subdivision_preserves_reduced_dimension():
    cert = cycle_refinement_certificate(3, (3, 4, 5))
    assert cert["pass"]
    assert cert["physical_dimensions"] == [3, 3, 3]


def test_quantum_graph_suite():
    assert quantum_graph_suite()["pass"]
