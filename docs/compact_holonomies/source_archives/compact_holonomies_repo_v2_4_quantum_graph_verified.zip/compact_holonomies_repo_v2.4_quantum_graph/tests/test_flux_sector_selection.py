import pytest

from compact_holonomies.flux_sector_selection import (
    flux_selection_no_go_certificate,
    uniform_flux_action,
)


def test_uniform_flux_action_is_quadratic():
    assert uniform_flux_action(3) / uniform_flux_action(1) == pytest.approx(9.0)
    assert uniform_flux_action(-3) == pytest.approx(uniform_flux_action(3))


def test_minimal_positive_flux_action_does_not_select_three():
    cert = flux_selection_no_go_certificate()
    assert cert["pass"]
    assert cert["minimizing_charges"] == [0]
    assert cert["q3_action_gap_above_vacuum"] > 0
