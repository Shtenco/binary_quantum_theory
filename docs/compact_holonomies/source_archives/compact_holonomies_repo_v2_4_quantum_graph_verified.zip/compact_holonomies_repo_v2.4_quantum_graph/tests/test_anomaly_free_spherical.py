import numpy as np
from compact_holonomies.anomaly_free_spherical import (
    beta,
    canonical_holonomy_chart,
    continuum_closure_trial,
    f1,
    f2,
    signature_change_threshold,
    symbolic_certificate,
)


def test_symbolic_closure_identities_and_canonical_chart():
    certificate = symbolic_certificate()
    assert certificate["pass"]
    assert certificate["canonical_chart_poisson_bracket"] == "1"


def test_continuum_off_shell_closure_on_unseen_seed():
    result = continuum_closure_trial(grid_size=32, delta=0.27, seed=17)
    assert result.relative_residual < 1e-11


def test_classical_limits_numerically():
    k = np.array([-0.3, 0.1, 0.4])
    d = 1e-6
    assert np.allclose(f1(k, d), k**2, rtol=1e-9, atol=1e-12)
    assert np.allclose(f2(k, d), k, rtol=1e-9, atol=1e-12)
    assert np.allclose(beta(k, d), 1.0, rtol=1e-9, atol=1e-12)


def test_signature_threshold_and_local_canonical_map():
    d = 0.4
    threshold = signature_change_threshold(d)
    assert abs(beta(threshold, d)) < 1e-14
    kb, eb = canonical_holonomy_chart(0.2, 1.7, d)
    assert np.isfinite(kb) and np.isfinite(eb)
