from compact_holonomies.covariant_low_energy import (
    cubic_curvature_quadratic_order_certificate,
    gw170817_consistency_check,
    low_energy_predictions,
)


def test_cubic_curvature_does_not_change_quadratic_action():
    cert = cubic_curvature_quadratic_order_certificate()
    assert cert["quadratic_action_unchanged"]
    assert cert["leading_correction_is_cubic"]


def test_low_energy_tensor_predictions_and_external_consistency():
    prediction = low_energy_predictions()
    check = gw170817_consistency_check()
    assert prediction["tensor_polarizations"] == 2
    assert prediction["tree_level_c_gw_over_c"] == 1.0
    assert check["consistent"]
