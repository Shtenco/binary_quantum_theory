import numpy as np
import pytest

from compact_holonomies.quantum_holonomy_dynamics import (
    analytic_holonomy_spectrum,
    clock_shift_operators,
    continuum_limit_certificate,
    holonomy_laplacian,
    quantum_constraint_certificate,
    quantum_dynamics_suite,
    weyl_kinematics_certificate,
)


def test_exact_finite_weyl_relation():
    clock, shift, omega = clock_shift_operators(17)
    assert np.linalg.norm(clock @ shift - omega * shift @ clock) < 1e-12


def test_finite_ccr_obstruction_is_not_hidden():
    cert = weyl_kinematics_certificate(23)
    assert cert.passed
    assert cert.canonical_trace_obstruction == pytest.approx(23.0, abs=1e-10)
    assert cert.canonical_commutator_residual >= np.sqrt(23)


def test_holonomy_laplacian_matches_exact_spectrum():
    theta = holonomy_laplacian(19, lattice_spacing=0.3, mass=0.2)
    numerical = np.sort(np.linalg.eigvalsh(theta))
    analytic = analytic_holonomy_spectrum(19, lattice_spacing=0.3, mass=0.2)
    assert np.max(np.abs(numerical - analytic)) < 1e-10


def test_relational_quantum_constraint_is_unitary_and_solved():
    cert = quantum_constraint_certificate()
    assert cert.passed
    assert cert.minimum_theta_eigenvalue > 0
    assert cert.maximum_evolution_unitarity_error < 1e-11
    assert cert.klein_gordon_constraint_residual < 1e-9


def test_low_mode_continuum_limit_is_second_order():
    cert = continuum_limit_certificate()
    assert cert.passed
    assert cert.fitted_order == pytest.approx(2.0, abs=0.05)
    assert cert.relative_errors[-1] < cert.relative_errors[0]


def test_quantum_dynamics_suite():
    suite = quantum_dynamics_suite()
    assert suite["pass"]
