from compact_holonomies.generation_selection import generation_selection_certificate


def test_current_constraints_do_not_select_three_generations():
    cert = generation_selection_certificate()
    assert cert["pass"]
    assert cert["allowed_positive_generation_counts"] == [1, 2, 3, 4, 5]
    assert cert["three_is_allowed"]
    assert not cert["three_is_unique"]
