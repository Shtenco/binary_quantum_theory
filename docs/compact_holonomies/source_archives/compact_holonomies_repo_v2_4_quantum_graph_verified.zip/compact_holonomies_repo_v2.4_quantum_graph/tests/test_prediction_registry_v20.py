from compact_holonomies.prediction_registry import constants_coverage_report, registry


def test_registry_records_failed_continuous_test_without_fake_445_claim():
    items = registry()
    report = constants_coverage_report(445)
    assert len(items) >= 14
    assert report["continuous_physical_predictions_tested"] == 1
    assert report["continuous_physical_predictions_passed"] == 0
    assert report["successful_coverage_fraction"] == 0.0
    assert report["failed_tests"][0]["prediction_id"] == "P012"
