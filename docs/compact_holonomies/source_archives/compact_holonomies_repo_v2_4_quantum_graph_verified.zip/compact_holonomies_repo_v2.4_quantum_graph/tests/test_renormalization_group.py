from fractions import Fraction

from compact_holonomies.renormalization_group import (
    inverse_alpha_running,
    rg_certificate,
    standard_model_one_loop_beta_coefficients,
)


def test_exact_standard_model_beta_coefficients():
    result = standard_model_one_loop_beta_coefficients()
    assert result.b1 == Fraction(41, 10)
    assert result.b2 == Fraction(-19, 6)
    assert result.b3 == Fraction(-7, 1)
    assert rg_certificate()["pass"]


def test_asymptotic_freedom_signs():
    result = standard_model_one_loop_beta_coefficients()
    assert result.b1 > 0
    assert result.b2 < 0
    assert result.b3 < 0


def test_one_loop_running_identity_at_reference_scale():
    alpha = 0.118
    assert inverse_alpha_running(alpha, Fraction(-7), 91.0, 91.0) == 1.0 / alpha
