from compact_holonomies.gauge_sector import standard_model_gauge_certificate


def test_compact_standard_model_gauge_representation_closes():
    result = standard_model_gauge_certificate()
    assert result["pass"]
    assert result["total_generator_count"] == 12
    assert "not uniquely derived" in result["derivation_status"].lower()
