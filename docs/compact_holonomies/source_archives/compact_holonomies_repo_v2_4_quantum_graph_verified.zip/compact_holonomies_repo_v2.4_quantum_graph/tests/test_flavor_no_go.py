from compact_holonomies.flavor_no_go import constant_higgs_flavor_certificate


def test_constant_higgs_gives_degenerate_topological_families():
    cert = constant_higgs_flavor_certificate(6, 3)
    assert cert["pass"]
    assert cert["family_dimension"] == 3
    assert cert["identity_error"] < 1e-12
    assert cert["degeneracy_spread"] < 1e-12
