import sympy as sp

from compact_holonomies.anomaly_free_matter import (
    anomaly_polynomials,
    electric_charges,
    minimal_hypercharge_solution,
    right_neutrino_family,
    symbolic_hypercharge_certificate,
    yukawa_residuals,
)


def test_minimal_hypercharges_and_charges():
    solution = minimal_hypercharge_solution(sp.Rational(1, 2))
    assert all(value == 0 for value in anomaly_polynomials(solution).values())
    assert all(value == 0 for value in yukawa_residuals(solution).values())
    charges = electric_charges(solution)
    assert charges["u_L"] == sp.Rational(2, 3)
    assert charges["d_L"] == sp.Rational(-1, 3)
    assert charges["e_L"] == -1
    assert charges["nu_L"] == 0


def test_right_neutrino_family_is_anomaly_free_but_not_unique():
    q, h = sp.symbols("q h")
    solution = right_neutrino_family(q, h)
    assert all(value == 0 for value in anomaly_polynomials(solution).values())
    assert all(value == 0 for value in yukawa_residuals(solution).values())


def test_symbolic_hypercharge_certificate():
    assert symbolic_hypercharge_certificate()["pass"]
