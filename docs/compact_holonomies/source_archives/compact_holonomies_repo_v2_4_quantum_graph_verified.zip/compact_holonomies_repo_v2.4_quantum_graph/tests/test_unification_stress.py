from fractions import Fraction

from compact_holonomies.unification_stress import (
    fermion_trace_normalizations,
    minimal_unification_stress_certificate,
    spectral_coupling_certificate,
)


def test_exact_trace_relation_and_weak_angle():
    traces = fermion_trace_normalizations(1)
    assert traces.k_y == Fraction(10, 3)
    assert traces.k_su2 == 2
    assert traces.k_su3 == 2
    cert = spectral_coupling_certificate()
    assert cert["pass"]
    assert cert["sin2_thetaW_at_common_normalization_scale"] == "3/8"


def test_minimal_unification_is_falsified_by_held_out_alpha_s():
    cert = minimal_unification_stress_certificate()
    assert cert["test_pass"]
    assert not cert["minimal_exact_one_loop_unification_survives"]
    assert cert["prediction"]["predicted_alpha3_MZ"] < 0.08
    assert cert["observed_alpha3_MZ"] > 0.11
    assert cert["pairwise_scale_spread_factor"] > 1000
