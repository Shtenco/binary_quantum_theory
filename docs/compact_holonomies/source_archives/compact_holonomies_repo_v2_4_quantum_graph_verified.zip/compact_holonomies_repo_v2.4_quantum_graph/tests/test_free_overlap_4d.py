from compact_holonomies.free_overlap_4d import (
    continuum_convergence,
    euclidean_gamma_certificate,
    free_overlap_4d_certificate,
)


def test_euclidean_gamma_algebra():
    assert euclidean_gamma_certificate()["pass"]


def test_free_overlap_has_one_physical_corner_and_no_doublers():
    certificate = free_overlap_4d_certificate()
    assert certificate["pass"]
    assert certificate["physical_zero_corner_error"] < 1e-12
    assert certificate["minimum_doubler_corner_gap"] > 1.9


def test_free_overlap_continuum_order():
    result = continuum_convergence()
    assert result["pass"]
    assert result["minimum_observed_order"] > 1.9
