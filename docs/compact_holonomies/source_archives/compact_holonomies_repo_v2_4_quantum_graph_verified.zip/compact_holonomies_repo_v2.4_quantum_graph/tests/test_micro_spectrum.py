from pathlib import Path
import numpy as np
from compact_holonomies.micro_spectrum import (
    analytic_eigenvalues,
    compact_laplacian,
    run_blind_spectrum_suite,
    run_blind_spectrum_test,
    universal_series_ratio,
)


def test_analytic_spectrum_matches_independent_diagonalization():
    n, delta, twist = 23, 0.41, 0.73
    numerical = np.linalg.eigvalsh(compact_laplacian(n, delta, twist))
    predicted = analytic_eigenvalues(n, delta, twist)
    assert np.allclose(predicted, numerical, rtol=1e-12, atol=1e-12)


def test_universal_series_ratio():
    assert abs(universal_series_ratio() - 0.4) < 1e-15


def test_preregistered_blind_challenge_passes():
    root = Path(__file__).resolve().parents[1]
    result = run_blind_spectrum_test(root / "preregistration/A20_micro_spectrum_manifest.json")
    assert result["pass"]
    assert result["holdout_fraction"] >= 0.6
    assert result["compact_prediction"]["normalized_rmse"] < 1e-12


def test_blind_suite_wins_all_hashed_challenges():
    root = Path(__file__).resolve().parents[1]
    result = run_blind_spectrum_suite(root / "preregistration/A20_micro_spectrum_manifest.json", challenge_count=8)
    assert result["pass"]
    assert result["wins_against_quartic"] == 8
