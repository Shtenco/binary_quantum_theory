#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

from compact_holonomies.quantum_holonomy_dynamics import quantum_dynamics_suite

result = quantum_dynamics_suite()
out = Path("artifacts/A33_A35_quantum_dynamics")
out.mkdir(parents=True, exist_ok=True)
(out / "quantum_dynamics_certificate.json").write_text(
    json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
)
print(json.dumps(result, indent=2, sort_keys=True))
if not result["pass"]:
    raise SystemExit(1)
