#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from compact_holonomies.prediction_registry import constants_coverage_report

result = constants_coverage_report(445)
result["artifact_id"] = "A21"
out = ROOT / "artifacts/A21_prediction_registry/prediction_registry_audit.json"
out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(result, indent=2, ensure_ascii=False))
