#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

from compact_holonomies.flux_sector_selection import flux_selection_no_go_certificate

result = flux_selection_no_go_certificate()
out = Path("artifacts/A36_flux_sector_selection")
out.mkdir(parents=True, exist_ok=True)
(out / "flux_selection_no_go.json").write_text(
    json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
)
print(json.dumps(result, indent=2, sort_keys=True))
if not result["pass"]:
    raise SystemExit(1)
