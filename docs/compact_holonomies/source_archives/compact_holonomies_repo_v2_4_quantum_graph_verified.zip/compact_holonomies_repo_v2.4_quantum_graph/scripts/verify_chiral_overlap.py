#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from compact_holonomies.chiral_overlap import chiral_flux_suite


def main() -> None:
    result = chiral_flux_suite()
    out = Path("artifacts/A24_chiral_overlap")
    out.mkdir(parents=True, exist_ok=True)
    (out / "chiral_overlap_certificate.json").write_text(
        json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(json.dumps({k: v for k, v in result.items() if k != "trials"}, indent=2))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
