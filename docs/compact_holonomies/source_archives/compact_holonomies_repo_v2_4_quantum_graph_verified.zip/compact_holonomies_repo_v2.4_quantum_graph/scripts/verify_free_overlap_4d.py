#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from compact_holonomies.free_overlap_4d import free_overlap_4d_certificate


def main() -> None:
    result = free_overlap_4d_certificate()
    out = Path("artifacts/A27_free_overlap_4d")
    out.mkdir(parents=True, exist_ok=True)
    (out / "free_overlap_4d_certificate.json").write_text(
        json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(json.dumps({key: value for key, value in result.items() if key != "corner_spectrum"}, indent=2))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
