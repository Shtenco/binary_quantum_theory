#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from compact_holonomies.anomaly_free_matter import symbolic_hypercharge_certificate
from compact_holonomies.renormalization_group import rg_certificate


def main() -> None:
    result = {
        "A25_hypercharge_anomaly_cancellation": symbolic_hypercharge_certificate(),
        "A26_one_loop_rg": rg_certificate(),
    }
    result["pass"] = all(section["pass"] for key, section in result.items() if key.startswith("A"))
    out = Path("artifacts/A25_A26_chiral_matter_rg")
    out.mkdir(parents=True, exist_ok=True)
    (out / "chiral_matter_rg_certificate.json").write_text(
        json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
