#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.topological_generations import three_generation_suite

result = three_generation_suite()
out = Path("artifacts/A28_topological_generations")
out.mkdir(parents=True, exist_ok=True)
(out / "topological_generations_certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k != "trials"}, indent=2))
if not result["pass"]:
    raise SystemExit(1)
