#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.unification_stress import spectral_coupling_certificate, minimal_unification_stress_certificate

result = {
    "trace_relation": spectral_coupling_certificate(),
    "minimal_model_death_test": minimal_unification_stress_certificate(),
}
out = Path("artifacts/A29_A30_unification")
out.mkdir(parents=True, exist_ok=True)
(out / "unification_certificate.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2))
if not result["trace_relation"]["pass"] or not result["minimal_model_death_test"]["test_pass"]:
    raise SystemExit(1)
