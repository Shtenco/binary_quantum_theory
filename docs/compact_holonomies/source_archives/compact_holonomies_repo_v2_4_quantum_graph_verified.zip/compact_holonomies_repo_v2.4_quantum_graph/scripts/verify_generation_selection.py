#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.generation_selection import generation_selection_certificate

result = generation_selection_certificate()
out = Path("artifacts/A31_generation_selection")
out.mkdir(parents=True, exist_ok=True)
(out / "generation_selection_no_go.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k != "rows"}, indent=2))
if not result["pass"]:
    raise SystemExit(1)
