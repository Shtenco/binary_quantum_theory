#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from compact_holonomies.micro_spectrum import (
    run_blind_spectrum_suite,
    run_blind_spectrum_test,
    write_default_manifest,
)

manifest = ROOT / "preregistration/A20_micro_spectrum_manifest.json"
if not manifest.exists():
    write_default_manifest(manifest)
result = {
    "artifact_id": "A20",
    "single_challenge": run_blind_spectrum_test(manifest),
    "challenge_suite": run_blind_spectrum_suite(manifest, challenge_count=32),
    "interpretation": (
        "Out-of-sample mathematical prediction for a fixed compact micro-operator. "
        "The formula is frozen before the hashed challenges and has no fitted "
        "observable-specific coefficients. This does not by itself predict particle "
        "masses or CODATA/PDG constants."
    ),
}
result["pass"] = bool(result["single_challenge"]["pass"] and result["challenge_suite"]["pass"])
out = ROOT / "artifacts/A20_blind_micro_spectrum/blind_micro_spectrum_results.json"
out.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
if not result["pass"]:
    raise SystemExit(1)
