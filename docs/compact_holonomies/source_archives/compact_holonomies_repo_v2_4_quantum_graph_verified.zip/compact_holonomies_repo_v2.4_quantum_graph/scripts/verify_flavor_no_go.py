#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from compact_holonomies.flavor_no_go import constant_higgs_flavor_certificate

result = constant_higgs_flavor_certificate()
out = Path("artifacts/A32_flavor_no_go")
out.mkdir(parents=True, exist_ok=True)
(out / "constant_higgs_degeneracy.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2))
if not result["pass"]:
    raise SystemExit(1)
