#!/usr/bin/env python3
"""Standalone reproducibility checks for the controlled foam EFT layer."""
from __future__ import annotations

import json
import math
import pathlib
import sys
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from compact_holonomies.effective_foam_eft import (  # noqa: E402
    HolonomyCorrection,
    barrier_action,
    tunneling_amplitude,
    tunneling_probability,
    foam_corrected_barrier,
    phase_decoherence_factor,
    planck_suppression,
)

checks = []

def check(name, condition, detail):
    checks.append({"name": name, "pass": bool(condition), "detail": detail})
    print(f"[{'PASS' if condition else 'FAIL'}] {name}: {detail}")

h = HolonomyCorrection(0.02)
ks = np.linspace(-4.0, 4.0, 801)
viol = max(abs(h.apply(float(k))-k)-h.remainder_bound(float(k)) for k in ks)
check("holonomy_remainder_bound", viol <= 1e-14, f"max excess={viol:.3e}")

action, hbar = 2.7, 0.8
probs = [abs(tunneling_amplitude(action, hbar, p))**2 for p in np.linspace(-100,100,1001)]
spread = max(probs)-min(probs)
check("phase_modulus_invariance", spread < 1e-14, f"probability spread={spread:.3e}")
check("amplitude_probability_consistency",
      math.isclose(probs[0], tunneling_probability(action,hbar), rel_tol=1e-13),
      f"P={probs[0]:.8e}")

m, gap, width = 3.0, 5.0, 2.0
num = barrier_action(lambda x: gap, 0.0, m, 0.0, width)
exact = width*math.sqrt(2*m*gap)
check("rectangular_barrier", math.isclose(num,exact,rel_tol=1e-12), f"num={num:.12g}, exact={exact:.12g}")

supp = planck_suppression(1e-15,1.616255e-35,2)
check("nuclear_scale_planck_suppression", supp < 1e-39, f"(lP/L)^2={supp:.3e}")

v0=lambda x: 8.0
phi=lambda x: math.cos(x)
veff=foam_corrected_barrier(v0,phi,coupling=1.0,suppression=supp)
a0=barrier_action(v0,1.0,1.0,0.0,1.0)
a1=barrier_action(veff,1.0,1.0,0.0,1.0)
relative=abs(a1-a0)/a0
check("controlled_decoupling", relative < 1e-14, f"relative shift={relative:.3e}")

coh=phase_decoherence_factor(3.0)
check("random_phase_is_decohering", 0<coh<1, f"coherence factor={coh:.6f}")

out = ROOT / "artifacts" / "A16_effective_foam_eft" / "effective_foam_eft_results.json"
out.write_text(json.dumps({"checks":checks,"passed":sum(c['pass'] for c in checks),"total":len(checks)}, indent=2), encoding="utf-8")
print(f"\n{sum(c['pass'] for c in checks)}/{len(checks)} checks passed")
print(f"results: {out}")
raise SystemExit(0 if all(c['pass'] for c in checks) else 1)
