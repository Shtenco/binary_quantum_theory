#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from compact_holonomies.covariant_low_energy import (
    cubic_curvature_quadratic_order_certificate,
    gw170817_consistency_check,
    low_energy_predictions,
)

result = {
    "artifact_id": "A19",
    "completion_status": "explicit minimal completion choice; not uniquely derived from holonomies",
    "degree_counting_certificate": cubic_curvature_quadratic_order_certificate(),
    "predictions": low_energy_predictions(),
    "external_check": gw170817_consistency_check(),
}
result["pass"] = bool(
    result["degree_counting_certificate"]["quadratic_action_unchanged"]
    and result["degree_counting_certificate"]["leading_correction_is_cubic"]
    and result["predictions"]["tensor_polarizations"] == 2
    and result["external_check"]["consistent"]
)
out = ROOT / "artifacts/A19_covariant_low_energy/covariant_low_energy_results.json"
out.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
if not result["pass"]:
    raise SystemExit(1)
