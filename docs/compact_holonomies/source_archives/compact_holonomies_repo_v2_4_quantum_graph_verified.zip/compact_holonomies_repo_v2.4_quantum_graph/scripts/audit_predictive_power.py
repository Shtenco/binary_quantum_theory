#!/usr/bin/env python3
"""Machine-readable predictive-power and target-leakage audit."""
from __future__ import annotations
import ast
import json
from pathlib import Path
from datetime import datetime, timezone
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))
from compact_holonomies.prediction_registry import constants_coverage_report, registry

TARGET_CATALOG_SIZE = 445
FORBIDDEN_MODEL_SYMBOLS = {
    "curve_fit", "least_squares", "minimize", "differential_evolution",
    "experimental_value", "target_value", "measured_value", "pdg_value", "codata_value",
}


def scan_python():
    findings = []
    public_functions = []
    for path in sorted(SRC.rglob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_"):
                public_functions.append(f"{path.relative_to(ROOT)}:{node.name}")
            if isinstance(node, ast.Name) and node.id in FORBIDDEN_MODEL_SYMBOLS:
                findings.append({"file": str(path.relative_to(ROOT)), "symbol": node.id})
            if isinstance(node, ast.Attribute) and node.attr in FORBIDDEN_MODEL_SYMBOLS:
                findings.append({"file": str(path.relative_to(ROOT)), "symbol": node.attr})
    return public_functions, findings


def main():
    funcs, leakage = scan_python()
    coverage = constants_coverage_report(TARGET_CATALOG_SIZE)
    registered = [item.as_dict() for item in registry()]
    report = {
        "schema": "compact-holonomies-predictive-audit-v2",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "catalog_claim_tested": TARGET_CATALOG_SIZE,
        "definition_of_physical_constant_prediction": (
            "A named numerical CODATA/PDG observable with units and uncertainty, "
            "computed from preregistered theory-fixed inputs without using its measured "
            "value for fitting, formula selection, normalization, or acceptance."
        ),
        "public_model_functions": funcs,
        "target_leakage_symbols_found": leakage,
        "registered_structural_predictions": registered,
        "n_registered_structural_predictions": len(registered),
        "n_continuous_physical_predictions_tested": coverage["continuous_physical_predictions_tested"],
        "n_continuous_physical_predictions_passed": coverage["continuous_physical_predictions_passed"],
        "successful_physical_constant_coverage_fraction": coverage["successful_coverage_fraction"],
        "failed_continuous_tests": coverage["failed_tests"],
        "out_of_sample_mathematical_prediction_artifact": "A20",
        "out_of_sample_physical_constant_predictions_passed": 0,
        "status": "ONE_CONTINUOUS_DEATH_TEST_FAILED",
        "conclusion": (
            "The repository has structural predictions and now exposes one continuous gauge-coupling "
            "prediction to a held-out minimal-unification death test. That prediction fails. No measured "
            "continuous parameter has yet been successfully predicted, so successful coverage remains 0/445."
        ),
    }
    out = ROOT / "artifacts/A17_predictive_power_audit"
    out.mkdir(parents=True, exist_ok=True)
    (out / "predictive_power_audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if leakage:
        raise SystemExit("target leakage symbols found")

if __name__ == "__main__":
    main()
