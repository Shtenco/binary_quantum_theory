#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from compact_holonomies.gauge_sector import standard_model_gauge_certificate

result = standard_model_gauge_certificate()
result["artifact_id"] = "A22"
out = ROOT / "artifacts/A22_gauge_sector/gauge_sector_results.json"
out.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
if not result["pass"]:
    raise SystemExit(1)
