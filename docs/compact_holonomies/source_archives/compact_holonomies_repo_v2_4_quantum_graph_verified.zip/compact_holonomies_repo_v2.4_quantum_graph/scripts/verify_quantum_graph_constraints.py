#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

from compact_holonomies.quantum_graph_constraints import quantum_graph_suite

result = quantum_graph_suite()
out = Path("artifacts/A37_A39_quantum_graph")
out.mkdir(parents=True, exist_ok=True)
(out / "quantum_graph_constraints.json").write_text(
    json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
)
print(json.dumps(result, indent=2, sort_keys=True))
if not result["pass"]:
    raise SystemExit(1)
