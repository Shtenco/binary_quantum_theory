#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
for script in \
  artifacts/A1_spherical_holonomy/verify_sine_spherical.py \
  artifacts/A2_qec_counterexample/constraint_code_counterexample.py \
  artifacts/A3_uv_kernel_nonuniqueness/test_nonlocal_kernel_underdetermination.py \
  artifacts/A4_binary_walk_heat_kernel/verify_binary_walk_heat_kernel.py \
  artifacts/A5_binary_sine_foam/final_binary_sine_foam_check.py \
  artifacts/A6_death_test/binary_foam_death_test_full.py \
  artifacts/A7_su2_gauss_law/verify_su2_gauss_closure.py \
  artifacts/A8_su2_transfer_positivity/test_sine_action_reflection_positivity.py \
  artifacts/A9_finite_size_scaling/finite_size_scaling.py \
  artifacts/A10_hda_anomaly_test/hda_closure_toy_test.py \
  artifacts/A11_hda_second_attempt/hda_closure_curvature_ansatz.py \
  artifacts/A13_hda_systematic_sweep/hda_ansatz_sweep.py \
  artifacts/A14_midisuperspace_groundwork/midisuperspace_dof_count.py \
  artifacts/A15_tt_polarization_count/tt_count_rigorous.py
 do
  echo "=== $script ==="
  python3 "$script"
 done
