#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
LOG_DIR="$ROOT/artifacts/full_verification_logs"
mkdir -p "$LOG_DIR"
run() {
  local name="$1"; shift
  echo "[RUN] $name"
  timeout -s KILL 120s "$@" >"$LOG_DIR/$name.log" 2>&1
  echo "[PASS] $name"
}
run pytest pytest -q
run A0_document python3 scripts/verify_holonomy_document.py
run A16_eft python3 scripts/verify_effective_foam_eft.py
run A18_hda python3 scripts/verify_anomaly_free_spherical.py
run A19_low_energy python3 scripts/verify_covariant_low_energy.py
run A20_blind_spectrum python3 scripts/run_blind_micro_spectrum.py
run A22_gauge python3 scripts/verify_gauge_sector.py
run A23_freeze python3 scripts/freeze_future_predictions.py
run A24_chiral_overlap python3 scripts/verify_chiral_overlap.py
run A25_A26_matter_rg python3 scripts/verify_anomaly_free_matter.py
run A27_free_overlap_4d python3 scripts/verify_free_overlap_4d.py
run A28_topological_generations python3 scripts/verify_topological_generations.py
run A29_A30_unification python3 scripts/verify_unification_stress.py
run A31_generation_selection python3 scripts/verify_generation_selection.py
run A32_flavor_no_go python3 scripts/verify_flavor_no_go.py
run A33_A35_quantum_dynamics python3 scripts/verify_quantum_holonomy_dynamics.py
run A36_flux_sector_selection python3 scripts/verify_flux_sector_selection.py
run A37_A39_quantum_graph python3 scripts/verify_quantum_graph_constraints.py
run A17_audit python3 scripts/audit_predictive_power.py
run A21_registry python3 scripts/audit_prediction_registry.py
echo "ALL CORE CHECKS PASSED"
