#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from compact_holonomies.anomaly_free_spherical import (
    closure_convergence,
    signature_change_threshold,
    symbolic_certificate,
)

out = ROOT / "artifacts/A18_anomaly_free_spherical/anomaly_free_spherical_results.json"
cert = symbolic_certificate()
trials = closure_convergence()
finest = [t for t in trials if t.grid_size == max(x.grid_size for x in trials)]
result = {
    "artifact_id": "A18",
    "scope": "continuum vacuum spherical sector, not full 3+1 quantum gravity",
    "symbolic_certificate": cert,
    "closure_trials": [t.as_dict() for t in trials],
    "max_relative_residual_on_finest_grid": max(t.relative_residual for t in finest),
    "signature_change_threshold_delta_times_K": 3.141592653589793 / 4,
    "example_threshold_for_delta_0.3": signature_change_threshold(0.3),
}
result["pass"] = bool(cert["pass"] and result["max_relative_residual_on_finest_grid"] < 1e-11)
out.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
if not result["pass"]:
    raise SystemExit(1)
