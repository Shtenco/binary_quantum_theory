# Compact Holonomies v2.2 — topology, coupling death test, and flavor no-go

## Verified extension

```text
compact holonomies
  -> closed vacuum spherical HDA (restricted sector)
  -> explicit low-energy 4D completion (not unique)
  -> fixed compact micro-spectrum and mathematical blind challenges
  -> compact gauge representations
  -> exact overlap chirality and index
  -> conditional anomaly-free hypercharges and one-loop beta functions
  -> topological family multiplicity N_chiral=|Q|
  -> exact representation-trace relation sin^2(theta_W)=3/8
  -> held-out minimal-unification death test (FAILED physical model)
  -> generation-selection and flavor-hierarchy no-go results
```

## A28 — conditional three-family topology

For the registered compact U(1) overlap sector,

```text
index(D_ov) = -Q,
N_zero = |Q|.
```

The `Q=+3` sector contains exactly three negative-chirality zero modes and the
`Q=-3` sector contains exactly three positive-chirality zero modes.  Six
unselected lattice/orientation trials pass.  This removes the need to insert
three separate copies of a field *after Q=3 has been selected*.

It does **not** derive why the physical vacuum chooses `|Q|=3`.

## A29 — exact conditional gauge trace relation

For one assumed Standard-Model generation, the fermionic trace weights are

```text
k_Y = 10/3,  k_2 = 2,  k_3 = 2.
```

A single common microscopic trace coefficient therefore implies

```text
g_3^2 = g_2^2 = (5/3) g_Y^2,
sin^2(theta_W) = 3/8
```

at that common-normalization scale.  This is exact but conditional on the
representation pattern and the common-normalization hypothesis.

## A30 — minimal exact one-loop unification is falsified

A frozen PDG-2024 MS-bar benchmark is used:

- `alpha_hat^(5)(MZ)^-1 = 127.930 +/- 0.008`;
- `s_hat_Z^2 = 0.23129 +/- 0.00004`;
- held-out `alpha_s(MZ) = 0.1180 +/- 0.0009`.

Fitting exact unification to `alpha_1` and `alpha_2`, with Standard-Model
one-loop running and no thresholds, predicts

```text
M_U = 1.0139558685e13 GeV,
alpha_s(MZ) = 0.0710657973.
```

The relative miss is about `-39.8%`.  The experimental-only pull is about
`-52.1 sigma`, but that number intentionally excludes unknown theory/threshold
uncertainty.  More robustly, the three pairwise meeting scales differ by a
factor of about `9641`.

Therefore the exact minimal no-threshold model is dead.  A future completion
must add preregistered threshold content or altered microscopic dynamics; it
may not tune thresholds after examining the held-out coupling.

Benchmark sources:

- Particle Data Group 2024, *Electroweak Model and Constraints on New Physics*:
  `https://pdg.lbl.gov/2024/reviews/rpp2024-rev-standard-model.pdf`
- Particle Data Group 2024, *Quantum Chromodynamics*:
  `https://pdg.lbl.gov/2024/reviews/rpp2024-rev-qcd.pdf`

The 2024 benchmark is deliberately frozen for reproducibility rather than
silently updated after the test.

## A31 — current consistency conditions do not select three generations

Generation-wise local anomaly cancellation and the Witten parity condition
hold for every positive integer number of complete generations.  With one
Higgs doublet, one-loop asymptotic freedom gives

```text
SU(2): N_g < 43/8  -> N_g <= 5,
SU(3): N_g < 33/4  -> N_g <= 8.
```

Together these filters allow

```text
N_g in {1,2,3,4,5}.
```

Thus `N_g=3` is allowed but not unique.  The missing theorem is a dynamical
selection of the topological sector `|Q|=3`.

## A32 — topology alone does not generate flavor hierarchy

In the maximally symmetric same-bundle `Q=3` toy sector with a constant scalar
profile, the Yukawa overlap matrix is the identity on the three-dimensional
zero-mode subspace.  Its three singular values agree to about `7e-16`.

Hence topological multiplicity produces three families but a symmetric Higgs
profile produces degenerate masses and no nontrivial mixing.  Hierarchy
requires additional nonuniform profiles, Wilson lines, different bundles, or
another derived symmetry-breaking mechanism.  Those quantities are not yet
predicted.

## Current empirical coverage

- Continuous physical predictions tested: **1**.
- Continuous physical predictions passed: **0**.
- Successful 445-parameter coverage: **0/445**.

This release is scientifically stronger because a concrete numerical
prediction was allowed to fail and the failure was retained in the registry.
