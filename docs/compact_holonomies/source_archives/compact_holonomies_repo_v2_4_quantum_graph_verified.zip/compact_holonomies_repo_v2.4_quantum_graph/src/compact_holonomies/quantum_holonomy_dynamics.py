"""Finite quantum holonomy kinematics and a controlled relational dynamics toy model.

The purpose of this module is deliberately narrow.  It upgrades the project
from purely classical Poisson-bracket checks to an explicit finite Hilbert
space with:

* an exact unitary Weyl (clock--shift) algebra;
* a self-adjoint positive holonomy Laplacian;
* a positive-frequency solution of a Klein--Gordon-type quantum constraint;
* a controlled low-mode continuum limit.

It is **not** a quantization of four-dimensional general relativity.  Finite
matrices cannot satisfy the canonical commutator [q,p]=i I exactly (the trace
of any commutator vanishes), so the exact kinematics is formulated with Weyl
operators instead.  This finite-dimensional obstruction is recorded as a
result rather than hidden by a truncated commutator test.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

import numpy as np
from scipy.linalg import eigh


Array = np.ndarray


def _frobenius(matrix: Array) -> float:
    return float(np.linalg.norm(matrix, ord="fro"))


def clock_shift_operators(dimension: int) -> tuple[Array, Array, complex]:
    """Return the exact finite Weyl pair ``(U, V, omega)``.

    In the computational basis ``|n>`` we use

    ``U|n> = omega**n |n>`` and ``V|n> = |n+1 mod N>``.

    Therefore ``U V = omega V U`` exactly up to floating-point roundoff.
    """
    n = int(dimension)
    if n < 3:
        raise ValueError("dimension must be at least 3")
    omega = np.exp(2j * np.pi / n)
    clock = np.diag(omega ** np.arange(n))
    shift = np.roll(np.eye(n, dtype=complex), 1, axis=0)
    return clock, shift, omega


def finite_angle_and_momentum(dimension: int) -> tuple[Array, Array]:
    """Construct one conventional angle operator and Fourier momentum.

    These operators are used only to expose the finite-dimensional canonical
    commutator obstruction.  The exact algebraic object is the Weyl pair from
    :func:`clock_shift_operators`.
    """
    n = int(dimension)
    if n < 3:
        raise ValueError("dimension must be at least 3")
    angles = 2.0 * np.pi * (np.arange(n) - (n - 1) / 2.0) / n
    angle = np.diag(angles)
    # Columns of F are momentum eigenvectors in the angle basis.
    rows = np.arange(n)[:, None]
    cols = np.arange(n)[None, :]
    fourier = np.exp(2j * np.pi * rows * cols / n) / np.sqrt(n)
    momenta = np.fft.fftfreq(n) * n
    momentum = fourier @ np.diag(momenta) @ fourier.conj().T
    momentum = 0.5 * (momentum + momentum.conj().T)
    return angle.astype(complex), momentum


@dataclass(frozen=True)
class WeylKinematicsCertificate:
    dimension: int
    clock_unitarity_error: float
    shift_unitarity_error: float
    weyl_relation_error: float
    canonical_commutator_residual: float
    canonical_trace_obstruction: float
    expected_trace_obstruction: float
    passed: bool
    verdict: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def weyl_kinematics_certificate(dimension: int = 31) -> WeylKinematicsCertificate:
    """Verify exact Weyl kinematics and the finite CCR no-go theorem."""
    clock, shift, omega = clock_shift_operators(dimension)
    identity = np.eye(dimension, dtype=complex)
    clock_unitarity = _frobenius(clock.conj().T @ clock - identity)
    shift_unitarity = _frobenius(shift.conj().T @ shift - identity)
    weyl_error = _frobenius(clock @ shift - omega * shift @ clock)

    angle, momentum = finite_angle_and_momentum(dimension)
    commutator = angle @ momentum - momentum @ angle
    canonical_residual_matrix = commutator - 1j * identity
    canonical_residual = _frobenius(canonical_residual_matrix)
    trace_obstruction = float(abs(np.trace(canonical_residual_matrix)))
    expected_trace = float(dimension)

    passed = bool(
        clock_unitarity < 1e-12
        and shift_unitarity < 1e-12
        and weyl_error < 1e-11
        and abs(trace_obstruction - expected_trace) < 1e-10
        and canonical_residual >= np.sqrt(dimension) * (1.0 - 1e-12)
    )
    return WeylKinematicsCertificate(
        dimension=int(dimension),
        clock_unitarity_error=clock_unitarity,
        shift_unitarity_error=shift_unitarity,
        weyl_relation_error=weyl_error,
        canonical_commutator_residual=canonical_residual,
        canonical_trace_obstruction=trace_obstruction,
        expected_trace_obstruction=expected_trace,
        passed=passed,
        verdict=(
            "The finite Hilbert space carries an exact unitary Weyl algebra. "
            "An exact canonical commutator is impossible because Tr[A,B]=0 "
            "while Tr(iI)=iN; the project therefore uses exponentiated "
            "holonomy-flux kinematics rather than a fake truncated CCR."
        ),
    )


def holonomy_laplacian(
    dimension: int,
    lattice_spacing: float = 1.0,
    mass: float = 0.0,
) -> Array:
    """Positive compact-shift Laplacian ``Theta`` on a periodic finite space."""
    if lattice_spacing <= 0:
        raise ValueError("lattice_spacing must be positive")
    if mass < 0:
        raise ValueError("mass must be non-negative")
    _, shift, _ = clock_shift_operators(dimension)
    identity = np.eye(dimension, dtype=complex)
    theta = (2.0 * identity - shift - shift.conj().T) / lattice_spacing**2
    theta = theta + mass**2 * identity
    return 0.5 * (theta + theta.conj().T)


def analytic_holonomy_spectrum(
    dimension: int,
    lattice_spacing: float = 1.0,
    mass: float = 0.0,
) -> Array:
    """Analytic spectrum of :func:`holonomy_laplacian`."""
    k = np.arange(int(dimension), dtype=float)
    values = 4.0 * np.sin(np.pi * k / dimension) ** 2 / lattice_spacing**2 + mass**2
    return np.sort(values)


@dataclass(frozen=True)
class QuantumConstraintCertificate:
    dimension: int
    lattice_spacing: float
    mass: float
    theta_hermiticity_error: float
    minimum_theta_eigenvalue: float
    spectral_error: float
    square_root_factorization_error: float
    maximum_evolution_unitarity_error: float
    maximum_state_norm_error: float
    klein_gordon_constraint_residual: float
    passed: bool
    verdict: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def quantum_constraint_certificate(
    dimension: int = 31,
    lattice_spacing: float = 0.2,
    mass: float = 0.35,
    relational_times: Iterable[float] = (0.0, 0.37, 1.1, 2.3),
) -> QuantumConstraintCertificate:
    r"""Construct and verify a positive-frequency quantum constraint solution.

    The toy physical equation is

    ``d_phi^2 Psi + Theta Psi = 0``.

    On the positive-frequency branch,

    ``i d_phi Psi = sqrt(Theta) Psi``.

    Since ``Theta`` is positive and self-adjoint, the relational evolution in
    ``phi`` is unitary and exactly solves the second-order constraint.  This is
    a genuine finite quantum dynamics, but only for one compact degree of
    freedom; it is not the Hamiltonian constraint of full 3+1 gravity.
    """
    theta = holonomy_laplacian(dimension, lattice_spacing, mass)
    hermiticity_error = _frobenius(theta - theta.conj().T)
    eigenvalues, eigenvectors = eigh(theta)
    minimum_eigenvalue = float(np.min(eigenvalues))
    analytic = analytic_holonomy_spectrum(dimension, lattice_spacing, mass)
    spectral_error = float(np.max(np.abs(np.sort(eigenvalues) - analytic)))

    frequencies = np.sqrt(np.clip(eigenvalues, 0.0, None))
    hamiltonian = (eigenvectors * frequencies) @ eigenvectors.conj().T
    hamiltonian = 0.5 * (hamiltonian + hamiltonian.conj().T)
    factorization_error = _frobenius(hamiltonian @ hamiltonian - theta)

    sites = np.arange(dimension, dtype=float)
    center = 0.37 * (dimension - 1)
    width = max(2.0, dimension / 8.0)
    state0 = np.exp(-0.5 * ((sites - center) / width) ** 2) * np.exp(0.41j * sites)
    state0 = state0 / np.linalg.norm(state0)
    identity = np.eye(dimension, dtype=complex)

    unitary_errors: list[float] = []
    norm_errors: list[float] = []
    for relational_time in relational_times:
        phases = np.exp(-1j * frequencies * float(relational_time))
        evolution = (eigenvectors * phases) @ eigenvectors.conj().T
        unitary_errors.append(_frobenius(evolution.conj().T @ evolution - identity))
        evolved = evolution @ state0
        norm_errors.append(float(abs(np.vdot(evolved, evolved).real - 1.0)))

    kg_residual = _frobenius(-hamiltonian @ hamiltonian + theta)
    max_unitarity = max(unitary_errors, default=0.0)
    max_norm_error = max(norm_errors, default=0.0)
    passed = bool(
        hermiticity_error < 1e-12
        and minimum_eigenvalue >= -1e-12
        and spectral_error < 1e-10
        and factorization_error < 1e-9
        and max_unitarity < 1e-11
        and max_norm_error < 1e-12
        and kg_residual < 1e-9
    )
    return QuantumConstraintCertificate(
        dimension=int(dimension),
        lattice_spacing=float(lattice_spacing),
        mass=float(mass),
        theta_hermiticity_error=hermiticity_error,
        minimum_theta_eigenvalue=minimum_eigenvalue,
        spectral_error=spectral_error,
        square_root_factorization_error=factorization_error,
        maximum_evolution_unitarity_error=max_unitarity,
        maximum_state_norm_error=max_norm_error,
        klein_gordon_constraint_residual=kg_residual,
        passed=passed,
        verdict=(
            "A positive self-adjoint compact holonomy operator defines exact "
            "unitary relational evolution and a nonempty family of physical "
            "positive-frequency solutions. The construction is a one-degree-"
            "of-freedom quantum laboratory, not full quantum gravity."
        ),
    )


@dataclass(frozen=True)
class ContinuumLimitCertificate:
    circumference: float
    mode_number: int
    dimensions: tuple[int, ...]
    lattice_spacings: tuple[float, ...]
    relative_errors: tuple[float, ...]
    fitted_order: float
    leading_coefficient_ratio: float
    expected_leading_coefficient_ratio: float
    passed: bool
    verdict: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def continuum_limit_certificate(
    circumference: float = 2.0 * np.pi,
    mode_number: int = 2,
    dimensions: tuple[int, ...] = (32, 48, 64, 96, 128, 192),
) -> ContinuumLimitCertificate:
    """Verify second-order convergence of low modes to the continuum circle."""
    if circumference <= 0:
        raise ValueError("circumference must be positive")
    if mode_number <= 0:
        raise ValueError("mode_number must be positive")
    if any(n <= 2 * mode_number for n in dimensions):
        raise ValueError("each dimension must resolve the requested low mode")

    continuum = (2.0 * np.pi * mode_number / circumference) ** 2
    spacings: list[float] = []
    relative_errors: list[float] = []
    for n in dimensions:
        spacing = circumference / n
        discrete = 4.0 * np.sin(np.pi * mode_number / n) ** 2 / spacing**2
        spacings.append(float(spacing))
        relative_errors.append(float(abs(discrete - continuum) / continuum))

    log_h = np.log(np.asarray(spacings))
    log_e = np.log(np.asarray(relative_errors))
    fitted_order = float(np.polyfit(log_h, log_e, 1)[0])

    # sin^2(x)/x^2 = 1 - x^2/3 + O(x^4), hence
    # relative error / h^2 -> (2*pi*m/L)^2 / 12.
    measured_ratio = relative_errors[-1] / spacings[-1] ** 2
    expected_ratio = continuum / 12.0
    monotone = all(
        relative_errors[index + 1] < relative_errors[index]
        for index in range(len(relative_errors) - 1)
    )
    passed = bool(
        monotone
        and 1.95 < fitted_order < 2.05
        and abs(measured_ratio / expected_ratio - 1.0) < 0.01
    )
    return ContinuumLimitCertificate(
        circumference=float(circumference),
        mode_number=int(mode_number),
        dimensions=tuple(int(n) for n in dimensions),
        lattice_spacings=tuple(spacings),
        relative_errors=tuple(relative_errors),
        fitted_order=fitted_order,
        leading_coefficient_ratio=float(measured_ratio),
        expected_leading_coefficient_ratio=float(expected_ratio),
        passed=passed,
        verdict=(
            "The low compact-holonomy spectrum converges to the continuum "
            "circle Laplacian with the preregistered O(a^2) error and the "
            "correct leading coefficient. This controls one spectral limit, "
            "not the continuum limit of interacting 3+1 geometry."
        ),
    )


def quantum_dynamics_suite() -> dict[str, Any]:
    """Run the complete A33--A35 finite quantum dynamics suite."""
    kinematics = weyl_kinematics_certificate().as_dict()
    constraint = quantum_constraint_certificate().as_dict()
    continuum = continuum_limit_certificate().as_dict()
    return {
        "A33_weyl_kinematics": kinematics,
        "A34_quantum_constraint": constraint,
        "A35_continuum_limit": continuum,
        "pass": bool(kinematics["passed"] and constraint["passed"] and continuum["passed"]),
        "scope": (
            "finite one-degree-of-freedom compact quantum laboratory; explicit "
            "Hilbert space and unitary relational dynamics, but no full 3+1 "
            "Hamiltonian/diffeomorphism/Gauss operator algebra"
        ),
    }
