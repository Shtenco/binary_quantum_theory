"""An anomaly-free vacuum spherical sector with compact holonomy functions.

This module implements the continuum effective constraint system used in the
spherically symmetric loop-gravity literature.  It deliberately does *not*
claim a solution of the full 3+1 quantum-gravity constraint problem.

The key consistency identities are

    2 f2(K) = d f1(K) / dK,
    beta(K) = d f2(K) / dK = 1/2 d^2 f1(K) / dK^2.

For the compact choice

    f1 = sin(delta K)^2 / delta^2,
    f2 = sin(2 delta K) / (2 delta),
    beta = cos(2 delta K),

the vacuum spherical Hamiltonian constraints close with a deformed structure
function beta.  A pseudospectral, off-shell functional Poisson-bracket check is
provided below as an independent numerical certificate.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import sympy as sp


def f1(k: np.ndarray | float, delta: float) -> np.ndarray | float:
    if delta <= 0:
        raise ValueError("delta must be positive")
    return np.sin(delta * k) ** 2 / delta**2


def f2(k: np.ndarray | float, delta: float) -> np.ndarray | float:
    if delta <= 0:
        raise ValueError("delta must be positive")
    return np.sin(2.0 * delta * k) / (2.0 * delta)


def beta(k: np.ndarray | float, delta: float) -> np.ndarray | float:
    if delta <= 0:
        raise ValueError("delta must be positive")
    return np.cos(2.0 * delta * k)


def signature_change_threshold(delta: float) -> float:
    """Smallest positive K at which beta changes sign."""
    if delta <= 0:
        raise ValueError("delta must be positive")
    return np.pi / (4.0 * delta)


def canonical_holonomy_chart(k: np.ndarray | float, e: np.ndarray | float, delta: float):
    """Local canonical chart Kbar=sin(delta K)/delta, Ebar=E/cos(delta K).

    The chart is valid only where cos(delta K) != 0.  It is useful as an exact
    local proof that compactification can be introduced without changing the
    Poisson bracket, provided both members of the canonical pair are transformed.
    """
    c = np.cos(delta * k)
    if np.any(np.isclose(c, 0.0, atol=1e-12)):
        raise ValueError("canonical chart is singular where cos(delta*K)=0")
    return np.sin(delta * k) / delta, e / c


def symbolic_certificate() -> dict[str, str | bool]:
    k, d, e = sp.symbols("K delta E", real=True, nonzero=True)
    f1_s = sp.sin(d * k) ** 2 / d**2
    f2_s = sp.sin(2 * d * k) / (2 * d)
    beta_s = sp.cos(2 * d * k)
    kbar = sp.sin(d * k) / d
    ebar = e / sp.cos(d * k)

    identity_1 = sp.simplify(2 * f2_s - sp.diff(f1_s, k))
    identity_2 = sp.simplify(beta_s - sp.diff(f2_s, k))
    poisson = sp.simplify(sp.diff(kbar, k) * sp.diff(ebar, e) - sp.diff(kbar, e) * sp.diff(ebar, k))
    f1_limit = sp.limit(f1_s, d, 0)
    f2_limit = sp.limit(f2_s, d, 0)
    beta_limit = sp.limit(beta_s, d, 0)

    return {
        "2f2_minus_df1": str(identity_1),
        "beta_minus_df2": str(identity_2),
        "canonical_chart_poisson_bracket": str(poisson),
        "classical_limit_f1": str(f1_limit),
        "classical_limit_f2": str(f2_limit),
        "classical_limit_beta": str(beta_limit),
        "pass": bool(identity_1 == 0 and identity_2 == 0 and poisson == 1),
    }


def _spectral_derivative_matrix(n: int, length: float = 2 * np.pi) -> np.ndarray:
    if n < 8:
        raise ValueError("n must be at least 8")
    eye = np.eye(n)
    wave_numbers = 2 * np.pi * np.fft.fftfreq(n, d=length / n)
    columns = [
        np.fft.ifft(1j * wave_numbers * np.fft.fft(eye[:, j])).real
        for j in range(n)
    ]
    return np.column_stack(columns)


def _complex_step_gradient(function, vector: np.ndarray, step: float = 1e-30) -> np.ndarray:
    gradient = np.empty(vector.size, dtype=float)
    for j in range(vector.size):
        shifted = vector.astype(complex)
        shifted[j] += 1j * step
        gradient[j] = np.imag(function(shifted)) / step
    return gradient


@dataclass(frozen=True)
class ClosureTrial:
    grid_size: int
    seed: int
    delta: float
    bracket: float
    expected_closed_bracket: float
    absolute_residual: float
    relative_residual: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def continuum_closure_trial(grid_size: int = 32, delta: float = 0.3, seed: int = 1) -> ClosureTrial:
    """Off-shell numerical check of the vacuum spherical HDA.

    The radial domain is periodic and all fields are smooth low-frequency random
    trigonometric polynomials.  Functional derivatives are evaluated by the
    complex-step method; spatial derivatives are pseudospectral.  The convention
    used here gives

      {H[N1],H[N2]} = 1/2 D[ beta Ex/Ephi^2 (N1 N2' - N2 N1') ].

    The factor 1/2 is convention-specific and follows from the canonical
    normalization {K_phi,E_phi}=G/2 used by this implementation.  The meaningful
    test is that the off-shell residual converges to zero and the structure
    function is exactly beta=cos(2 delta K_phi).
    """
    if delta <= 0:
        raise ValueError("delta must be positive")
    n = int(grid_size)
    length = 2 * np.pi
    dx = length / n
    derivative = _spectral_derivative_matrix(n, length)
    x = np.arange(n) * dx
    rng = np.random.default_rng(seed)

    def smooth_field(base: float, amplitude: float) -> np.ndarray:
        values = np.full(n, base, dtype=float)
        for mode in range(1, 4):
            values += amplitude * (
                rng.normal() * np.sin(mode * x) + rng.normal() * np.cos(mode * x)
            ) / mode
        return values

    lapse_1 = smooth_field(1.0, 0.08)
    lapse_2 = smooth_field(0.7, 0.08)
    ex = smooth_field(2.0, 0.08)
    ephi = smooth_field(1.3, 0.05)
    kx = smooth_field(0.0, 0.05)
    kphi = smooth_field(0.0, 0.05)
    if np.min(ex) <= 0 or np.min(ephi) <= 0:
        raise RuntimeError("generated triads must stay positive")
    state = np.concatenate([kx, kphi, ex, ephi])

    def split(z: np.ndarray):
        return z[:n], z[n : 2 * n], z[2 * n : 3 * n], z[3 * n :]

    def hamiltonian(z: np.ndarray, lapse: np.ndarray):
        kx_v, kp_v, ex_v, ep_v = split(z)
        gamma = -(derivative @ ex_v) / (2 * ep_v)
        gamma_prime = derivative @ gamma
        density = (
            ep_v / np.sqrt(ex_v) * f1(kp_v, delta)
            + 2 * np.sqrt(ex_v) * f2(kp_v, delta) * kx_v
            + ep_v / np.sqrt(ex_v) * (1 - gamma**2)
            + 2 * np.sqrt(ex_v) * gamma_prime
        )
        return -0.5 * dx * np.sum(lapse * density)

    def diffeomorphism(z: np.ndarray, shift: np.ndarray):
        kx_v, kp_v, ex_v, ep_v = split(z)
        density = -0.5 * (derivative @ ex_v) * kx_v + (derivative @ kp_v) * ep_v
        return dx * np.sum(shift * density)

    grad_1 = _complex_step_gradient(lambda z: hamiltonian(z, lapse_1), state)
    grad_2 = _complex_step_gradient(lambda z: hamiltonian(z, lapse_2), state)
    g1_kx, g1_kp, g1_ex, g1_ep = split(grad_1)
    g2_kx, g2_kp, g2_ex, g2_ep = split(grad_2)

    bracket = (1 / dx) * np.sum(g1_kx * g2_ex - g1_ex * g2_kx)
    bracket += (1 / (2 * dx)) * np.sum(g1_kp * g2_ep - g1_ep * g2_kp)

    kx_v, kp_v, ex_v, ep_v = split(state)
    shift = (
        beta(kp_v, delta)
        * ex_v
        / ep_v**2
        * (lapse_1 * (derivative @ lapse_2) - lapse_2 * (derivative @ lapse_1))
    )
    expected = 0.5 * diffeomorphism(state, shift)
    residual = float(abs(bracket - expected))
    relative = residual / max(1e-30, float(abs(expected)))
    return ClosureTrial(
        grid_size=n,
        seed=seed,
        delta=float(delta),
        bracket=float(np.real(bracket)),
        expected_closed_bracket=float(np.real(expected)),
        absolute_residual=residual,
        relative_residual=relative,
    )


def closure_convergence(grid_sizes=(16, 24, 32), seeds=(1, 2, 3), delta: float = 0.3):
    return [
        continuum_closure_trial(grid_size=n, delta=delta, seed=seed)
        for n in grid_sizes
        for seed in seeds
    ]
