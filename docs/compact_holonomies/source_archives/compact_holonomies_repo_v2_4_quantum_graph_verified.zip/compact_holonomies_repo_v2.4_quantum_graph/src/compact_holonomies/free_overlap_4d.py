"""Free four-dimensional overlap fermion in momentum space.

This module supplies a direct four-dimensional certificate for exact lattice
chirality and removal of Wilson doublers.  It is still a free-fermion result;
interacting chiral gauge theories require additional locality and anomaly
analysis.
"""
from __future__ import annotations

from typing import Any

import numpy as np

_S1 = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
_S2 = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex)
_S3 = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
_I2 = np.eye(2, dtype=complex)
_I4 = np.eye(4, dtype=complex)

_GAMMAS = (
    np.kron(_S1, _S1),
    np.kron(_S1, _S2),
    np.kron(_S1, _S3),
    np.kron(_S2, _I2),
)
_GAMMA5 = np.kron(_S3, _I2)


def euclidean_gamma_certificate() -> dict[str, float | bool]:
    max_hermiticity = max(float(np.max(np.abs(g - g.conj().T))) for g in _GAMMAS)
    max_clifford = 0.0
    for mu, gmu in enumerate(_GAMMAS):
        for nu, gnu in enumerate(_GAMMAS):
            target = 2.0 * _I4 if mu == nu else np.zeros((4, 4), dtype=complex)
            max_clifford = max(max_clifford, float(np.max(np.abs(gmu @ gnu + gnu @ gmu - target))))
    gamma5_square = float(np.max(np.abs(_GAMMA5 @ _GAMMA5 - _I4)))
    gamma5_anticommutation = max(
        float(np.max(np.abs(_GAMMA5 @ gamma + gamma @ _GAMMA5))) for gamma in _GAMMAS
    )
    return {
        "max_gamma_hermiticity_error": max_hermiticity,
        "max_clifford_error": max_clifford,
        "gamma5_square_error": gamma5_square,
        "gamma5_anticommutation_error": gamma5_anticommutation,
        "pass": bool(max(max_hermiticity, max_clifford, gamma5_square, gamma5_anticommutation) < 1e-14),
    }


def free_overlap_block(
    momentum: np.ndarray | tuple[float, float, float, float],
    rho: float = 1.0,
    lattice_spacing: float = 1.0,
    wilson_parameter: float = 1.0,
) -> np.ndarray:
    """Return the 4x4 massless overlap operator D_ov(p)."""
    p = np.asarray(momentum, dtype=float)
    if p.shape != (4,):
        raise ValueError("momentum must contain four components")
    if lattice_spacing <= 0 or wilson_parameter <= 0:
        raise ValueError("lattice_spacing and wilson_parameter must be positive")
    if not 0.0 < rho < 2.0 * wilson_parameter:
        raise ValueError("rho must satisfy 0 < rho < 2*r")
    a = float(lattice_spacing)
    r = float(wilson_parameter)
    dimensionless = a * p
    sine = np.sin(dimensionless)
    wilson_mass = r * float(np.sum(1.0 - np.cos(dimensionless))) - rho
    a_kernel = wilson_mass * _I4
    for component, gamma in zip(sine, _GAMMAS):
        a_kernel = a_kernel + 1j * component * gamma
    norm = float(np.sqrt(np.sum(sine**2) + wilson_mass**2))
    if norm == 0:
        raise RuntimeError("overlap kernel is singular")
    return (rho / a) * (_I4 + a_kernel / norm)


def ginsparg_wilson_block_error(operator: np.ndarray, rho: float = 1.0, lattice_spacing: float = 1.0) -> float:
    residual = (
        _GAMMA5 @ operator
        + operator @ _GAMMA5
        - (lattice_spacing / rho) * operator @ _GAMMA5 @ operator
    )
    return float(np.max(np.abs(residual)))


def brillouin_corner_spectrum(
    rho: float = 1.0,
    lattice_spacing: float = 1.0,
    wilson_parameter: float = 1.0,
) -> list[dict[str, Any]]:
    """Evaluate all 16 corners p_mu in {0,pi/a}."""
    import itertools

    corners = []
    for bits in itertools.product((0, 1), repeat=4):
        momentum = np.array(bits, dtype=float) * np.pi / lattice_spacing
        operator = free_overlap_block(momentum, rho, lattice_spacing, wilson_parameter)
        singular_values = np.linalg.svd(operator, compute_uv=False)
        corners.append({
            "corner": bits,
            "pi_component_count": int(sum(bits)),
            "minimum_singular_value": float(np.min(singular_values)),
            "maximum_singular_value": float(np.max(singular_values)),
        })
    return corners


def continuum_convergence(epsilons: tuple[float, ...] = (0.2, 0.1, 0.05, 0.025)) -> dict[str, Any]:
    """Verify D_ov(p)=i gamma.p+O(|p|^2) along a generic direction."""
    direction = np.array([1.0, 2.0, -1.0, 0.5])
    direction /= np.linalg.norm(direction)
    errors = []
    for epsilon in epsilons:
        p = epsilon * direction
        operator = free_overlap_block(p)
        continuum = sum(1j * p_mu * gamma for p_mu, gamma in zip(p, _GAMMAS))
        errors.append(float(np.linalg.norm(operator - continuum, ord=2)))
    slopes = [
        float(np.log(errors[i] / errors[i + 1]) / np.log(epsilons[i] / epsilons[i + 1]))
        for i in range(len(errors) - 1)
    ]
    return {
        "epsilons": list(epsilons),
        "operator_norm_errors": errors,
        "observed_orders": slopes,
        "minimum_observed_order": min(slopes),
        "pass": bool(min(slopes) > 1.9),
    }


# Backward-compatible alias for the spelling used in the first v2.1 draft.
brilluoin_corner_spectrum = brillouin_corner_spectrum

def free_overlap_4d_certificate() -> dict[str, Any]:
    gamma = euclidean_gamma_certificate()
    generic_momentum = np.array([0.37, -0.51, 0.22, 0.61])
    operator = free_overlap_block(generic_momentum)
    gw_error = ginsparg_wilson_block_error(operator)
    gamma5_hermiticity_error = float(np.max(np.abs(operator.conj().T - _GAMMA5 @ operator @ _GAMMA5)))
    corners = brillouin_corner_spectrum()
    zero_corner = next(item for item in corners if item["pi_component_count"] == 0)
    doubler_corners = [item for item in corners if item["pi_component_count"] > 0]
    physical_zero_error = zero_corner["maximum_singular_value"]
    minimum_doubler_gap = min(item["minimum_singular_value"] for item in doubler_corners)
    convergence = continuum_convergence()
    passed = bool(
        gamma["pass"]
        and gw_error < 1e-12
        and gamma5_hermiticity_error < 1e-12
        and physical_zero_error < 1e-12
        and minimum_doubler_gap > 1.9
        and convergence["pass"]
    )
    return {
        "gamma_algebra": gamma,
        "generic_momentum": generic_momentum.tolist(),
        "ginsparg_wilson_error": gw_error,
        "gamma5_hermiticity_error": gamma5_hermiticity_error,
        "physical_zero_corner_error": physical_zero_error,
        "minimum_doubler_corner_gap": minimum_doubler_gap,
        "corner_spectrum": corners,
        "continuum_convergence": convergence,
        "pass": passed,
        "scope": (
            "Free four-dimensional overlap fermion. It proves exact lattice chirality and removal "
            "of free Wilson doublers for 0<rho<2r, not a complete interacting chiral gauge theory."
        ),
    }
