"""Symbolic anomaly cancellation for one chiral Standard-Model generation.

The derivation starts from a fixed representation *pattern*

    Q  : (3,2),  u^c : (3bar,1), d^c : (3bar,1),
    L  : (1,2),  e^c : (1,1), H : (1,2),

and solves only for U(1) hypercharges.  Thus it does not derive the gauge group
or representation pattern.  Under Yukawa invariance and cancellation of the
local gauge and mixed gravitational anomalies, the model without a right-
handed neutrino fixes all hypercharge ratios up to an overall normalization.
With a right-handed neutrino, an additional anomaly-free B-L direction remains.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import sympy as sp


@dataclass(frozen=True)
class HyperchargeSolution:
    q: sp.Expr
    u_conjugate: sp.Expr
    d_conjugate: sp.Expr
    lepton_doublet: sp.Expr
    e_conjugate: sp.Expr
    higgs: sp.Expr
    nu_conjugate: sp.Expr | None = None

    def as_dict(self) -> dict[str, str | None]:
        return {key: None if value is None else str(sp.simplify(value)) for key, value in asdict(self).items()}


def anomaly_polynomials(solution: HyperchargeSolution) -> dict[str, sp.Expr]:
    """Return local anomaly coefficients in a left-handed Weyl convention."""
    yq = solution.q
    yu = solution.u_conjugate
    yd = solution.d_conjugate
    yl = solution.lepton_doublet
    ye = solution.e_conjugate
    yn = solution.nu_conjugate if solution.nu_conjugate is not None else sp.Integer(0)
    return {
        "SU3^2_U1": sp.simplify(2 * yq + yu + yd),
        "SU2^2_U1": sp.simplify(3 * yq + yl),
        "gravity^2_U1": sp.simplify(6 * yq + 3 * yu + 3 * yd + 2 * yl + ye + (yn if solution.nu_conjugate is not None else 0)),
        "U1^3": sp.simplify(6 * yq**3 + 3 * yu**3 + 3 * yd**3 + 2 * yl**3 + ye**3 + (yn**3 if solution.nu_conjugate is not None else 0)),
    }


def yukawa_residuals(solution: HyperchargeSolution) -> dict[str, sp.Expr]:
    """Hypercharge sums of the allowed one-Higgs Yukawa interactions."""
    yq = solution.q
    yu = solution.u_conjugate
    yd = solution.d_conjugate
    yl = solution.lepton_doublet
    ye = solution.e_conjugate
    yh = solution.higgs
    residuals = {
        "Q_H_uc": sp.simplify(yq + yh + yu),
        "Q_Hdag_dc": sp.simplify(yq - yh + yd),
        "L_Hdag_ec": sp.simplify(yl - yh + ye),
    }
    if solution.nu_conjugate is not None:
        residuals["L_H_nuc"] = sp.simplify(yl + yh + solution.nu_conjugate)
    return residuals


def minimal_hypercharge_solution(normalization: sp.Expr = sp.Rational(1, 2)) -> HyperchargeSolution:
    """Unique ratios without nu^c, normalized by Y_H=normalization."""
    yh = sp.sympify(normalization)
    yq = yh / 3
    return HyperchargeSolution(
        q=yq,
        u_conjugate=-yq - yh,
        d_conjugate=-yq + yh,
        lepton_doublet=-3 * yq,
        e_conjugate=3 * yq + yh,
        higgs=yh,
    )


def right_neutrino_family(q_parameter: sp.Expr, higgs_parameter: sp.Expr) -> HyperchargeSolution:
    """Two-parameter anomaly-free family when a right-handed neutrino is included."""
    yq = sp.sympify(q_parameter)
    yh = sp.sympify(higgs_parameter)
    yl = -3 * yq
    return HyperchargeSolution(
        q=yq,
        u_conjugate=-yq - yh,
        d_conjugate=-yq + yh,
        lepton_doublet=yl,
        e_conjugate=-yl + yh,
        nu_conjugate=-yl - yh,
        higgs=yh,
    )


def electric_charges(solution: HyperchargeSolution) -> dict[str, sp.Expr]:
    """Electric charges Q_em=T3+Y for physical (non-conjugate) fields."""
    yq, yl, yh = solution.q, solution.lepton_doublet, solution.higgs
    # u^c,d^c,e^c are left-handed charge conjugates, hence physical RH charges are minus Y.
    charges = {
        "u_L": sp.simplify(sp.Rational(1, 2) + yq),
        "d_L": sp.simplify(-sp.Rational(1, 2) + yq),
        "u_R": sp.simplify(-solution.u_conjugate),
        "d_R": sp.simplify(-solution.d_conjugate),
        "nu_L": sp.simplify(sp.Rational(1, 2) + yl),
        "e_L": sp.simplify(-sp.Rational(1, 2) + yl),
        "e_R": sp.simplify(-solution.e_conjugate),
        "H_plus": sp.simplify(sp.Rational(1, 2) + yh),
        "H_zero": sp.simplify(-sp.Rational(1, 2) + yh),
    }
    if solution.nu_conjugate is not None:
        charges["nu_R"] = sp.simplify(-solution.nu_conjugate)
    return charges


def symbolic_hypercharge_certificate() -> dict[str, Any]:
    """Prove uniqueness without nu^c and underdetermination with nu^c."""
    q, h = sp.symbols("q h", real=True)
    no_nu = minimal_hypercharge_solution(h)
    no_nu_anomalies = anomaly_polynomials(no_nu)
    no_nu_yukawa = yukawa_residuals(no_nu)

    # The mixed gravitational anomaly before solving fixes h=3q.
    generic_no_nu = HyperchargeSolution(
        q=q,
        u_conjugate=-q - h,
        d_conjugate=-q + h,
        lepton_doublet=-3 * q,
        e_conjugate=3 * q + h,
        higgs=h,
    )
    generic_anomalies = anomaly_polynomials(generic_no_nu)
    gravitational_factor = sp.factor(generic_anomalies["gravity^2_U1"])
    cubic_after_gravity = sp.factor(generic_anomalies["U1^3"].subs(h, 3 * q))

    with_nu = right_neutrino_family(q, h)
    with_nu_anomalies = anomaly_polynomials(with_nu)
    with_nu_yukawa = yukawa_residuals(with_nu)

    standard = minimal_hypercharge_solution(sp.Rational(1, 2))
    standard_charges = electric_charges(standard)
    expected = {
        "u_L": sp.Rational(2, 3), "d_L": sp.Rational(-1, 3),
        "u_R": sp.Rational(2, 3), "d_R": sp.Rational(-1, 3),
        "nu_L": 0, "e_L": -1, "e_R": -1,
        "H_plus": 1, "H_zero": 0,
    }
    charge_match = all(sp.simplify(standard_charges[key] - value) == 0 for key, value in expected.items())

    return {
        "minimal_without_right_neutrino": {
            "generic_gravitational_anomaly": str(gravitational_factor),
            "condition": "h=3*q",
            "cubic_anomaly_after_condition": str(cubic_after_gravity),
            "normalized_solution_YH_half": standard.as_dict(),
            "electric_charges": {key: str(value) for key, value in standard_charges.items()},
            "all_anomalies_zero": all(value == 0 for value in no_nu_anomalies.values()),
            "all_yukawa_residuals_zero": all(value == 0 for value in no_nu_yukawa.values()),
            "charge_match": charge_match,
            "witten_SU2_doublet_count": 4,
            "witten_global_anomaly_cancelled": True,
            "uniqueness": "unique hypercharge ratios up to overall U(1) normalization, given the assumed representations and Yukawa terms",
        },
        "with_right_neutrino": {
            "solution_family": with_nu.as_dict(),
            "all_anomalies_identically_zero": all(value == 0 for value in with_nu_anomalies.values()),
            "all_yukawa_residuals_identically_zero": all(value == 0 for value in with_nu_yukawa.values()),
            "remaining_freedom": "two parameters before normalization; equivalently a hypercharge/B-L mixing direction remains",
        },
        "pass": bool(
            gravitational_factor == h - 3 * q
            and cubic_after_gravity == 0
            and all(value == 0 for value in no_nu_anomalies.values())
            and all(value == 0 for value in no_nu_yukawa.values())
            and all(value == 0 for value in with_nu_anomalies.values())
            and all(value == 0 for value in with_nu_yukawa.values())
            and charge_match
        ),
        "scope": (
            "Derives U(1) hypercharge ratios from anomaly cancellation only after the SU(3)xSU(2) "
            "representation pattern and Yukawa structure have been assumed."
        ),
    }
