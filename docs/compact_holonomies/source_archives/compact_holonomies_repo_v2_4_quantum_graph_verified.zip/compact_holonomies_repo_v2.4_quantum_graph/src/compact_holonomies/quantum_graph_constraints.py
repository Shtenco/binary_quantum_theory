"""Exact local constraints on a finite multi-edge compact quantum graph.

This module is the first multi-vertex quantum layer in the project.  It uses a
finite Z_N gauge laboratory on an oriented cycle because the complete Hilbert
space, local Gauss transformations, physical projector, master constraint and
Hamiltonian can all be represented exactly as finite matrices.

The construction tests the architecture needed by a constrained quantum
geometry—local constraints, a nonempty physical subspace and dynamics that
preserves it.  It is not yet a gravitational SU(2) spin network and contains no
diffeomorphism or Hamiltonian-constraint algebra of 3+1 general relativity.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache
from typing import Any, Iterable

import numpy as np
from scipy.linalg import eigh

from .quantum_holonomy_dynamics import clock_shift_operators


Array = np.ndarray


def _frob(matrix: Array) -> float:
    return float(np.linalg.norm(matrix, ord="fro"))


def _embed(local_operator: Array, edge: int, edge_count: int, local_dimension: int) -> Array:
    factors: list[Array] = []
    for position in range(edge_count):
        factors.append(local_operator if position == edge else np.eye(local_dimension, dtype=complex))
    result = factors[0]
    for factor in factors[1:]:
        result = np.kron(result, factor)
    return result


@lru_cache(maxsize=None)
def cycle_graph_operators(local_dimension: int = 3, edge_count: int = 4) -> dict[str, Any]:
    """Construct edge Weyl operators, vertex Gauss transformations and Wilson loop."""
    n = int(local_dimension)
    edges = int(edge_count)
    if n < 2:
        raise ValueError("local_dimension must be at least 2")
    if edges < 3:
        raise ValueError("edge_count must be at least 3")
    clock, shift, omega = clock_shift_operators(n)
    clocks = [_embed(clock, edge, edges, n) for edge in range(edges)]
    shifts = [_embed(shift, edge, edges, n) for edge in range(edges)]

    # Edge e is oriented from vertex e to vertex e+1.  The local gauge
    # transformation at v acts with X on the outgoing edge and X^dagger on
    # the incoming edge.  The phases cancel in the Wilson loop.
    gauss = [
        shifts[vertex] @ shifts[(vertex - 1) % edges].conj().T
        for vertex in range(edges)
    ]
    wilson = np.eye(n**edges, dtype=complex)
    for clock_edge in clocks:
        wilson = wilson @ clock_edge
    return {
        "clock_edges": clocks,
        "shift_edges": shifts,
        "gauss_operators": gauss,
        "wilson_loop": wilson,
        "omega": omega,
        "hilbert_dimension": n**edges,
    }


def local_gauss_projector(gauss_operator: Array, local_dimension: int) -> Array:
    """Project onto the eigenvalue-one sector of one finite gauge transformation."""
    identity = np.eye(gauss_operator.shape[0], dtype=complex)
    projector = np.zeros_like(identity)
    power = identity.copy()
    for _ in range(int(local_dimension)):
        projector = projector + power
        power = power @ gauss_operator
    projector = projector / local_dimension
    return 0.5 * (projector + projector.conj().T)


@lru_cache(maxsize=None)
def physical_gauss_projector(local_dimension: int = 3, edge_count: int = 4) -> Array:
    """Return the joint projector onto all local Gauss constraints."""
    operators = cycle_graph_operators(local_dimension, edge_count)
    dimension = operators["hilbert_dimension"]
    projector = np.eye(dimension, dtype=complex)
    for gauss_operator in operators["gauss_operators"]:
        projector = projector @ local_gauss_projector(gauss_operator, local_dimension)
    return 0.5 * (projector + projector.conj().T)


@lru_cache(maxsize=None)
def master_constraint(local_dimension: int = 3, edge_count: int = 4) -> Array:
    """Positive master constraint whose kernel is the gauge-invariant sector."""
    operators = cycle_graph_operators(local_dimension, edge_count)
    identity = np.eye(operators["hilbert_dimension"], dtype=complex)
    master = np.zeros_like(identity)
    for gauss_operator in operators["gauss_operators"]:
        master = master + 2.0 * identity - gauss_operator - gauss_operator.conj().T
    return 0.5 * (master + master.conj().T)


@lru_cache(maxsize=None)
def gauge_invariant_hamiltonian(
    local_dimension: int = 3,
    edge_count: int = 4,
    electric_coupling: float = 0.7,
    magnetic_coupling: float = 1.1,
) -> Array:
    """Finite Kogut--Susskind-type Hamiltonian on the cycle graph."""
    if electric_coupling < 0 or magnetic_coupling < 0:
        raise ValueError("couplings must be non-negative")
    operators = cycle_graph_operators(local_dimension, edge_count)
    identity = np.eye(operators["hilbert_dimension"], dtype=complex)
    electric = np.zeros_like(identity)
    for shift_edge in operators["shift_edges"]:
        electric = electric + 2.0 * identity - shift_edge - shift_edge.conj().T
    wilson = operators["wilson_loop"]
    magnetic = 2.0 * identity - wilson - wilson.conj().T
    hamiltonian = electric_coupling * electric + magnetic_coupling * magnetic
    return 0.5 * (hamiltonian + hamiltonian.conj().T)


@dataclass(frozen=True)
class GraphGaussCertificate:
    local_dimension: int
    edge_count: int
    hilbert_dimension: int
    physical_dimension: int
    expected_physical_dimension: int
    maximum_gauss_unitarity_error: float
    maximum_gauss_period_error: float
    maximum_gauss_commutator_error: float
    maximum_wilson_gauge_commutator_error: float
    projector_hermiticity_error: float
    projector_idempotence_error: float
    maximum_projected_constraint_error: float
    passed: bool
    verdict: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@lru_cache(maxsize=None)
def graph_gauss_certificate(local_dimension: int = 3, edge_count: int = 4) -> GraphGaussCertificate:
    """Verify exact local gauge constraints and the joint physical projector."""
    operators = cycle_graph_operators(local_dimension, edge_count)
    gauss = operators["gauss_operators"]
    wilson = operators["wilson_loop"]
    dimension = operators["hilbert_dimension"]
    identity = np.eye(dimension, dtype=complex)
    projector = physical_gauss_projector(local_dimension, edge_count)

    unitarity = [_frob(g.conj().T @ g - identity) for g in gauss]
    periods = [_frob(np.linalg.matrix_power(g, local_dimension) - identity) for g in gauss]
    commutators = [
        _frob(gauss[i] @ gauss[j] - gauss[j] @ gauss[i])
        for i in range(edge_count)
        for j in range(i + 1, edge_count)
    ]
    wilson_commutators = [_frob(g @ wilson - wilson @ g) for g in gauss]
    projected_errors = [_frob(g @ projector - projector) for g in gauss]
    # For a Hermitian idempotent projector, rank equals its trace.  This avoids
    # an unnecessary dense eigendecomposition in refinement sweeps.
    physical_dimension = int(round(float(np.trace(projector).real)))
    expected_physical_dimension = int(local_dimension)  # one independent cycle holonomy
    hermiticity = _frob(projector - projector.conj().T)
    idempotence = _frob(projector @ projector - projector)

    max_or_zero = lambda values: max(values, default=0.0)
    passed = bool(
        physical_dimension == expected_physical_dimension
        and max_or_zero(unitarity) < 1e-12
        and max_or_zero(periods) < 1e-11
        and max_or_zero(commutators) < 1e-12
        and max_or_zero(wilson_commutators) < 1e-11
        and hermiticity < 1e-11
        and idempotence < 1e-10
        and max_or_zero(projected_errors) < 1e-10
    )
    return GraphGaussCertificate(
        local_dimension=int(local_dimension),
        edge_count=int(edge_count),
        hilbert_dimension=int(dimension),
        physical_dimension=physical_dimension,
        expected_physical_dimension=expected_physical_dimension,
        maximum_gauss_unitarity_error=max_or_zero(unitarity),
        maximum_gauss_period_error=max_or_zero(periods),
        maximum_gauss_commutator_error=max_or_zero(commutators),
        maximum_wilson_gauge_commutator_error=max_or_zero(wilson_commutators),
        projector_hermiticity_error=hermiticity,
        projector_idempotence_error=idempotence,
        maximum_projected_constraint_error=max_or_zero(projected_errors),
        passed=passed,
        verdict=(
            "The finite cycle graph has exact local Gauss transformations and "
            "a nonempty joint physical subspace. Its dimension is N, the one "
            "independent loop-holonomy degree of freedom after gauge reduction."
        ),
    )


@dataclass(frozen=True)
class MasterConstraintCertificate:
    local_dimension: int
    edge_count: int
    minimum_master_eigenvalue: float
    master_kernel_dimension: int
    physical_projector_dimension: int
    master_projector_residual: float
    hamiltonian_hermiticity_error: float
    hamiltonian_master_commutator_error: float
    hamiltonian_projector_commutator_error: float
    maximum_physical_leakage: float
    maximum_norm_error: float
    passed: bool
    verdict: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@lru_cache(maxsize=None)
def master_constraint_certificate(
    local_dimension: int = 3,
    edge_count: int = 4,
    relational_times: Iterable[float] = (0.0, 0.29, 0.83, 1.7),
) -> MasterConstraintCertificate:
    """Verify positive master constraint and physical-subspace-preserving dynamics."""
    projector = physical_gauss_projector(local_dimension, edge_count)
    master = master_constraint(local_dimension, edge_count)
    hamiltonian = gauge_invariant_hamiltonian(local_dimension, edge_count)
    dimension = projector.shape[0]
    identity = np.eye(dimension, dtype=complex)

    master_eigenvalues = np.linalg.eigvalsh(master)
    minimum_master = float(np.min(master_eigenvalues))
    kernel_dimension = int(np.sum(np.abs(master_eigenvalues) < 1e-9))
    projector_dimension = int(round(float(np.trace(projector).real)))
    master_projector = _frob(master @ projector)
    h_hermiticity = _frob(hamiltonian - hamiltonian.conj().T)
    hm_commutator = _frob(hamiltonian @ master - master @ hamiltonian)
    hp_commutator = _frob(hamiltonian @ projector - projector @ hamiltonian)

    rng = np.random.default_rng(20260717)
    raw = rng.normal(size=dimension) + 1j * rng.normal(size=dimension)
    physical = projector @ raw
    physical = physical / np.linalg.norm(physical)
    eigenvalues, eigenvectors = eigh(hamiltonian)
    leakages: list[float] = []
    norm_errors: list[float] = []
    for time in relational_times:
        phases = np.exp(-1j * eigenvalues * float(time))
        evolution = (eigenvectors * phases) @ eigenvectors.conj().T
        evolved = evolution @ physical
        leakages.append(float(np.linalg.norm((identity - projector) @ evolved)))
        norm_errors.append(float(abs(np.vdot(evolved, evolved).real - 1.0)))

    max_leakage = max(leakages, default=0.0)
    max_norm = max(norm_errors, default=0.0)
    passed = bool(
        minimum_master >= -1e-10
        and kernel_dimension == projector_dimension == local_dimension
        and master_projector < 1e-9
        and h_hermiticity < 1e-12
        and hm_commutator < 1e-9
        and hp_commutator < 1e-9
        and max_leakage < 1e-10
        and max_norm < 1e-12
    )
    return MasterConstraintCertificate(
        local_dimension=int(local_dimension),
        edge_count=int(edge_count),
        minimum_master_eigenvalue=minimum_master,
        master_kernel_dimension=kernel_dimension,
        physical_projector_dimension=projector_dimension,
        master_projector_residual=master_projector,
        hamiltonian_hermiticity_error=h_hermiticity,
        hamiltonian_master_commutator_error=hm_commutator,
        hamiltonian_projector_commutator_error=hp_commutator,
        maximum_physical_leakage=max_leakage,
        maximum_norm_error=max_norm,
        passed=passed,
        verdict=(
            "The positive master constraint has the same kernel as the joint "
            "Gauss projector, and the registered Hamiltonian commutes with both. "
            "Unitary evolution therefore preserves the physical subspace."
        ),
    )


def cycle_refinement_certificate(
    local_dimension: int = 3,
    edge_counts: tuple[int, ...] = (3, 4, 5),
) -> dict[str, Any]:
    """Check gauge-reduced physical dimension under subdivision of one loop."""
    trials = [graph_gauss_certificate(local_dimension, edges).as_dict() for edges in edge_counts]
    dimensions = [trial["physical_dimension"] for trial in trials]
    pass_flag = bool(all(trial["passed"] for trial in trials) and dimensions == [local_dimension] * len(trials))
    return {
        "local_dimension": int(local_dimension),
        "edge_counts": [int(value) for value in edge_counts],
        "trials": trials,
        "physical_dimensions": dimensions,
        "pass": pass_flag,
        "verdict": (
            "Subdividing the same single cycle from three to five edges leaves "
            "the gauge-reduced physical dimension equal to N. This is an exact "
            "topological refinement check for the constrained graph kinematics, "
            "not a continuum test of gravitational dynamics."
        ),
    }


def quantum_graph_suite() -> dict[str, Any]:
    gauss = graph_gauss_certificate().as_dict()
    dynamics = master_constraint_certificate().as_dict()
    refinement = cycle_refinement_certificate()
    return {
        "A37_local_gauss_graph": gauss,
        "A38_master_constraint_dynamics": dynamics,
        "A39_cycle_refinement": refinement,
        "pass": bool(gauss["passed"] and dynamics["passed"] and refinement["pass"]),
        "scope": (
            "finite Z_N cycle gauge graph with local constraints; multi-vertex "
            "quantum architecture, not an SU(2) 3+1 gravitational spin network"
        ),
    }
