"""Compact holonomies research utilities.

Exact identities, controlled EFT assumptions, anomaly-free reduced dynamics,
and prediction audits are kept separate by design.
"""

from .effective_foam_eft import (
    EFTParameters,
    HolonomyCorrection,
    barrier_action,
    tunneling_amplitude,
    tunneling_probability,
    foam_corrected_barrier,
    phase_decoherence_factor,
    planck_suppression,
)
from .anomaly_free_spherical import (
    beta,
    canonical_holonomy_chart,
    closure_convergence,
    continuum_closure_trial,
    f1,
    f2,
    signature_change_threshold,
    symbolic_certificate,
)
from .micro_spectrum import (
    analytic_eigenvalues,
    compact_laplacian,
    run_blind_spectrum_test,
    universal_series_ratio,
)

__all__ = [
    "EFTParameters",
    "HolonomyCorrection",
    "barrier_action",
    "tunneling_amplitude",
    "tunneling_probability",
    "foam_corrected_barrier",
    "phase_decoherence_factor",
    "planck_suppression",
    "f1",
    "f2",
    "beta",
    "signature_change_threshold",
    "canonical_holonomy_chart",
    "symbolic_certificate",
    "continuum_closure_trial",
    "closure_convergence",
    "compact_laplacian",
    "analytic_eigenvalues",
    "run_blind_spectrum_test",
    "universal_series_ratio",
]

from .chiral_overlap import (
    chiral_certificate,
    chiral_flux_suite,
    overlap_dirac_operator,
    overlap_index,
    uniform_u1_flux_links,
)
from .anomaly_free_matter import (
    minimal_hypercharge_solution,
    right_neutrino_family,
    symbolic_hypercharge_certificate,
)
from .renormalization_group import (
    rg_certificate,
    standard_model_one_loop_beta_coefficients,
)
from .free_overlap_4d import free_overlap_4d_certificate, free_overlap_block

__all__.extend([
    "chiral_certificate",
    "chiral_flux_suite",
    "overlap_dirac_operator",
    "overlap_index",
    "uniform_u1_flux_links",
    "minimal_hypercharge_solution",
    "right_neutrino_family",
    "symbolic_hypercharge_certificate",
    "rg_certificate",
    "standard_model_one_loop_beta_coefficients",
    "free_overlap_4d_certificate",
    "free_overlap_block",
])

from .topological_generations import generation_certificate, three_generation_suite
from .unification_stress import (
    CouplingBenchmark,
    fermion_trace_normalizations,
    minimal_unification_stress_certificate,
    spectral_coupling_certificate,
)
from .generation_selection import generation_selection_certificate
from .flavor_no_go import constant_higgs_flavor_certificate

__all__.extend([
    "generation_certificate",
    "three_generation_suite",
    "CouplingBenchmark",
    "fermion_trace_normalizations",
    "minimal_unification_stress_certificate",
    "spectral_coupling_certificate",
    "generation_selection_certificate",
    "constant_higgs_flavor_certificate",
])

from .quantum_holonomy_dynamics import (
    analytic_holonomy_spectrum,
    clock_shift_operators,
    continuum_limit_certificate,
    holonomy_laplacian,
    quantum_constraint_certificate,
    quantum_dynamics_suite,
    weyl_kinematics_certificate,
)
from .flux_sector_selection import flux_selection_no_go_certificate, uniform_flux_action

__all__.extend([
    "clock_shift_operators",
    "weyl_kinematics_certificate",
    "holonomy_laplacian",
    "analytic_holonomy_spectrum",
    "quantum_constraint_certificate",
    "continuum_limit_certificate",
    "quantum_dynamics_suite",
    "uniform_flux_action",
    "flux_selection_no_go_certificate",
])

from .quantum_graph_constraints import (
    cycle_graph_operators,
    cycle_refinement_certificate,
    gauge_invariant_hamiltonian,
    graph_gauss_certificate,
    master_constraint,
    master_constraint_certificate,
    physical_gauss_projector,
    quantum_graph_suite,
)

__all__.extend([
    "cycle_graph_operators",
    "physical_gauss_projector",
    "master_constraint",
    "gauge_invariant_hamiltonian",
    "graph_gauss_certificate",
    "master_constraint_certificate",
    "cycle_refinement_certificate",
    "quantum_graph_suite",
])
