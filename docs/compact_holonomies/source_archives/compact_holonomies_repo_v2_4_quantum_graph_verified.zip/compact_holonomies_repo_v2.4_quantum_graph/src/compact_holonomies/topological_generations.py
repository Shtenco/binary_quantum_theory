"""Conditional family multiplicity from a compact topological index.

This module does *not* derive why Nature chooses three generations.  It proves a
more limited statement: in the controlled two-dimensional compact U(1) overlap
sector already used by :mod:`compact_holonomies.chiral_overlap`, a flux sector
with integer charge Q contains exactly |Q| chiral zero modes.  Therefore Q=3
produces three same-chirality modes without assigning three independent fields
by hand.  The remaining open problem is a dynamical selection principle for
Q=3 and a derivation of the four-dimensional Standard-Model representation
content.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from .chiral_overlap import overlap_dirac_operator, overlap_index, uniform_u1_flux_links


@dataclass(frozen=True)
class GenerationCertificate:
    lattice_size: int
    topological_charge: int
    zero_mode_count: int
    positive_chirality_modes: int
    negative_chirality_modes: int
    projected_chiralities: tuple[float, ...]
    overlap_index: float
    expected_index: int
    largest_zero_singular_value: float
    first_nonzero_singular_value: float
    orthonormality_error: float
    chirality_integrality_error: float
    passed: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def generation_certificate(
    lattice_size: int,
    topological_charge: int = 3,
    zero_tolerance: float = 1e-10,
) -> GenerationCertificate:
    """Count exact overlap zero modes and their chirality in one flux sector."""
    if topological_charge == 0:
        expected_zero_modes = 0
    else:
        expected_zero_modes = abs(int(topological_charge))
    result = overlap_dirac_operator(
        uniform_u1_flux_links(lattice_size, topological_charge)
    )
    _, singular_values, vh = np.linalg.svd(result.operator, full_matrices=False)
    order = np.argsort(singular_values)
    singular_values = singular_values[order]
    vectors = vh.conj().T[:, order]
    zero_mask = singular_values < zero_tolerance
    zero_vectors = vectors[:, zero_mask]
    zero_count = int(zero_vectors.shape[1])

    if zero_count:
        projected_gamma5 = zero_vectors.conj().T @ result.gamma5 @ zero_vectors
        projected_gamma5 = 0.5 * (projected_gamma5 + projected_gamma5.conj().T)
        chiralities = np.linalg.eigvalsh(projected_gamma5).real
        positive = int(np.sum(chiralities > 0.5))
        negative = int(np.sum(chiralities < -0.5))
        chirality_error = float(np.max(np.abs(np.abs(chiralities) - 1.0)))
        orth_error = float(
            np.max(np.abs(zero_vectors.conj().T @ zero_vectors - np.eye(zero_count)))
        )
        largest_zero = float(np.max(singular_values[zero_mask]))
    else:
        chiralities = np.array([], dtype=float)
        positive = negative = 0
        chirality_error = 0.0
        orth_error = 0.0
        largest_zero = 0.0

    nonzero_values = singular_values[~zero_mask]
    first_nonzero = float(nonzero_values[0]) if len(nonzero_values) else float("inf")
    index = overlap_index(result)
    expected_index = -int(topological_charge)
    expected_positive = max(expected_index, 0)
    expected_negative = max(-expected_index, 0)
    passed = bool(
        zero_count == expected_zero_modes
        and positive == expected_positive
        and negative == expected_negative
        and abs(index - expected_index) < 1e-10
        and largest_zero < zero_tolerance
        and first_nonzero > 1e-6
        and orth_error < 1e-11
        and chirality_error < 1e-10
    )
    return GenerationCertificate(
        lattice_size=int(lattice_size),
        topological_charge=int(topological_charge),
        zero_mode_count=zero_count,
        positive_chirality_modes=positive,
        negative_chirality_modes=negative,
        projected_chiralities=tuple(float(x) for x in chiralities),
        overlap_index=float(index),
        expected_index=expected_index,
        largest_zero_singular_value=largest_zero,
        first_nonzero_singular_value=first_nonzero,
        orthonormality_error=orth_error,
        chirality_integrality_error=chirality_error,
        passed=passed,
    )


def three_generation_suite(
    lattice_sizes: tuple[int, ...] = (5, 6, 7),
) -> dict[str, Any]:
    """Verify both orientations of the Q=3 sector on unselected lattice sizes."""
    trials = [
        generation_certificate(L, Q).as_dict()
        for L in lattice_sizes
        for Q in (-3, 3)
    ]
    return {
        "trial_count": len(trials),
        "trials": trials,
        "max_zero_singular_value": max(t["largest_zero_singular_value"] for t in trials),
        "minimum_nonzero_singular_value": min(t["first_nonzero_singular_value"] for t in trials),
        "max_chirality_integrality_error": max(t["chirality_integrality_error"] for t in trials),
        "pass": all(t["passed"] for t in trials),
        "conditional_result": "Q=+/-3 gives exactly three same-chirality overlap zero modes",
        "open_problem": "the dynamics selecting |Q|=3 rather than another integer flux is not derived",
        "scope": "2D compact U(1) overlap test bed; not yet a 4D Standard-Model compactification",
    }
