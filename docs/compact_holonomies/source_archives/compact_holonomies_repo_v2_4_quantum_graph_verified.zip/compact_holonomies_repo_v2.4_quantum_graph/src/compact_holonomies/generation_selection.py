"""No-go audit for selecting exactly three generations from current constraints."""
from __future__ import annotations

from fractions import Fraction
from typing import Any

from .renormalization_group import standard_model_one_loop_beta_coefficients


def generation_selection_certificate(max_generations: int = 12) -> dict[str, Any]:
    if max_generations < 1:
        raise ValueError("max_generations must be positive")
    rows = []
    for ng in range(1, max_generations + 1):
        beta = standard_model_one_loop_beta_coefficients(generations=ng, higgs_doublets=1)
        local_anomalies_cancel = True  # one complete generation is anomaly-free
        witten_doublets = 4 * ng
        witten_cancelled = witten_doublets % 2 == 0
        su2_af = beta.b2 < 0
        su3_af = beta.b3 < 0
        rows.append({
            "generations": ng,
            "b1": str(beta.b1),
            "b2": str(beta.b2),
            "b3": str(beta.b3),
            "local_anomalies_cancel": local_anomalies_cancel,
            "witten_SU2_doublets": witten_doublets,
            "witten_anomaly_cancelled": witten_cancelled,
            "SU2_asymptotically_free": su2_af,
            "SU3_asymptotically_free": su3_af,
            "passes_current_structural_filters": bool(
                local_anomalies_cancel and witten_cancelled and su2_af and su3_af
            ),
        })
    allowed = [row["generations"] for row in rows if row["passes_current_structural_filters"]]
    return {
        "rows": rows,
        "allowed_positive_generation_counts": allowed,
        "three_is_allowed": 3 in allowed,
        "three_is_unique": allowed == [3],
        "pass": 3 in allowed and allowed != [3] and allowed == [1, 2, 3, 4, 5],
        "exact_bounds": {
            "SU2_asymptotic_freedom": "N_g < 43/8, hence N_g<=5 for one Higgs doublet",
            "SU3_asymptotic_freedom": "N_g < 33/4, hence N_g<=8",
        },
        "verdict": (
            "Anomaly cancellation, the Witten parity condition, and one-loop SU(2)/SU(3) "
            "asymptotic freedom do not select N_g=3. Together they allow N_g=1,...,5. "
            "The topological statement N_g=|Q| therefore still needs a dynamical principle selecting |Q|=3."
        ),
    }
