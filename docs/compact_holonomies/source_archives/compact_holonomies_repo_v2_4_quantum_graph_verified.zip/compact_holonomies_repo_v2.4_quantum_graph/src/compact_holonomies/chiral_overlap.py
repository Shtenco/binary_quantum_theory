"""Exact lattice chirality from compact U(1) link holonomies.

The module implements the two-dimensional Neuberger overlap Dirac operator
on a periodic square lattice.  It is a controlled finite-dimensional test bed,
not a derivation of four-dimensional Standard-Model fermions.

For Wilson parameter r=1 and 0 < rho < 2, define

    H_W = gamma5 (D_W - rho/a),
    D_ov = (rho/a) [1 + gamma5 sign(H_W)].

The operator obeys the Ginsparg-Wilson relation

    gamma5 D + D gamma5 = (a/rho) D gamma5 D,

and its index is

    index(D) = Tr gamma5 [1 - a D/(2 rho)].

For the uniform-flux link convention used here, index(D) = -Q.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
from scipy.linalg import eigh

_SIGMA_1 = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
_SIGMA_2 = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex)
_SIGMA_3 = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
_GAMMA = (_SIGMA_1, _SIGMA_2)
_GAMMA_5 = _SIGMA_3


def gamma5_matrix(lattice_size: int) -> np.ndarray:
    """Return gamma5 acting on spin and all lattice sites."""
    if lattice_size < 2:
        raise ValueError("lattice_size must be at least 2")
    return np.kron(np.eye(lattice_size * lattice_size), _GAMMA_5)


def uniform_u1_flux_links(lattice_size: int, topological_charge: int) -> np.ndarray:
    """Periodic U(1) links with uniform plaquette flux 2*pi*Q/L^2.

    Array axes are ``(mu, x, y)``.  The boundary link in the y direction
    supplies the transition function required by periodicity on the torus.
    """
    L = int(lattice_size)
    Q = int(topological_charge)
    if L < 2:
        raise ValueError("lattice_size must be at least 2")
    links = np.ones((2, L, L), dtype=complex)
    for x in range(L):
        for y in range(L):
            links[0, x, y] = np.exp(-1j * 2.0 * np.pi * Q * y / (L * L))
            if y == L - 1:
                links[1, x, y] = np.exp(1j * 2.0 * np.pi * Q * x / L)
    return links


def plaquette_phases(links: np.ndarray) -> np.ndarray:
    """Return principal plaquette phases for a periodic two-dimensional field."""
    if links.ndim != 3 or links.shape[0] != 2 or links.shape[1] != links.shape[2]:
        raise ValueError("links must have shape (2, L, L)")
    L = links.shape[1]
    phases = np.empty((L, L), dtype=float)
    for x in range(L):
        for y in range(L):
            plaquette = (
                links[0, x, y]
                * links[1, (x + 1) % L, y]
                * np.conj(links[0, x, (y + 1) % L])
                * np.conj(links[1, x, y])
            )
            phases[x, y] = np.angle(plaquette)
    return phases


def geometric_topological_charge(links: np.ndarray) -> float:
    """Geometric charge from the sum of principal plaquette phases."""
    return float(np.sum(plaquette_phases(links)) / (2.0 * np.pi))


def _site_index(x: int, y: int, lattice_size: int) -> int:
    return x * lattice_size + y


def wilson_dirac_operator(
    links: np.ndarray,
    lattice_spacing: float = 1.0,
    wilson_parameter: float = 1.0,
) -> np.ndarray:
    """Massless Wilson-Dirac operator in two Euclidean dimensions."""
    if lattice_spacing <= 0:
        raise ValueError("lattice_spacing must be positive")
    if wilson_parameter <= 0:
        raise ValueError("wilson_parameter must be positive")
    if links.ndim != 3 or links.shape[0] != 2 or links.shape[1] != links.shape[2]:
        raise ValueError("links must have shape (2, L, L)")
    L = links.shape[1]
    a = float(lattice_spacing)
    r = float(wilson_parameter)
    spin_identity = np.eye(2, dtype=complex)
    operator = np.zeros((2 * L * L, 2 * L * L), dtype=complex)

    for x in range(L):
        for y in range(L):
            site = _site_index(x, y, L)
            row = slice(2 * site, 2 * site + 2)
            operator[row, row] += (2.0 * r / a) * spin_identity
            coordinates = [x, y]
            for mu in range(2):
                plus = coordinates.copy()
                minus = coordinates.copy()
                plus[mu] = (plus[mu] + 1) % L
                minus[mu] = (minus[mu] - 1) % L
                plus_site = _site_index(plus[0], plus[1], L)
                minus_site = _site_index(minus[0], minus[1], L)
                plus_col = slice(2 * plus_site, 2 * plus_site + 2)
                minus_col = slice(2 * minus_site, 2 * minus_site + 2)
                operator[row, plus_col] += (
                    -(r * spin_identity - _GAMMA[mu])
                    * links[mu, x, y]
                    / (2.0 * a)
                )
                operator[row, minus_col] += (
                    -(r * spin_identity + _GAMMA[mu])
                    * np.conj(links[mu, minus[0], minus[1]])
                    / (2.0 * a)
                )
    return operator


@dataclass(frozen=True)
class OverlapResult:
    operator: np.ndarray
    hermitian_wilson_kernel: np.ndarray
    kernel_eigenvalues: np.ndarray
    sign_kernel: np.ndarray
    gamma5: np.ndarray
    rho: float
    lattice_spacing: float


def overlap_dirac_operator(
    links: np.ndarray,
    rho: float = 1.0,
    lattice_spacing: float = 1.0,
    wilson_parameter: float = 1.0,
    zero_tolerance: float = 1e-12,
) -> OverlapResult:
    """Construct the exact finite-matrix Neuberger overlap operator."""
    if not 0.0 < rho < 2.0 * wilson_parameter:
        raise ValueError("rho must satisfy 0 < rho < 2*r")
    L = links.shape[1]
    a = float(lattice_spacing)
    d_w = wilson_dirac_operator(links, a, wilson_parameter)
    gamma5 = gamma5_matrix(L)
    shifted = d_w - (rho / a) * np.eye(d_w.shape[0], dtype=complex)
    h_w = gamma5 @ shifted
    hermiticity_error = float(np.max(np.abs(h_w - h_w.conj().T)))
    if hermiticity_error > 1e-10:
        raise RuntimeError(f"Wilson kernel is not Hermitian: {hermiticity_error}")
    eigenvalues, eigenvectors = eigh(h_w)
    if float(np.min(np.abs(eigenvalues))) <= zero_tolerance:
        raise RuntimeError("Wilson kernel crosses zero; the overlap index is ill-defined")
    signs = np.sign(eigenvalues)
    sign_kernel = (eigenvectors * signs) @ eigenvectors.conj().T
    operator = (rho / a) * (np.eye(d_w.shape[0], dtype=complex) + gamma5 @ sign_kernel)
    return OverlapResult(
        operator=operator,
        hermitian_wilson_kernel=h_w,
        kernel_eigenvalues=eigenvalues,
        sign_kernel=sign_kernel,
        gamma5=gamma5,
        rho=float(rho),
        lattice_spacing=a,
    )


def overlap_index(result: OverlapResult) -> float:
    """Compute the Ginsparg-Wilson index from the overlap operator."""
    factor = result.lattice_spacing / (2.0 * result.rho)
    identity = np.eye(result.operator.shape[0], dtype=complex)
    value = np.trace(result.gamma5 @ (identity - factor * result.operator))
    return float(np.real_if_close(value).real)


@dataclass(frozen=True)
class ChiralCertificate:
    lattice_size: int
    input_flux: int
    geometric_charge: float
    overlap_index: float
    expected_index: int
    plaquette_uniformity_error: float
    kernel_hermiticity_error: float
    kernel_gap: float
    sign_involution_error: float
    gamma5_hermiticity_error: float
    ginsparg_wilson_error: float
    index_integrality_error: float
    index_theorem_error: float
    passed: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def chiral_certificate(
    lattice_size: int,
    topological_charge: int,
    rho: float = 1.0,
    lattice_spacing: float = 1.0,
) -> ChiralCertificate:
    """Verify compact flux, exact lattice chirality, and the index theorem."""
    links = uniform_u1_flux_links(lattice_size, topological_charge)
    phases = plaquette_phases(links)
    result = overlap_dirac_operator(links, rho=rho, lattice_spacing=lattice_spacing)
    d = result.operator
    gamma5 = result.gamma5
    a = result.lattice_spacing
    gw_residual = gamma5 @ d + d @ gamma5 - (a / result.rho) * d @ gamma5 @ d
    index = overlap_index(result)
    expected_index = -int(topological_charge)  # sign fixed by the link convention above
    geometric_charge = geometric_topological_charge(links)
    certificate = ChiralCertificate(
        lattice_size=int(lattice_size),
        input_flux=int(topological_charge),
        geometric_charge=geometric_charge,
        overlap_index=index,
        expected_index=expected_index,
        plaquette_uniformity_error=float(np.std(phases)),
        kernel_hermiticity_error=float(
            np.max(np.abs(result.hermitian_wilson_kernel - result.hermitian_wilson_kernel.conj().T))
        ),
        kernel_gap=float(np.min(np.abs(result.kernel_eigenvalues))),
        sign_involution_error=float(
            np.max(np.abs(result.sign_kernel @ result.sign_kernel - np.eye(d.shape[0])))
        ),
        gamma5_hermiticity_error=float(np.max(np.abs(d.conj().T - gamma5 @ d @ gamma5))),
        ginsparg_wilson_error=float(np.max(np.abs(gw_residual))),
        index_integrality_error=float(abs(index - round(index))),
        index_theorem_error=float(abs(index - expected_index)),
        passed=False,
    )
    passed = bool(
        abs(geometric_charge - topological_charge) < 1e-12
        and certificate.plaquette_uniformity_error < 1e-12
        and certificate.kernel_hermiticity_error < 1e-12
        and certificate.kernel_gap > 1e-8
        and certificate.sign_involution_error < 1e-11
        and certificate.gamma5_hermiticity_error < 1e-11
        and certificate.ginsparg_wilson_error < 1e-11
        and certificate.index_integrality_error < 1e-10
        and certificate.index_theorem_error < 1e-10
    )
    return ChiralCertificate(**{**certificate.as_dict(), "passed": passed})


def chiral_flux_suite(
    lattice_sizes: tuple[int, ...] = (4, 5, 6, 8),
    charges: tuple[int, ...] = (-2, -1, 0, 1, 2),
) -> dict[str, Any]:
    """Run an unselected grid of flux/index challenges."""
    trials = [chiral_certificate(L, Q).as_dict() for L in lattice_sizes for Q in charges]
    return {
        "trial_count": len(trials),
        "max_ginsparg_wilson_error": max(t["ginsparg_wilson_error"] for t in trials),
        "max_index_theorem_error": max(t["index_theorem_error"] for t in trials),
        "minimum_kernel_gap": min(t["kernel_gap"] for t in trials),
        "trials": trials,
        "pass": all(t["passed"] for t in trials),
        "scope": (
            "Two-dimensional U(1) overlap-fermion test bed. It establishes exact finite-lattice "
            "chirality and topology, not the full four-dimensional Standard Model fermion sector."
        ),
    }
