"""Representation-trace coupling relation and a falsification stress test.

The anomaly-free one-generation representation pattern fixes relative gauge
trace normalizations.  If a single microscopic coefficient multiplies those
traces, one obtains the conditional high-scale relation

    g_3^2 = g_2^2 = (5/3) g_Y^2,
    sin^2(theta_W) = 3/8.

This module then tests the *minimal* hypothesis of exact one-loop Standard
Model unification with no threshold corrections.  It is deliberately a death
test: two measured couplings determine the unification scale and coupling; the
third is held out.  Failure is recorded rather than hidden.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from fractions import Fraction
import math
from typing import Any

from .renormalization_group import standard_model_one_loop_beta_coefficients


@dataclass(frozen=True)
class TraceNormalizations:
    k_y: Fraction
    k_su2: Fraction
    k_su3: Fraction

    def as_dict(self) -> dict[str, str]:
        return {k: str(v) for k, v in asdict(self).items()}


def fermion_trace_normalizations(generations: int = 1) -> TraceNormalizations:
    """Trace sums over left-handed Weyl states of the assumed SM pattern."""
    if generations <= 0:
        raise ValueError("generations must be positive")
    n = Fraction(generations)
    sum_y2 = (
        6 * Fraction(1, 6) ** 2
        + 3 * Fraction(-2, 3) ** 2
        + 3 * Fraction(1, 3) ** 2
        + 2 * Fraction(-1, 2) ** 2
        + Fraction(1, 1) ** 2
    ) * n
    # Dynkin-index sums including spectator multiplicities.
    return TraceNormalizations(k_y=sum_y2, k_su2=2 * n, k_su3=2 * n)


def spectral_coupling_certificate() -> dict[str, Any]:
    traces = fermion_trace_normalizations(1)
    ratio_y_to_su2 = traces.k_y / traces.k_su2
    # Equal microscopic normalization means k_i g_i^2 is common.
    gy2_over_g22 = traces.k_su2 / traces.k_y
    sin2 = gy2_over_g22 / (1 + gy2_over_g22)
    return {
        "trace_normalizations_per_generation": traces.as_dict(),
        "kY_over_k2": str(ratio_y_to_su2),
        "conditional_relation": "g3^2=g2^2=(5/3) gY^2",
        "sin2_thetaW_at_common_normalization_scale": str(sin2),
        "exact_expected": "3/8",
        "pass": sin2 == Fraction(3, 8) and ratio_y_to_su2 == Fraction(5, 3),
        "scope": (
            "Conditional on the assumed SM representation pattern and a single common microscopic "
            "gauge-trace coefficient. It does not establish that such a scale exists in the minimal model."
        ),
    }


@dataclass(frozen=True)
class CouplingBenchmark:
    reference_scale_gev: float = 91.1876
    alpha_em_inverse_msbar: float = 127.930
    alpha_em_inverse_sigma: float = 0.008
    sin2_theta_msbar: float = 0.23129
    sin2_theta_sigma: float = 0.00004
    alpha_s_msbar: float = 0.1180
    alpha_s_sigma: float = 0.0009


def _low_energy_alphas(benchmark: CouplingBenchmark) -> tuple[float, float, float]:
    alpha = 1.0 / benchmark.alpha_em_inverse_msbar
    alpha_y = alpha / (1.0 - benchmark.sin2_theta_msbar)
    alpha_1 = (5.0 / 3.0) * alpha_y
    alpha_2 = alpha / benchmark.sin2_theta_msbar
    return alpha_1, alpha_2, benchmark.alpha_s_msbar


def _predict_alpha3_from_alpha1_alpha2(benchmark: CouplingBenchmark) -> dict[str, float]:
    alpha1, alpha2, _ = _low_energy_alphas(benchmark)
    b = standard_model_one_loop_beta_coefficients()
    b1, b2, b3 = float(b.b1), float(b.b2), float(b.b3)
    inv1, inv2 = 1.0 / alpha1, 1.0 / alpha2
    log_ratio = 2.0 * math.pi * (inv1 - inv2) / (b1 - b2)
    inverse_unified = inv1 - b1 * log_ratio / (2.0 * math.pi)
    inverse_alpha3_prediction = inverse_unified + b3 * log_ratio / (2.0 * math.pi)
    return {
        "log_MU_over_MZ": log_ratio,
        "unification_scale_gev": benchmark.reference_scale_gev * math.exp(log_ratio),
        "inverse_alpha_unified": inverse_unified,
        "predicted_inverse_alpha3_MZ": inverse_alpha3_prediction,
        "predicted_alpha3_MZ": 1.0 / inverse_alpha3_prediction,
    }


def _prediction_sigma_from_electroweak_inputs(benchmark: CouplingBenchmark) -> float:
    """Finite-difference propagation of experimental alpha and sin^2 errors."""
    base = asdict(benchmark)
    variances = 0.0
    for value_key, sigma_key in (
        ("alpha_em_inverse_msbar", "alpha_em_inverse_sigma"),
        ("sin2_theta_msbar", "sin2_theta_sigma"),
    ):
        sigma = float(base[sigma_key])
        plus = dict(base)
        minus = dict(base)
        plus[value_key] += sigma
        minus[value_key] -= sigma
        fp = _predict_alpha3_from_alpha1_alpha2(CouplingBenchmark(**plus))["predicted_alpha3_MZ"]
        fm = _predict_alpha3_from_alpha1_alpha2(CouplingBenchmark(**minus))["predicted_alpha3_MZ"]
        derivative = (fp - fm) / (2.0 * sigma)
        variances += (derivative * sigma) ** 2
    return math.sqrt(variances)


def _pairwise_meeting_scales(benchmark: CouplingBenchmark) -> dict[str, float]:
    alphas = _low_energy_alphas(benchmark)
    inv = [1.0 / x for x in alphas]
    beta = standard_model_one_loop_beta_coefficients()
    b = [float(beta.b1), float(beta.b2), float(beta.b3)]
    result: dict[str, float] = {}
    for i, j, label in ((0, 1, "M12_gev"), (0, 2, "M13_gev"), (1, 2, "M23_gev")):
        t = 2.0 * math.pi * (inv[i] - inv[j]) / (b[i] - b[j])
        result[label] = benchmark.reference_scale_gev * math.exp(t)
    return result


def minimal_unification_stress_certificate(
    benchmark: CouplingBenchmark | None = None,
) -> dict[str, Any]:
    """Hold out alpha_s after fitting exact unification to alpha1 and alpha2."""
    benchmark = benchmark or CouplingBenchmark()
    prediction = _predict_alpha3_from_alpha1_alpha2(benchmark)
    pred_sigma = _prediction_sigma_from_electroweak_inputs(benchmark)
    combined_sigma = math.hypot(pred_sigma, benchmark.alpha_s_sigma)
    difference = prediction["predicted_alpha3_MZ"] - benchmark.alpha_s_msbar
    experimental_only_pull = difference / combined_sigma
    relative_error = difference / benchmark.alpha_s_msbar
    pairwise = _pairwise_meeting_scales(benchmark)
    pair_spread = max(pairwise.values()) / min(pairwise.values())
    minimal_model_survives = abs(experimental_only_pull) < 5.0 and pair_spread < 10.0
    return {
        "benchmark": asdict(benchmark),
        "benchmark_sources": {
            "alpha_em_inverse_msbar": "PDG 2024 Electroweak review, alpha_hat^(5)(MZ)^-1=127.930+/-0.008",
            "sin2_theta_msbar": "PDG 2024 Electroweak global fit, s_hat_Z^2=0.23129+/-0.00004",
            "alpha_s_msbar": "PDG 2024 QCD review, world average alpha_s(MZ)=0.1180+/-0.0009",
        },
        "fit_inputs": ["alpha1(MZ)", "alpha2(MZ)"],
        "held_out_observable": "alpha3(MZ)=alpha_s(MZ)",
        "prediction": prediction,
        "prediction_sigma_from_experimental_EW_inputs": pred_sigma,
        "observed_alpha3_MZ": benchmark.alpha_s_msbar,
        "observed_alpha3_sigma": benchmark.alpha_s_sigma,
        "relative_prediction_error": relative_error,
        "experimental_only_pull_sigma": experimental_only_pull,
        "pairwise_meeting_scales": pairwise,
        "pairwise_scale_spread_factor": pair_spread,
        "minimal_exact_one_loop_unification_survives": minimal_model_survives,
        "test_pass": not minimal_model_survives,
        "verdict": (
            "The conditional 3/8 high-scale trace relation is exact, but the minimal no-threshold "
            "one-loop Standard Model does not unify: fitting alpha1 and alpha2 predicts alpha_s "
            "far below the held-out measured value. New thresholds or different microscopic content "
            "would be required and must be preregistered before refitting."
        ),
        "scope": (
            "The quoted pull propagates experimental errors only. It is a death test of the exactly "
            "specified minimal model, not a precision exclusion of every possible threshold completion."
        ),
    }
