"""Minimal flavor-sector no-go certificates.

Topological multiplicity supplies a vector space of families, but it does not
by itself generate non-degenerate masses or mixing.  In the maximally symmetric
same-bundle toy sector with a constant Higgs profile, the overlap matrix on an
orthonormal Q=3 zero-mode subspace is exactly the identity.  Thus all three
singular values are degenerate.  Flavor hierarchy requires additional geometry
or background profiles, whose parameters are not yet derived.
"""
from __future__ import annotations

from typing import Any
import numpy as np

from .chiral_overlap import overlap_dirac_operator, uniform_u1_flux_links


def constant_higgs_flavor_certificate(lattice_size: int = 6, charge: int = 3) -> dict[str, Any]:
    result = overlap_dirac_operator(uniform_u1_flux_links(lattice_size, charge))
    _, singular_values, vh = np.linalg.svd(result.operator, full_matrices=False)
    order = np.argsort(singular_values)
    zero_count = abs(charge)
    basis = vh.conj().T[:, order[:zero_count]]
    # A constant scalar profile is the identity multiplication operator.
    yukawa_overlap = basis.conj().T @ basis
    flavor_singular_values = np.linalg.svd(yukawa_overlap, compute_uv=False)
    identity_error = float(np.max(np.abs(yukawa_overlap - np.eye(zero_count))))
    degeneracy_spread = float(np.max(flavor_singular_values) - np.min(flavor_singular_values))
    return {
        "lattice_size": lattice_size,
        "topological_charge": charge,
        "family_dimension": zero_count,
        "zero_mode_singular_values": [float(x) for x in singular_values[order[:zero_count]]],
        "constant_profile_yukawa_matrix_real": np.real_if_close(yukawa_overlap).real.tolist(),
        "flavor_singular_values": [float(x) for x in flavor_singular_values],
        "identity_error": identity_error,
        "degeneracy_spread": degeneracy_spread,
        "pass": identity_error < 1e-12 and degeneracy_spread < 1e-12,
        "verdict": (
            "Three topological zero modes plus a constant symmetric Higgs profile produce three "
            "degenerate couplings, not the observed hierarchy. Nonuniform profiles, Wilson lines, "
            "different bundles or other symmetry breaking are necessary and would introduce new inputs."
        ),
        "scope": "same-bundle 2D overlap toy sector; this is a controlled no-go, not a complete flavor model",
    }
