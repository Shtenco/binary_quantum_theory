#!/usr/bin/env python3
"""Controlled EFT layer for compact-holonomy / quantum-foam hypotheses.

This module does *not* claim that spacetime foam enhances nuclear reactions.
It provides a dimensionally consistent parametrisation whose coefficients can
be bounded or falsified.  The default model reduces to ordinary WKB.

Conventions
-----------
The covariant action is most transparent in natural units (c = ħ = 1):

    S_eff = ∫ d⁴x √(-g) [
        M_Pl²/2 (R - 2Λ)
        - Zφ/2 (∇φ)² - U(φ)
        - ZF/4 F_{μν}F^{μν}
        + ψ̄(i e_a^μ γ^a D_μ - mψ)ψ
        + Σ_n c_n O_n / M_Pl^(n-4)
    ].

Compact holonomies enter through bounded replacements such as
K -> K_δ = sin(δK)/δ.  They are a regulator/deformation ansatz, not by
 themselves a completed anomaly-free theory.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable
import math
import numpy as np
from scipy import integrate

ArrayLike = np.ndarray | list[float] | tuple[float, ...]
Potential = Callable[[float], float]


@dataclass(frozen=True)
class EFTParameters:
    """Dimensionless low-energy coefficients in a chosen EFT basis.

    xi_curvature couples the foam scalar to curvature via xi φ²R/2.
    beta_em couples it to electromagnetism via -beta φ F²/(4 M_Pl).
    c6_derivative controls a representative dimension-6 derivative operator.

    Values are not predicted here.  They must be fixed by a microscopic model
    or constrained experimentally.  Zero is the conservative default.
    """

    z_phi: float = 1.0
    z_em: float = 1.0
    xi_curvature: float = 0.0
    beta_em: float = 0.0
    c6_derivative: float = 0.0

    def validate(self) -> None:
        values = vars(self)
        if not all(math.isfinite(v) for v in values.values()):
            raise ValueError("All EFT coefficients must be finite")
        if self.z_phi <= 0 or self.z_em <= 0:
            raise ValueError("Kinetic normalisations z_phi and z_em must be positive")


@dataclass(frozen=True)
class HolonomyCorrection:
    """Bounded holonomy deformation K_delta = sin(delta K)/delta."""

    delta: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.delta) or self.delta <= 0:
            raise ValueError("delta must be finite and positive")

    def apply(self, curvature: ArrayLike | float) -> np.ndarray | float:
        k = np.asarray(curvature, dtype=float)
        out = np.sin(self.delta * k) / self.delta
        return float(out) if out.ndim == 0 else out

    def beta(self, curvature: ArrayLike | float) -> np.ndarray | float:
        """Common deformation factor beta = cos(2 delta K)."""
        k = np.asarray(curvature, dtype=float)
        out = np.cos(2.0 * self.delta * k)
        return float(out) if out.ndim == 0 else out

    def remainder_bound(self, curvature: float) -> float:
        """Bound |K_delta-K| <= delta² |K|³/6 for real scalar K."""
        return self.delta**2 * abs(curvature) ** 3 / 6.0


def planck_suppression(length_scale: float, planck_length: float, power: int = 2) -> float:
    """Return the EFT suppression parameter (l_P/L)^power.

    This is a bookkeeping parameter, not a universal observable.  For any
    ordinary nuclear length L >> l_P it is extraordinarily small unless a
    separate infrared enhancement mechanism is explicitly demonstrated.
    """
    if length_scale <= 0 or planck_length <= 0:
        raise ValueError("length scales must be positive")
    if power <= 0:
        raise ValueError("power must be positive")
    return (planck_length / length_scale) ** power


def foam_corrected_barrier(
    base_potential: Potential,
    foam_profile: Potential,
    coupling: float,
    suppression: float,
) -> Potential:
    """Construct V_eff(x)=V0(x)+coupling*suppression*phi(x).

    The explicit suppression makes the hypothesis testable and prevents an
    unphysical order-one Planck-scale effect from being inserted by hand.
    """
    if not math.isfinite(coupling) or not math.isfinite(suppression):
        raise ValueError("coupling and suppression must be finite")
    if suppression < 0:
        raise ValueError("suppression must be non-negative")

    def effective(x: float) -> float:
        return float(base_potential(x) + coupling * suppression * foam_profile(x))

    return effective


def barrier_action(
    potential: Potential,
    energy: float,
    mass: float,
    x_left: float,
    x_right: float,
) -> float:
    """Return the one-way forbidden-region action ∫ sqrt(2m max(V-E,0)) dx."""
    if mass <= 0:
        raise ValueError("mass must be positive")
    if x_right <= x_left:
        raise ValueError("x_right must exceed x_left")

    def integrand(x: float) -> float:
        gap = max(float(potential(x)) - energy, 0.0)
        return math.sqrt(2.0 * mass * gap)

    value, error = integrate.quad(integrand, x_left, x_right, limit=400)
    if not math.isfinite(value) or error < 0:
        raise RuntimeError("barrier integral failed")
    return value


def tunneling_amplitude(
    action: float,
    hbar: float,
    phase: float = 0.0,
) -> complex:
    """Semiclassical amplitude A = exp(-S_B/ħ) exp(i phase)."""
    if action < 0 or hbar <= 0:
        raise ValueError("action must be non-negative and hbar positive")
    return complex(np.exp(-action / hbar + 1j * phase))


def tunneling_probability(action: float, hbar: float) -> float:
    """Leading WKB transmission probability P = exp(-2 S_B/ħ)."""
    amp = tunneling_amplitude(action, hbar)
    return float(abs(amp) ** 2)


def phase_decoherence_factor(phase_variance: float) -> float:
    """Gaussian random-phase average |<exp(iθ)>| = exp(-Var(θ)/2).

    Random foam phases suppress coherent interference; they do not multiply a
    single-path probability by an arbitrary enhancement factor.
    """
    if phase_variance < 0 or not math.isfinite(phase_variance):
        raise ValueError("phase_variance must be finite and non-negative")
    return math.exp(-0.5 * phase_variance)
