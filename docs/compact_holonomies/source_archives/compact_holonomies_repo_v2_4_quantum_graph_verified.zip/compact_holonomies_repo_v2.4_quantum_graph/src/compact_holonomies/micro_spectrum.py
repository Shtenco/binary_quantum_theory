"""Fixed compact micro-operator and preregistered spectral predictions."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np


def twisted_shift(size: int, twist: float) -> np.ndarray:
    if size < 3:
        raise ValueError("size must be >= 3")
    u = np.zeros((size, size), dtype=complex)
    for j in range(size - 1):
        u[j, j + 1] = 1.0
    u[size - 1, 0] = np.exp(1j * twist)
    return u


def compact_laplacian(size: int, delta: float, twist: float = 0.0) -> np.ndarray:
    if delta <= 0:
        raise ValueError("delta must be positive")
    u = twisted_shift(size, twist)
    return (2 * np.eye(size) - u - u.conj().T) / delta**2


def analytic_eigenvalues(size: int, delta: float, twist: float = 0.0) -> np.ndarray:
    modes = np.arange(size)
    q = (2 * np.pi * modes + twist) / size
    values = 4 * np.sin(q / 2) ** 2 / delta**2
    return np.sort(values.real)


def continuum_baseline_eigenvalues(size: int, delta: float, twist: float = 0.0) -> np.ndarray:
    modes = np.arange(size)
    q = (2 * np.pi * modes + twist) / size
    q = (q + np.pi) % (2 * np.pi) - np.pi
    return np.sort(q**2 / delta**2)


def quartic_baseline_eigenvalues(size: int, delta: float, twist: float = 0.0) -> np.ndarray:
    modes = np.arange(size)
    q = (2 * np.pi * modes + twist) / size
    q = (q + np.pi) % (2 * np.pi) - np.pi
    return np.sort((q**2 - q**4 / 12) / delta**2)


def universal_series_ratio() -> float:
    """For 4 sin^2(q/2): coefficient(q^6)/coefficient(q^4)^2 = 2/5."""
    c4 = -1 / 12
    c6 = 1 / 360
    return c6 / (c4**2)


@dataclass(frozen=True)
class BlindChallenge:
    size: int
    delta: float
    twist: float
    holdout_indices: tuple[int, ...]
    seed_hex: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def challenge_from_manifest(manifest_bytes: bytes) -> BlindChallenge:
    digest = hashlib.sha256(manifest_bytes).digest()
    seed = int.from_bytes(digest[:8], "big")
    rng = np.random.default_rng(seed)
    sizes = np.array([29, 31, 37, 41, 43, 47])
    size = int(rng.choice(sizes))
    delta = float(rng.uniform(0.15, 0.85))
    twist = float(rng.uniform(0.15, 2.85))
    count = max(8, int(round(0.65 * size)))
    holdout = tuple(sorted(int(i) for i in rng.choice(size, size=count, replace=False)))
    return BlindChallenge(size=size, delta=delta, twist=twist, holdout_indices=holdout, seed_hex=digest.hex())


def _error_metrics(prediction: np.ndarray, truth: np.ndarray, indices: np.ndarray) -> dict[str, float]:
    p = prediction[indices]
    t = truth[indices]
    error = p - t
    scale = max(1e-30, float(np.max(np.abs(t))))
    return {
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(error**2))),
        "max_abs": float(np.max(np.abs(error))),
        "normalized_rmse": float(np.sqrt(np.mean(error**2)) / scale),
    }


def run_blind_spectrum_test(manifest_path: str | Path) -> dict[str, Any]:
    manifest_path = Path(manifest_path)
    challenge = challenge_from_manifest(manifest_path.read_bytes())
    numerical = np.linalg.eigvalsh(compact_laplacian(challenge.size, challenge.delta, challenge.twist))
    exact = analytic_eigenvalues(challenge.size, challenge.delta, challenge.twist)
    continuum = continuum_baseline_eigenvalues(challenge.size, challenge.delta, challenge.twist)
    quartic = quartic_baseline_eigenvalues(challenge.size, challenge.delta, challenge.twist)
    holdout = np.array(challenge.holdout_indices, dtype=int)
    result = {
        "challenge": challenge.as_dict(),
        "holdout_fraction": float(len(holdout) / challenge.size),
        "compact_prediction": _error_metrics(exact, numerical, holdout),
        "continuum_baseline": _error_metrics(continuum, numerical, holdout),
        "quartic_baseline": _error_metrics(quartic, numerical, holdout),
        "universal_series_ratio_predicted": universal_series_ratio(),
        "universal_series_ratio_exact": 0.4,
    }
    result["pass"] = bool(
        result["compact_prediction"]["normalized_rmse"] < 1e-12
        and result["compact_prediction"]["rmse"] < result["quartic_baseline"]["rmse"]
        and abs(result["universal_series_ratio_predicted"] - 0.4) < 1e-15
    )
    return result



def run_blind_spectrum_suite(manifest_path: str | Path, challenge_count: int = 32) -> dict[str, Any]:
    """Evaluate the frozen predictor on many non-hand-picked challenges.

    Challenge seeds are SHA256(manifest || counter), so the suite is reproducible
    and cannot be selected by looking at the numerical eigenvalues.
    """
    manifest_path = Path(manifest_path)
    manifest = manifest_path.read_bytes()
    trials = []
    for counter in range(challenge_count):
        salted = manifest + counter.to_bytes(8, "big")
        challenge = challenge_from_manifest(salted)
        numerical = np.linalg.eigvalsh(compact_laplacian(challenge.size, challenge.delta, challenge.twist))
        exact = analytic_eigenvalues(challenge.size, challenge.delta, challenge.twist)
        continuum = continuum_baseline_eigenvalues(challenge.size, challenge.delta, challenge.twist)
        quartic = quartic_baseline_eigenvalues(challenge.size, challenge.delta, challenge.twist)
        holdout = np.array(challenge.holdout_indices, dtype=int)
        trials.append({
            "counter": counter,
            "challenge": challenge.as_dict(),
            "compact_prediction": _error_metrics(exact, numerical, holdout),
            "continuum_baseline": _error_metrics(continuum, numerical, holdout),
            "quartic_baseline": _error_metrics(quartic, numerical, holdout),
        })
    max_exact_nrmse = max(t["compact_prediction"]["normalized_rmse"] for t in trials)
    wins_quartic = sum(t["compact_prediction"]["rmse"] < t["quartic_baseline"]["rmse"] for t in trials)
    wins_continuum = sum(t["compact_prediction"]["rmse"] < t["continuum_baseline"]["rmse"] for t in trials)
    return {
        "challenge_count": challenge_count,
        "max_compact_normalized_rmse": float(max_exact_nrmse),
        "wins_against_quartic": int(wins_quartic),
        "wins_against_continuum": int(wins_continuum),
        "trials": trials,
        "pass": bool(max_exact_nrmse < 1e-12 and wins_quartic == challenge_count and wins_continuum == challenge_count),
    }

def write_default_manifest(path: str | Path) -> Path:
    path = Path(path)
    payload = {
        "operator": "L_delta=(2I-U-U^dagger)/delta^2",
        "boundary": "U^N=exp(i*twist)I",
        "prediction": "lambda_n=4 sin^2((2*pi*n+twist)/(2N))/delta^2",
        "baselines": ["continuum q^2/delta^2", "quartic (q^2-q^4/12)/delta^2"],
        "holdout_rule": "SHA256(manifest) deterministically chooses N, delta, twist, and 65% holdout",
        "no_fit_parameters": True,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return path
