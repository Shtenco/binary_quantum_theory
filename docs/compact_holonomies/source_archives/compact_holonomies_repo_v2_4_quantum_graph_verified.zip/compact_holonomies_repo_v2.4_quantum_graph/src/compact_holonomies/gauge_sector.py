"""Constructive compact U(1) x SU(2) x SU(3) gauge representation.

This module proves that the standard gauge algebras can be represented by
compact link holonomies with exact finite-dimensional Lie-algebra closure.  It
does not claim that this product group, its representations, or its couplings
are uniquely derived from the gravitational holonomy sector.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

import numpy as np
from scipy.linalg import expm


def su2_generators() -> list[np.ndarray]:
    sigma = [
        np.array([[0, 1], [1, 0]], dtype=complex),
        np.array([[0, -1j], [1j, 0]], dtype=complex),
        np.array([[1, 0], [0, -1]], dtype=complex),
    ]
    return [matrix / 2 for matrix in sigma]


def su3_generators() -> list[np.ndarray]:
    z = 0j
    matrices = [
        [[0, 1, 0], [1, 0, 0], [0, 0, 0]],
        [[0, -1j, 0], [1j, 0, 0], [0, 0, 0]],
        [[1, 0, 0], [0, -1, 0], [0, 0, 0]],
        [[0, 0, 1], [0, 0, 0], [1, 0, 0]],
        [[0, 0, -1j], [0, 0, 0], [1j, 0, 0]],
        [[0, 0, 0], [0, 0, 1], [0, 1, 0]],
        [[0, 0, 0], [0, 0, -1j], [0, 1j, 0]],
        [[1 / np.sqrt(3), 0, 0], [0, 1 / np.sqrt(3), 0], [0, 0, -2 / np.sqrt(3)]],
    ]
    return [np.array(matrix, dtype=complex) / 2 for matrix in matrices]


def u1_generator() -> list[np.ndarray]:
    return [np.array([[1.0]], dtype=complex)]


@dataclass(frozen=True)
class AlgebraCertificate:
    name: str
    dimension: int
    max_normalization_error: float
    max_closure_residual: float
    max_antihermiticity_error: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def algebra_certificate(name: str, generators: list[np.ndarray]) -> AlgebraCertificate:
    dim = len(generators)
    gram = np.array([[np.trace(a @ b).real for b in generators] for a in generators])
    target_scale = 1.0 if name == "U(1)" else 0.5
    normalization_error = float(np.max(np.abs(gram - target_scale * np.eye(dim))))
    inverse_gram = np.linalg.inv(gram)
    max_residual = 0.0
    max_antihermiticity = 0.0
    for a in generators:
        for b in generators:
            commutator = a @ b - b @ a
            max_antihermiticity = max(
                max_antihermiticity,
                float(np.max(np.abs(commutator.conj().T + commutator))),
            )
            overlaps = np.array([np.trace(g.conj().T @ (-1j * commutator)).real for g in generators])
            coefficients = inverse_gram @ overlaps
            reconstructed = 1j * sum(c * g for c, g in zip(coefficients, generators))
            max_residual = max(max_residual, float(np.max(np.abs(commutator - reconstructed))))
    return AlgebraCertificate(
        name=name,
        dimension=dim,
        max_normalization_error=normalization_error,
        max_closure_residual=max_residual,
        max_antihermiticity_error=max_antihermiticity,
    )


def wilson_link(generators: list[np.ndarray], angles: np.ndarray) -> np.ndarray:
    if len(generators) != len(angles):
        raise ValueError("one angle is required per generator")
    exponent = 1j * sum(float(theta) * generator for theta, generator in zip(angles, generators))
    return expm(exponent)


def wilson_certificate(generators: list[np.ndarray], seed: int = 11) -> dict[str, float | bool]:
    rng = np.random.default_rng(seed)
    angles = rng.normal(scale=0.4, size=len(generators))
    link = wilson_link(generators, angles)
    identity = np.eye(link.shape[0])
    unitarity_error = float(np.max(np.abs(link.conj().T @ link - identity)))
    determinant_modulus_error = float(abs(abs(np.linalg.det(link)) - 1.0))
    return {
        "unitarity_error": unitarity_error,
        "determinant_modulus_error": determinant_modulus_error,
        "pass": bool(unitarity_error < 1e-12 and determinant_modulus_error < 1e-12),
    }


def standard_model_gauge_certificate() -> dict[str, object]:
    groups = {
        "U(1)": u1_generator(),
        "SU(2)": su2_generators(),
        "SU(3)": su3_generators(),
    }
    algebra = {name: algebra_certificate(name, generators).as_dict() for name, generators in groups.items()}
    links = {name: wilson_certificate(generators) for name, generators in groups.items()}
    max_residual = max(item["max_closure_residual"] for item in algebra.values())
    return {
        "group": "U(1) x SU(2) x SU(3)",
        "total_generator_count": 1 + 3 + 8,
        "algebra_certificates": algebra,
        "wilson_link_certificates": links,
        "pass": bool(max_residual < 1e-12 and all(item["pass"] for item in links.values())),
        "derivation_status": (
            "Constructed consistently, not uniquely derived. Gauge couplings, chiral "
            "representations, Yukawa matrices and symmetry-breaking parameters remain free."
        ),
    }
