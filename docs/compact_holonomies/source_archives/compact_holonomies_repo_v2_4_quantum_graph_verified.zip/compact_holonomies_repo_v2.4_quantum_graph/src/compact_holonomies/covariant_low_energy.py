"""Minimal covariant low-energy completion and its limited predictions.

The completion is GR plus diffeomorphism-invariant curvature operators that
start at cubic order in curvature.  This is an explicit *completion choice*,
not a unique derivation from compact holonomies.  Its useful property is that
its quadratic action around Minkowski is exactly the Fierz-Pauli action, so it
has the standard two luminal tensor modes at tree level.
"""
from __future__ import annotations

import sympy as sp


def cubic_curvature_quadratic_order_certificate() -> dict[str, str | bool]:
    eps = sp.symbols("epsilon")
    r1, r2, r3, s1, s2 = sp.symbols("r1 r2 r3 s1 s2")
    curvature = eps * r1 + eps**2 * r2 + eps**3 * r3
    sqrt_minus_g = 1 + eps * s1 + eps**2 * s2
    correction = sp.expand(sqrt_minus_g * curvature**3)
    coefficient_0 = sp.expand(correction).coeff(eps, 0)
    coefficient_1 = sp.expand(correction).coeff(eps, 1)
    coefficient_2 = sp.expand(correction).coeff(eps, 2)
    coefficient_3 = sp.expand(correction).coeff(eps, 3)
    return {
        "epsilon^0": str(coefficient_0),
        "epsilon^1": str(coefficient_1),
        "epsilon^2": str(coefficient_2),
        "epsilon^3": str(coefficient_3),
        "quadratic_action_unchanged": bool(coefficient_0 == coefficient_1 == coefficient_2 == 0),
        "leading_correction_is_cubic": bool(coefficient_3 == r1**3),
    }


def low_energy_predictions() -> dict[str, object]:
    return {
        "background": "Minkowski",
        "tensor_polarizations": 2,
        "tree_level_c_gw_over_c": 1.0,
        "linear_dispersion": "omega^2=k^2",
        "scope": (
            "Applies to the explicitly chosen diffeomorphism-invariant low-energy "
            "completion with corrections beginning at curvature-cubed order."
        ),
    }


def gw170817_consistency_check() -> dict[str, object]:
    lower = -3e-15
    upper = 7e-16
    prediction = 0.0
    return {
        "observable": "(c_gw-c)/c",
        "prediction": prediction,
        "observational_interval": [lower, upper],
        "consistent": bool(lower <= prediction <= upper),
        "data_source": "GW170817/GRB170817A, LIGO-Virgo-Fermi-INTEGRAL (2017)",
        "classification": "external consistency check, not a blind discovery",
    }
