"""One-loop gauge beta coefficients from the derived chiral matter content.

Convention:

    mu dg_i/dmu = b_i g_i^3 / (16 pi^2).

For U(1), ``g1`` uses the SU(5)/GUT normalization g1=sqrt(5/3) g_Y.
The result for three generations and one complex Higgs doublet is

    (b1,b2,b3) = (41/10, -19/6, -7).

These coefficients predict running *given boundary couplings*; they do not fix
the absolute coupling values or prove unification.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from fractions import Fraction
from typing import Any


@dataclass(frozen=True)
class BetaCoefficients:
    b1: Fraction
    b2: Fraction
    b3: Fraction

    def as_dict(self) -> dict[str, str]:
        return {key: str(value) for key, value in asdict(self).items()}


def standard_model_one_loop_beta_coefficients(
    generations: int = 3,
    higgs_doublets: int = 1,
) -> BetaCoefficients:
    """Compute one-loop coefficients by summing Weyl and scalar indices."""
    if generations < 0 or higgs_doublets < 0:
        raise ValueError("field multiplicities cannot be negative")
    ng = Fraction(generations)
    nh = Fraction(higgs_doublets)

    # Non-abelian sums of Dynkin indices, including spectator multiplicities.
    # Per generation: SU(3): Q contributes 2*T(3)=1, u^c and d^c each 1/2 -> 2.
    #                 SU(2): Q contributes 3*T(2)=3/2, L contributes 1/2 -> 2.
    sum_t_fermion_su3 = 2 * ng
    sum_t_fermion_su2 = 2 * ng
    sum_t_scalar_su2 = Fraction(1, 2) * nh

    b3 = -Fraction(11, 3) * 3 + Fraction(2, 3) * sum_t_fermion_su3
    b2 = -Fraction(11, 3) * 2 + Fraction(2, 3) * sum_t_fermion_su2 + Fraction(1, 3) * sum_t_scalar_su2

    # U(1) GUT-normalized index T1=(3/5) Y^2 times dimensions of spectator reps.
    sum_y2_weyl_per_generation = (
        6 * Fraction(1, 6) ** 2
        + 3 * Fraction(-2, 3) ** 2
        + 3 * Fraction(1, 3) ** 2
        + 2 * Fraction(-1, 2) ** 2
        + Fraction(1, 1) ** 2
    )
    sum_t1_fermion = Fraction(3, 5) * sum_y2_weyl_per_generation * ng
    sum_y2_scalar_per_higgs = 2 * Fraction(1, 2) ** 2
    sum_t1_scalar = Fraction(3, 5) * sum_y2_scalar_per_higgs * nh
    b1 = Fraction(2, 3) * sum_t1_fermion + Fraction(1, 3) * sum_t1_scalar
    return BetaCoefficients(b1=b1, b2=b2, b3=b3)


def inverse_alpha_running(
    alpha_at_reference: float,
    beta_coefficient: Fraction | float,
    scale: float,
    reference_scale: float,
) -> float:
    """One-loop solution for alpha_i^{-1}(mu), with no threshold corrections."""
    import math

    if alpha_at_reference <= 0 or scale <= 0 or reference_scale <= 0:
        raise ValueError("coupling and scales must be positive")
    b = float(beta_coefficient)
    return 1.0 / alpha_at_reference - b / (2.0 * math.pi) * math.log(scale / reference_scale)


def rg_certificate() -> dict[str, Any]:
    coefficients = standard_model_one_loop_beta_coefficients()
    expected = BetaCoefficients(Fraction(41, 10), Fraction(-19, 6), Fraction(-7, 1))
    # Exact group-theoretic qualitative prediction: U(1) grows, non-abelian factors are asymptotically free.
    return {
        "convention": "mu dg_i/dmu = b_i g_i^3/(16*pi^2), g1=sqrt(5/3) gY",
        "coefficients": coefficients.as_dict(),
        "expected_exact": expected.as_dict(),
        "exact_match": coefficients == expected,
        "qualitative_flow": {
            "U1": "not asymptotically free",
            "SU2": "asymptotically free at one loop",
            "SU3": "asymptotically free at one loop",
        },
        "pass": coefficients == expected,
        "scope": (
            "The coefficients follow from the assumed Standard-Model representation content and the "
            "anomaly-derived hypercharges. Absolute gauge couplings and threshold corrections remain inputs."
        ),
    }
