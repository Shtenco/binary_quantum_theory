"""No-go stress test for selecting the topological sector |Q|=3.

For a uniform U(1) flux on a compact two-dimensional area A, the positive
Maxwell action is proportional to Q^2.  It therefore selects Q=0, not Q=3.
This module records that elementary but important obstruction quantitatively.
It does not rule out all mechanisms for selecting three families; it rules out
selection by the minimal positive uniform-flux action already used in the toy
sector.
"""
from __future__ import annotations

from typing import Any

import numpy as np


def uniform_flux_action(topological_charge: int, area: float = 1.0, gauge_coupling: float = 1.0) -> float:
    """Return S_Q = 2 pi^2 Q^2 / (g^2 A) for uniform quantized flux."""
    if area <= 0:
        raise ValueError("area must be positive")
    if gauge_coupling <= 0:
        raise ValueError("gauge_coupling must be positive")
    q = int(topological_charge)
    return float(2.0 * np.pi**2 * q**2 / (gauge_coupling**2 * area))


def flux_selection_no_go_certificate(
    maximum_charge: int = 8,
    area: float = 1.0,
    gauge_coupling: float = 1.0,
) -> dict[str, Any]:
    """Show that the minimal positive action uniquely selects Q=0."""
    if maximum_charge < 3:
        raise ValueError("maximum_charge must include Q=3")
    charges = list(range(-maximum_charge, maximum_charge + 1))
    actions = [uniform_flux_action(q, area, gauge_coupling) for q in charges]
    minimum = min(actions)
    minimizers = [q for q, action in zip(charges, actions) if abs(action - minimum) < 1e-13]
    q3_action = uniform_flux_action(3, area, gauge_coupling)
    q1_action = uniform_flux_action(1, area, gauge_coupling)
    ratio = q3_action / q1_action
    passed = bool(minimizers == [0] and abs(ratio - 9.0) < 1e-13 and q3_action > minimum)
    return {
        "maximum_charge": int(maximum_charge),
        "area": float(area),
        "gauge_coupling": float(gauge_coupling),
        "charges": charges,
        "actions": actions,
        "minimizing_charges": minimizers,
        "q3_action_gap_above_vacuum": float(q3_action - minimum),
        "q3_to_q1_action_ratio": float(ratio),
        "pass": passed,
        "verdict": (
            "The minimal positive uniform-flux action selects Q=0 uniquely and "
            "penalizes Q=3 by nine times the Q=1 action. Therefore the current "
            "toy dynamics cannot explain three generations; a separately "
            "derived topological-selection mechanism is required."
        ),
        "scope": "uniform compact 2D U(1) flux sector with positive Maxwell action",
    }
