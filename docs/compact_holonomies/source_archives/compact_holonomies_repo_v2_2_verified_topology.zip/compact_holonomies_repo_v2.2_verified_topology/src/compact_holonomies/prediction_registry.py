"""Machine-readable registry separating predictions from assumptions and fits."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class RegisteredPrediction:
    prediction_id: str
    observable: str
    value: str
    free_parameters: tuple[str, ...]
    derivation_scope: str
    test_class: str
    external_status: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def registry() -> list[RegisteredPrediction]:
    return [
        RegisteredPrediction(
            "P001", "vacuum spherical HDA structure function", "beta(K_phi)=cos(2 delta K_phi)",
            ("delta",), "anomaly-free continuum vacuum spherical sector", "structural prediction", "not uniquely measured",
        ),
        RegisteredPrediction(
            "P002", "first beta sign-change", "|delta K_phi|=pi/4", ("delta",), "same sector",
            "dimensionless threshold prediction", "untested",
        ),
        RegisteredPrediction(
            "P003", "compact spectral coefficient ratio", "c6/c4^2=2/5", (), "fixed compact shift operator",
            "parameter-free mathematical prediction", "verified against withheld numerical spectrum",
        ),
        RegisteredPrediction(
            "P004", "linear tensor polarizations around Minkowski", "2", (),
            "minimal covariant curvature-cubed low-energy completion", "low-energy physical prediction",
            "consistent with observations; not distinctive from GR",
        ),
        RegisteredPrediction(
            "P005", "tree-level gravitational-wave speed around Minkowski", "c_gw/c=1", (),
            "same low-energy completion", "low-energy physical prediction", "consistent with GW170817",
        ),
        RegisteredPrediction(
            "P006", "overlap-Dirac topological index", "index(D_ov)=-Q", (),
            "2D periodic U(1) uniform-flux lattice with fixed link convention", "parameter-free topological prediction",
            "verified on 20 unselected finite-lattice flux challenges",
        ),
        RegisteredPrediction(
            "P007", "minimal one-generation hypercharge ratios",
            "Y_Q:Y_uc:Y_dc:Y_L:Y_ec:Y_H = 1:-4:2:-3:6:3", (),
            "assumed SU(3)xSU(2) representations, one Higgs, Yukawa invariance, no nu_R, anomaly cancellation",
            "conditional algebraic prediction", "symbolically verified; representation pattern remains assumed",
        ),
        RegisteredPrediction(
            "P008", "one-loop gauge beta coefficients", "(b1,b2,b3)=(41/10,-19/6,-7)", (),
            "three generations, one Higgs doublet, GUT-normalized g1", "conditional renormalization-group prediction",
            "derived exactly from the assumed matter content",
        ),
        RegisteredPrediction(
            "P009", "free 4D overlap doubler count", "one massless Brillouin corner; 15 doubler corners gapped by 2 rho/a",
            ("rho", "a"), "free four-dimensional overlap fermion with 0<rho<2r",
            "structural lattice prediction", "verified analytically/numerically; interactions not included",
        ),
        RegisteredPrediction(
            "P010", "topological family multiplicity", "N_chiral=|Q|; Q=3 gives three same-chirality zero modes",
            ("integer flux Q",), "2D compact U(1) overlap sector",
            "conditional topological prediction", "verified for Q=+/-3; the selection of Q=3 is not derived",
        ),
        RegisteredPrediction(
            "P011", "weak mixing angle at a common trace-normalization scale", "sin^2(theta_W)=3/8",
            (), "assumed SM representations and one common microscopic gauge-trace coefficient",
            "conditional exact relation", "verified algebraically; existence of a physical unification scale is not established",
        ),
        RegisteredPrediction(
            "P012", "held-out strong coupling in minimal exact one-loop unification", "alpha_s(MZ)=0.0710658",
            (), "PDG-2024 alpha1/alpha2 inputs; one-loop SM; no thresholds",
            "failed continuous physical prediction", "observed benchmark 0.1180+/-0.0009; minimal model falsified",
        ),
        RegisteredPrediction(
            "P013", "generation-count selection by current structural constraints", "N_g in {1,2,3,4,5}",
            (), "generation-wise anomaly cancellation plus Witten parity and one-loop SU2/SU3 asymptotic freedom",
            "no-go result", "three generations are allowed but not uniquely selected",
        ),
        RegisteredPrediction(
            "P014", "constant-Higgs flavor spectrum in the Q=3 symmetric toy sector", "three degenerate singular values",
            (), "same-bundle topological zero modes and constant scalar profile",
            "no-go result", "verified; hierarchy requires additional derived symmetry breaking",
        ),
    ]


def constants_coverage_report(target_count: int = 445) -> dict[str, object]:
    predictions = registry()
    tested_continuous = [item for item in predictions if item.test_class == "failed continuous physical prediction"]
    successful_continuous: list[RegisteredPrediction] = []
    return {
        "target_count": target_count,
        "registered_predictions_total": len(predictions),
        "registered_predictions": [item.as_dict() for item in predictions],
        "continuous_physical_predictions_tested": len(tested_continuous),
        "continuous_physical_predictions_passed": len(successful_continuous),
        "successful_coverage_fraction": 0.0,
        "failed_tests": [item.as_dict() for item in tested_continuous],
        "verdict": (
            "The theory now exposes one quantitative continuous coupling prediction to a held-out death test, "
            "and it fails. No measured continuous Standard-Model, CODATA or PDG parameter has yet been "
            "successfully derived. Successful coverage therefore remains 0/445."
        ),
    }
