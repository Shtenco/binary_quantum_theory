#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / "preregistration/FUTURE_BLIND_PREDICTIONS_v2.2.json"
manifest = {
    "version": "2.2.0",
    "frozen_predictions": [
        {
            "id": "F001",
            "prediction": "Exactly two luminal tensor modes around Minkowski in the minimal curvature-cubed completion.",
            "formula": "N_TT=2; c_gw/c=1; omega^2=k^2 at quadratic order",
            "allowed_refutation": "A robust extra tensor polarization or vacuum linear dispersion inconsistent with source effects refutes this completion.",
        },
        {
            "id": "F002",
            "prediction": "Vacuum spherical structure function beta crosses zero first at |delta K_phi|=pi/4.",
            "formula": "beta=cos(2 delta K_phi)",
            "allowed_refutation": "A derivation from the same fixed f1 showing a different beta refutes the sector implementation.",
        },
        {
            "id": "F003",
            "prediction": "The fixed compact shift spectrum has c6/c4^2=2/5.",
            "formula": "4 sin^2(q/2)=q^2-q^4/12+q^6/360+...",
            "allowed_refutation": "Independent diagonalization of the registered operator disagreeing beyond numerical tolerance refutes the implementation.",
        },
        {
            "id": "F004",
            "prediction": "For the registered uniform-flux convention, the overlap index equals minus the integer U(1) flux.",
            "formula": "index(D_ov)=Tr gamma5(1-a D_ov/(2 rho))=-Q",
            "allowed_refutation": "A nonsingular admissible challenge in the registered lattice family producing a noninteger index or index != -Q refutes the implementation.",
        },
        {
            "id": "F005",
            "prediction": "The free 4D overlap operator has only the p=0 massless Brillouin corner for 0<rho<2r.",
            "formula": "D_ov(0)=0; sigma_min[D_ov(p_corner)]=2 rho/a for every nonzero pi-corner",
            "allowed_refutation": "Any additional zero at a nonzero Brillouin corner in the stated parameter interval refutes the implementation.",
        },
        {
            "id": "F006",
            "prediction": "In the registered overlap flux family, the chiral zero-mode multiplicity equals |Q|.",
            "formula": "N_zero=|index(D_ov)|=|Q|",
            "allowed_refutation": "An admissible nonsingular Q challenge with a different zero-mode count refutes the implementation.",
        },
    ],
    "conditional_results_not_counted_as_external_blind_predictions": [
        "Standard-Model hypercharge ratios after assuming the representation pattern and Yukawa terms",
        "one-loop beta coefficients after assuming three generations and one Higgs doublet",
        "sin^2(theta_W)=3/8 after assuming a common gauge-trace normalization",
        "Q=3 as the physical flux sector; only the implication Q=3 -> three chiral modes is verified",
    ],
    "prohibited_after_freeze": [
        "changing formulas after seeing challenge data",
        "adding observable-specific fit coefficients",
        "counting constructed gauge couplings as predictions",
        "claiming that anomaly cancellation alone derives the gauge group or number of generations",
    ],
}
serialized = json.dumps(manifest, indent=2, sort_keys=True).encode()
manifest_path.write_bytes(serialized)
digest = hashlib.sha256(serialized).hexdigest()
result = {"artifact_id": "A23", "manifest": str(manifest_path.relative_to(ROOT)), "sha256": digest}
out = ROOT / "artifacts/A23_future_preregistration/frozen_manifest_hash.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
